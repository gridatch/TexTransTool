using System.Linq;
using NUnit.Framework;
using net.rs64.TexTransTool.TextureAtlas;
using net.rs64.TexTransTool.TextureAtlas.FineTuning;

namespace net.rs64.TexTransTool.TestCode
{
    internal class AutoAtlasTextureDefaultFineTuningAssumption
    {
        [Test]
        public void AtlasSettingDefaultsRemainCompatibleWithAutoAtlasTexture()
        {
            // AutoAtlasTexture intentionally inherits the regular AtlasTexture
            // defaults and removes only Resize. If upstream adds, removes, or
            // reorders a default tuning, review whether AutoAtlasTexture should
            // inherit that change before updating this expectation.
            var actual = new AtlasSetting().TextureFineTuning
                .Select(tuning => tuning.GetType())
                .ToArray();

            CollectionAssert.AreEqual(
                new[]
                {
                    typeof(Resize),
                    typeof(ReferenceCopy),
                    typeof(ColorSpace),
                    typeof(Compress),
                },
                actual);
        }
    }
}
