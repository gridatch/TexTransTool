#nullable enable
using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using System;
using net.rs64.TexTransCoreEngineForUnity;
using net.rs64.TexTransTool.TextureAtlas.FineTuning;
using net.rs64.TexTransTool.TextureAtlas.IslandRelocator;
using UnityEngine.Serialization;
using net.rs64.TexTransTool.Utils;
using net.rs64.TexTransCore;
using net.rs64.TexTransCore.UVIsland;
using net.rs64.TexTransTool.TextureAtlas.IslandSizePriorityTuner;

namespace net.rs64.TexTransTool.TextureAtlas
{
    [AddComponentMenu(TTTName + "/" + MenuPath)]
    public sealed partial class AtlasTexture : TexTransRuntimeBehavior, ITexTransToolStableComponent
    {
        internal const string ComponentName = "TTT AtlasTexture";
        internal const string MenuPath = ComponentName;
        public int StabilizeSaveDataVersion => TTTDataVersion_0_10_X;
        internal override TexTransPhase PhaseDefine => TexTransPhase.Optimizing;

        // targeting
        public List<Material?> AtlasTargetMaterials = new List<Material?>();

        // Bake-only settings. These do not affect normal NDMF AtlasTexture processing.
        public string BakeName = "";

        [FormerlySerializedAs("AtlasExcludedRenderers")]
        public List<Renderer?> BakeExcludedRenderers = new List<Renderer?>();

        // IslandSizePriorityTuner
        [SerializeReference, SubclassSelector] internal List<IIslandSizePriorityTuner?> IslandSizePriorityTuner = new();

        // material merge
        public List<MaterialMergeGroup> MergeMaterialGroups = new();
        [Serializable]
        public class MaterialMergeGroup
        {
            public List<Material> Group = new();
            public Material? Reference;
        }
        public Material? AllMaterialMergeReference;

        // Other atlasing Settings
        public AtlasSetting AtlasSetting = new AtlasSetting();


        internal override void Apply(IDomain domain)
        {
            using var rpf = new PFScope("AtlasTexture");
            using var pf = new PFScope("init");
            domain.LookAt(this);

            var targeting = domain as IRendererTargeting;
            var atlasSetting = AtlasSetting;

            if (AtlasTargetMaterials.Where(i => i != null).Any() is false) { TTLog.Info("AtlasTexture:info:TargetNotSet"); return; }

            pf.Split("targeting");

            var domainsAllowsRenderers = GetAtlasAllowedRenderers(domain, domain.EnumerateRenderer(), atlasSetting.IncludeDisabledRenderer);
            var targetMaterials = GetTargetMaterials(domain, domainsAllowsRenderers).ToHashSet();
            var targetRenderers = FilterTargetRenderers(targeting, domainsAllowsRenderers, targetMaterials);
            targetRenderers = FilterExistUVChannel(targeting,targetRenderers, atlasSetting.AtlasTargetUVChannel);

            if (targetMaterials.Any() is false || targetRenderers.Any() is false) { TTLog.Info("AtlasTexture:info:TargetNotFound"); return; }

            pf.Split("looking");

            foreach (var mmg in MergeMaterialGroups) { if (mmg.Reference != null) { domain.LookAt(mmg.Reference); } }
            if (AllMaterialMergeReference != null) { domain.LookAt(AllMaterialMergeReference); }
            domain.LookAtGetComponent<AtlasTextureExperimentalFeature>(gameObject);
            var experimentalOptions = GetComponent<AtlasTextureExperimentalFeature>();
            if (experimentalOptions == null) { experimentalOptions = null; }// UnityNull を潰す

            pf.Split("prepare");

            var engine = domain.GetTexTransCoreEngineForUnity();

            pf.Split("Atlasing!");
            // Do Atlasing!
            var atlasResult = DoAtlasTexture(domain, engine, targetMaterials, targetRenderers, IslandSizePriorityTuner, atlasSetting);
            if (atlasResult.IsSuccess is false) { return; }
            using var atlasContext = atlasResult.AtlasContext!;
            var atlasedMeshes = atlasResult.AtlasedMeshes!;
            var compiledAtlasTextures = atlasResult.CompiledAtlasTextures!;
            var preserveBump2ndMaterials = atlasResult.PreserveBump2ndMaterials;
            var preservedOriginalUVChannel = atlasResult.PreservedOriginalUVChannel;

            pf.Split("tex fine tuning");
            //Texture Fine Tuning
            var tunedAtlasTextures = DoTextureFinTuning(engine, atlasContext, atlasSetting, compiledAtlasTextures, experimentalOptions);

            var tunedAtlasUnityTextures = tunedAtlasTextures.RenderTextures.ToDictionary(i => i.Key, i => engine.GetReferenceRenderTexture(i.Value));
            var usedRT = new HashSet<ITTRenderTexture>(tunedAtlasTextures.TextureDescriptors.Keys);

            pf.Split("replace mesh");
            //Mesh Change
            ReplaceMesh(domain, targetRenderers, atlasContext, atlasedMeshes);

            pf.Split("gen and replace material");
            //MaterialGenerate And Change
            ReplaceAtlasedMaterials(domain, targetMaterials, atlasSetting, (MergeMaterialGroups, AllMaterialMergeReference, experimentalOptions), tunedAtlasUnityTextures, preserveBump2ndMaterials, preservedOriginalUVChannel);

            pf.Split("register textures");
            // Register AtlasedTextures
            foreach (var t in compiledAtlasTextures.Values) { if (usedRT.Contains(t) is false) t.Dispose(); }
            foreach (var aTex in tunedAtlasTextures.TextureDescriptors)
                domain.RegisterPostProcessingAndLazyGPUReadBack(aTex.Key, aTex.Value);
        }

        internal static Renderer[] FilterTargetRenderers(IRendererTargeting targeting, List<Renderer> nowRenderers, HashSet<Material> targetMaterials)
        {
            return nowRenderers
                .Where(r => targeting.GetMesh(r) != null)
                .Where(r => targeting.GetMaterials(r)
                    .UOfType<Material>()
                    .Any(targetMaterials.Contains)
                ).ToArray();
        }
        internal static Renderer[] FilterExistUVChannel(IRendererTargeting targeting, Renderer[] targetRenderers, UVChannel atlasTargetUVChannel)
        {
            return targetRenderers.Where(r => targeting.GetMesh(r).HasUV((int)atlasTargetUVChannel)).ToArray();
        }


        internal static AtlasResult DoAtlasTexture(
            IDomain domain
            , ITexTransToolForUnity engine

            , HashSet<Material> targetMaterials
            , Renderer[] targetRenderers

            , List<IIslandSizePriorityTuner?> islandSizePriorityTuner

            , AtlasSetting atlasSetting
            , bool requireLossless = false
            , int maxAtlasSize = 4096
            , Func<AtlasContext, Vector2Int, bool>? acceptAtlasSize = null
        )
        {
            using var pf = new PFScope("init");
            var targeting = domain as IRendererTargeting;

            var preserveBump2ndMaterials = GetBump2ndOriginalUVPreserveMaterials(targetMaterials, targetRenderers, targeting, atlasSetting.AtlasTargetUVChannel);
            var preservedOriginalUVChannel = preserveBump2ndMaterials.Any()
                ? FindUnusedUVChannel(targetRenderers, targeting, atlasSetting.AtlasTargetUVChannel)
                : null;

            if (preserveBump2ndMaterials.Any() && preservedOriginalUVChannel is null)
            {
                TTLog.Error("AtlasTexture:error:NoFreeUVChannelForIndependentTexture");
                return new(false, null, null, null, preserveBump2ndMaterials, null);
            }

            pf.Split("AtlasContext ctr");
            var atlasContext = new AtlasContext(
                               targeting
                               , targetRenderers
                               , targetMaterials
                               , new()
                               {
                                   AtlasTargetUVChannel = atlasSetting.AtlasTargetUVChannel,
                                   PrimaryTexturePropertyOrMaximum = atlasSetting.UsePrimaryMaximumTexture ? null : atlasSetting.PrimaryTextureProperty,
                                   AtlasIslandContextOption = new(),
                               }
                               );



            pf.Split("PixelNormalize");
            //アイランドまわり
            if (atlasSetting.PixelNormalize)
                atlasContext.SourceVirtualIslandNormalize();

            if (atlasSetting.PixelNormalize && TTMath.Approximately(atlasSetting.IslandPadding, 0))
                TTLog.Warning("AtlasTexture:warn:IslandPaddingIsZeroAndPixelNormalizeUsed");

            pf.Split("IslandProcessing");
            var (atlasTargeSize, movedVirtualIslandArray, relocateResult, relocationTime) =
                SelectAtlasSizeAndRelocate(domain, atlasSetting, atlasContext, islandSizePriorityTuner, maxAtlasSize);
            if (requireLossless && IsLosslessRelocation(relocateResult) is false)
            {
                atlasContext.Dispose();
                return new(false, null, null, null, preserveBump2ndMaterials, preservedOriginalUVChannel);
            }
            if (relocateResult.IslandRelocationResult is null || relocateResult.IslandRelocationResult.IsSuccess is false)
            {
                // Abort!!!
                TTLog.Error("AtlasTexture:error:RelocationFailed");
                atlasContext.Dispose();
                return new(false, null, null, null, preserveBump2ndMaterials, preservedOriginalUVChannel);
            }
            var source2MovedVirtualIsland = new Dictionary<IslandTransform, IslandTransform>();
            for (var i = 0; movedVirtualIslandArray.Length > i; i += 1)
            {
                source2MovedVirtualIsland[atlasContext.SourceVirtualIslands[i]] = movedVirtualIslandArray[i];
            }


            pf.Split("check hight");
            //上側を削れるかを見る
            var height = IslandRelocationManager.CalculateIslandsMaxHeight(movedVirtualIslandArray) + atlasSetting.IslandPadding;
            var atlasTextureHeightSize = Mathf.Max(GetNormalizedMinHeightSize(atlasTargeSize.y, height), 4);//4以下はちょっと怪しい挙動しそうだからクランプ
            Debug.Assert(Mathf.IsPowerOfTwo(atlasTextureHeightSize));

            TTLog.Info("AtlasTexture:info:RelocateResult", 1 - height, relocateResult.PriorityDownScale, relocateResult.OverallDownScale, relocateResult.TotalRelocateCount, relocationTime);
            var atlasedTextureSize = new Vector2Int(atlasTargeSize.x, atlasTextureHeightSize);
            if (acceptAtlasSize != null && acceptAtlasSize(atlasContext, atlasedTextureSize) is false)
            {
                atlasContext.Dispose();
                return new(false, null, null, null, preserveBump2ndMaterials, preservedOriginalUVChannel);
            }

            //新しいUVを持つMeshを生成するフェーズ

            pf.Split("GenerateAtlasedMesh");
            // SubSetIndex と対応する
            var atlasedMeshes = atlasContext.GenerateAtlasedMesh(atlasSetting, source2MovedVirtualIsland, atlasedTextureSize, preserveBump2ndMaterials, preservedOriginalUVChannel);
            pf.Split("GenerateAtlasedTextures");
            var compiledAtlasTextures = atlasContext.GenerateAtlasedTextures(
                  engine
                  , atlasSetting
                  , atlasedTextureSize
                  , relocateResult.IslandRelocationResult.IsRectangleMove
                  , source2MovedVirtualIsland
              );
            pf.Split("exit");
            return new(true, atlasContext, atlasedMeshes, compiledAtlasTextures, preserveBump2ndMaterials, preservedOriginalUVChannel);
        }
        internal record AtlasResult
        {
            public readonly bool IsSuccess;
            // Dispose はきちんとする必要がある。
            // Mesh や RT は後に渡したりとかになるが AtlasContext には気をつけるようにね
            public readonly AtlasContext? AtlasContext;
            public readonly Mesh[]? AtlasedMeshes;
            public readonly Dictionary<string, ITTRenderTexture>? CompiledAtlasTextures;
            public readonly HashSet<Material> PreserveBump2ndMaterials;
            public readonly int? PreservedOriginalUVChannel;

            public AtlasResult(
                bool isSuccess,
                AtlasContext? atlasContext,
                Mesh[]? atlasedMesh,
                Dictionary<string, ITTRenderTexture>? compiledAtlasTextures,
                HashSet<Material> preserveBump2ndMaterials,
                int? preservedOriginalUVChannel)
            {
                IsSuccess = isSuccess;
                AtlasContext = atlasContext;
                AtlasedMeshes = atlasedMesh;
                CompiledAtlasTextures = compiledAtlasTextures;
                PreserveBump2ndMaterials = preserveBump2ndMaterials;
                PreservedOriginalUVChannel = preservedOriginalUVChannel;
            }
        }
        internal static TexFineTuningResult DoTextureFinTuning(ITexTransToolForUnity engine, AtlasContext atlasContext, AtlasSetting atlasSetting, Dictionary<string, ITTRenderTexture> compiledAtlasTextures, AtlasTextureExperimentalFeature? experimentalOptions)
        {
            var atlasTexFineTuningTargets = TexFineTuningUtility.InitTexFineTuningHolders(compiledAtlasTextures.Keys);

            // AutoTunings
            if (experimentalOptions?.AutoTextureSizeSetting ?? false) SetSizeDataMaxSize(atlasTexFineTuningTargets, atlasContext.MaterialGroupingCtx);
            if (experimentalOptions?.AutoMergeTextureSetting ?? false) DefaultMargeTextureDictTuning(atlasTexFineTuningTargets, atlasContext.MaterialGroupingCtx);
            if (experimentalOptions?.AutoReferenceCopySetting ?? false) DefaultRefCopyTuning(atlasTexFineTuningTargets, atlasContext.MaterialGroupingCtx);

            foreach (var fineTuning in atlasSetting.TextureFineTuning) { fineTuning?.AddSetting(atlasTexFineTuningTargets); }
            if (experimentalOptions is not null) IndividualTuningAddSettings(atlasTexFineTuningTargets, experimentalOptions.TextureIndividualFineTuning);

            var tunedAtlasTextures = TexFineTuningUtility.ProcessingTextureFineTuning(engine, atlasTexFineTuningTargets, compiledAtlasTextures);
            return tunedAtlasTextures;
        }

        internal static void ReplaceMesh(IDomain domain, Renderer[] targetRenderers, AtlasContext atlasContext, Mesh[] atlasedMeshes)
        {
            var registered = new HashSet<Mesh>();
            foreach (var renderer in targetRenderers)
            {
                var mesh = domain.GetMesh(renderer);
                if (mesh == null) { continue; }
                if (atlasContext.NormalizedMeshCtx.Origin2NormalizedMesh.ContainsKey(mesh) is false) { continue; }

                var meshID = atlasContext.NormalizedMeshCtx.Normalized2MeshID[atlasContext.NormalizedMeshCtx.Origin2NormalizedMesh[mesh]];
                var matIDs = domain.GetMaterials(renderer).Select(m => m != null ? atlasContext.MaterialGroupingCtx.GetMaterialGroupID(m) : -1).ToArray();

                var subSet = new AtlasSubMeshIndexID?[matIDs.Length];
                for (var i = 0; subSet.Length > i; i += 1)
                {
                    var matID = matIDs[i];
                    if (matID is -1) { subSet[i] = null; }
                    else { subSet[i] = new AtlasSubMeshIndexID(meshID, i, matID); }
                }



                var identicalSubSetID = GetIdenticalSubSet(atlasContext.AtlasSubMeshIndexSetCtx.AtlasSubSets, subSet);
                int GetIdenticalSubSet(List<AtlasSubMeshIndexID?[]> atlasSubSetAll, AtlasSubMeshIndexID?[] findSource)
                {
                    return atlasSubSetAll.FindIndex(subSet =>
                    {

                        if (subSet.Length == findSource.Length && subSet.SequenceEqual(findSource)) { return true; }
                        if (AtlasSubMeshIndexIDSetContext.SubPartEqual(subSet, findSource) is false) { return false; }
                        return subSet.Length < findSource.Length is false;
                    });
                }
                if (identicalSubSetID is -1) { continue; }


                var atlasMesh = atlasedMeshes[identicalSubSetID];
                domain.SetMesh(renderer, atlasMesh);

                if (registered.Contains(atlasMesh) is false)
                {
                    domain.RegisterReplace(mesh, atlasMesh);
                    registered.Add(atlasMesh);
                }
            }
            domain.TransferAssets(atlasedMeshes);
        }

        internal static void ReplaceAtlasedMaterials(
            IDomain domain
            , HashSet<Material> targetMaterials
            , AtlasSetting atlasSetting
            , (List<MaterialMergeGroup> mergeMaterialGroups, Material? allMaterialMergeReference, AtlasTextureExperimentalFeature? experimentalOptions) atlasMergeSettings
            , Dictionary<string, RenderTexture> tunedAtlasUnityTextures
            , HashSet<Material> preserveBump2ndMaterials
            , int? preservedOriginalUVChannel
            )
        {
            var (materialMap, domainsMaterial2ReplaceMaterial) = GenerateAtlasedMaterialMaps(
                domain,
                targetMaterials,
                atlasSetting,
                atlasMergeSettings,
                tunedAtlasUnityTextures,
                preserveBump2ndMaterials,
                preservedOriginalUVChannel
            );

            domain.ReplaceMaterials(materialMap);
            domain.RegisterReplaces(domainsMaterial2ReplaceMaterial);
        }

        internal static (
            Dictionary<Material, Material> materialMap,
            Dictionary<Material, Material> domainsMaterial2ReplaceMaterial
        ) GenerateAtlasedMaterialMaps<Tex>(
            IDomain domain
            , HashSet<Material> targetMaterials
            , AtlasSetting atlasSetting
            , (List<MaterialMergeGroup> mergeMaterialGroups, Material? allMaterialMergeReference, AtlasTextureExperimentalFeature? experimentalOptions) atlasMergeSettings
            , Dictionary<string, Tex> tunedAtlasTextures
            , HashSet<Material> preserveBump2ndMaterials
            , int? preservedOriginalUVChannel
            ) where Tex : Texture
        {
            var atlasMatOption = new AtlasMatGenerateOption()
            {
                ForceSetTexture = atlasSetting.ForceSetTexture,
                PreserveBump2ndMaterials = preserveBump2ndMaterials,
                PreservedOriginalUVChannel = preservedOriginalUVChannel,
            };
            if (atlasMergeSettings.experimentalOptions?.UnsetTextures.Any() ?? false)
            {
                var containsAllTexture = targetMaterials.SelectMany(mat => mat.EnumerateReferencedTextures());
                atlasMatOption.UnsetTextures = atlasMergeSettings.experimentalOptions.UnsetTextures.Select(i => i.SelectTexture).SelectMany(ot => containsAllTexture.Where(ct => domain.OriginEqual(ot, ct))).ToHashSet();
            }

            var mergeReferenceMaterial = GenerateMergeReference(
                domain.OriginEqual,
                targetMaterials,
                atlasMergeSettings.mergeMaterialGroups,
                atlasMergeSettings.allMaterialMergeReference
            );
            return GenerateAtlasedMaterials(targetMaterials, tunedAtlasTextures, atlasMatOption, mergeReferenceMaterial);
        }

        private static (Dictionary<Material, Material> materialMap, Dictionary<Material, Material> domainsMaterial2ReplaceMaterial)
            GenerateAtlasedMaterials<Tex>(HashSet<Material> targetMaterials, Dictionary<string, Tex> tex, AtlasMatGenerateOption atlasMatOption, NowMaterialGroup[] mergeReferenceMaterial)
            where Tex : Texture
        {
            var materialMap = new Dictionary<Material, Material>();
            var domainsMaterial2ReplaceMaterial = new Dictionary<Material, Material>();
            var mergeRef2MergedMaterial = new Dictionary<Material, Material>();
            foreach (var distMat in targetMaterials)
            {
                var mergeGroup = mergeReferenceMaterial.FirstOrDefault(g => g.GroupMaterial.Contains(distMat));
                var referenceMaterial = mergeGroup?.MergeReference;
                var remapBump2ndUV = referenceMaterial == null
                    ? atlasMatOption.PreserveBump2ndMaterials.Contains(distMat)
                    : mergeGroup!.GroupMaterial.Any(atlasMatOption.PreserveBump2ndMaterials.Contains);

                if (referenceMaterial == null)
                {
                    domainsMaterial2ReplaceMaterial[distMat] = GenerateAtlasMat(distMat, tex, atlasMatOption, remapBump2ndUV);
                    materialMap.Add(distMat, domainsMaterial2ReplaceMaterial[distMat]);
                }
                else
                {
                    if (mergeRef2MergedMaterial.ContainsKey(referenceMaterial) is false)
                    {
                        domainsMaterial2ReplaceMaterial[referenceMaterial]
                            = mergeRef2MergedMaterial[referenceMaterial]
                            = GenerateAtlasMat(referenceMaterial, tex, atlasMatOption, remapBump2ndUV);
                    }
                    materialMap.Add(distMat, mergeRef2MergedMaterial[referenceMaterial]);
                }
            }
            return (materialMap, domainsMaterial2ReplaceMaterial);
        }
        private static NowMaterialGroup[] GenerateMergeReference(OriginEqual originEqual, HashSet<Material> targetMaterials, List<MaterialMergeGroup> mergeMaterialGroups, Material? allMaterialMergeReference)
        {
            var matGroupList = new List<NowMaterialGroup>();
            foreach (var mmg in mergeMaterialGroups)
            {
                var domainMaterialGroup = originEqual.GetDomainsMaterialsHashSet(targetMaterials, mmg.Group);
                var domainMaterialMergeRef = mmg.Reference != null ? originEqual.GetDomainsMaterial(targetMaterials, mmg.Reference) ?? mmg.Reference : null;

                matGroupList.Add(new(domainMaterialGroup, domainMaterialMergeRef));
            }

            var domainAllMaterialMergeRef = allMaterialMergeReference != null ? originEqual.GetDomainsMaterial(targetMaterials, allMaterialMergeReference) ?? allMaterialMergeReference : null;
            matGroupList.Add(new(targetMaterials, domainAllMaterialMergeRef));

            return matGroupList.ToArray();
        }
        record NowMaterialGroup
        {
            public HashSet<Material> GroupMaterial;
            public Material? MergeReference;

            public NowMaterialGroup(HashSet<Material> groupMaterial, Material? mergeReference)
            {
                GroupMaterial = groupMaterial;
                MergeReference = mergeReference;
            }
        }

        private static int GetNormalizedMinHeightSize(int atlasTextureSize, float height)
        {
            switch (height)
            {
                default: return atlasTextureSize;
                case < (1 / 32f): return atlasTextureSize / 32;
                case < (1 / 16f): return atlasTextureSize / 16;
                case < (1 / 8f): return atlasTextureSize / 8;
                case < (1 / 4f): return atlasTextureSize / 4;
                case < (1 / 2f): return atlasTextureSize / 2;
            }
        }
        private static readonly int[] AutoAtlasTextureSizeCandidates = { 256, 512, 1024, 2048, 4096 };

        static Vector2Int GetAtlasTextureSize(AtlasSetting atlasSetting)
        {
            var atlasTargeSize = new Vector2Int(atlasSetting.AtlasTextureSize, atlasSetting.AtlasTextureSize);
            if (atlasSetting.CustomAspect) { atlasTargeSize.y = atlasSetting.AtlasTextureHeightSize; }
            return atlasTargeSize;
        }

        private static (
            Vector2Int atlasTargetSize,
            IslandTransform[] virtualIslandArray,
            IslandRelocationManager.RelocateResult relocateResult,
            long relocationTime
        ) SelectAtlasSizeAndRelocate(
            IRendererTargeting domain,
            AtlasSetting atlasSetting,
            AtlasContext atlasContext,
            List<IIslandSizePriorityTuner?> islandSizePriorityTuner,
            int maxAtlasSize)
        {
            if (atlasSetting.AutoAtlasTextureSize is false)
            {
                var manualSize = GetAtlasTextureSize(atlasSetting);
                var (manualIslands, manualResult) = IslandProcessing(
                    domain,
                    atlasSetting,
                    atlasContext,
                    islandSizePriorityTuner,
                    manualSize,
                    out var manualTime
                );
                return (manualSize, manualIslands, manualResult, manualTime);
            }

            IslandTransform[]? selectedIslands = null;
            IslandRelocationManager.RelocateResult? selectedResult = null;
            var maxCandidateSize = AutoAtlasTextureSizeCandidates[AutoAtlasTextureSizeCandidates.Length - 1];
            var selectedSize = new Vector2Int(maxCandidateSize, maxCandidateSize);
            long totalRelocationTime = 0;

            foreach (var size in AutoAtlasTextureSizeCandidates.Where(candidate => candidate <= maxAtlasSize))
            {
                var candidateSize = new Vector2Int(size, size);
                var (candidateIslands, candidateResult) = IslandProcessing(
                    domain,
                    atlasSetting,
                    atlasContext,
                    islandSizePriorityTuner,
                    candidateSize,
                    out var candidateTime
                );

                totalRelocationTime += candidateTime;
                selectedSize = candidateSize;
                selectedIslands = candidateIslands;
                selectedResult = candidateResult;

                if (IsLosslessRelocation(candidateResult))
                {
                    TTLog.Info("AtlasTexture:info:AutoAtlasTextureSizeSelected", size);
                    break;
                }
            }

            Debug.Assert(selectedIslands is not null);
            Debug.Assert(selectedResult is not null);

            if (IsLosslessRelocation(selectedResult!) is false)
            {
                TTLog.Warning(
                    "AtlasTexture:warn:AutoAtlasTextureSizeLosslessNotFound",
                    selectedSize.x,
                    selectedResult!.PriorityDownScale,
                    selectedResult.OverallDownScale
                );
            }

            return (selectedSize, selectedIslands!, selectedResult!, totalRelocationTime);
        }

        private static bool IsLosslessRelocation(IslandRelocationManager.RelocateResult relocateResult)
        {
            return relocateResult.IslandRelocationResult?.IsSuccess is true
                && TTMath.Approximately(relocateResult.PriorityDownScale, 1f)
                && TTMath.Approximately(relocateResult.OverallDownScale, 1f);
        }

        private static (IslandTransform[] virtualIslandArray, IslandRelocationManager.RelocateResult relocateResult) IslandProcessing(
            IRendererTargeting domain
            , AtlasSetting atlasSetting
            , AtlasContext atlasContext
            , List<IIslandSizePriorityTuner?> islandSizePriorityTuner
            , Vector2Int atlasTargeSize
            , out long relocationTime
        )
        {
            var virtualIslandArray = new IslandTransform[atlasContext.SourceVirtualIslands.Length];

            for (var i = 0; virtualIslandArray.Length > i; i += 1)
                virtualIslandArray[i] = atlasContext.SourceVirtualIslands[i].Clone();



            atlasContext.PrimaryTextureSizeScaling(virtualIslandArray, atlasTargeSize);

            var refOriginIslands = GetSourceVirtualIslandForRefOriginIslands(atlasContext);
            var islandDescription = GenerateIslandDescription(atlasContext, refOriginIslands);

            var sizePriority = new float[virtualIslandArray.Length];
            for (var i = 0; sizePriority.Length > i; i += 1) { sizePriority[i] = 1f; }

            foreach (var islandFineTuner in islandSizePriorityTuner)
                islandFineTuner?.Tuning(sizePriority, refOriginIslands, islandDescription, domain);

            for (var i = 0; sizePriority.Length > i; i += 1)
                sizePriority[i] = TTMath.Saturate(sizePriority[i]);

            if (atlasSetting.AtlasIslandRelocator != null) { throw new NotImplementedException(); }
            var islandRelocator = new NFDHPlasFC() as IIslandRelocator;


            var relocateManage = new IslandRelocationManager(islandRelocator);
            relocateManage.Padding = atlasSetting.IslandPadding;
            relocateManage.ForceSizePriority = atlasSetting.ForceSizePriority;
            relocateManage.Height = (float)atlasTargeSize.y / atlasTargeSize.x;

            var timer = System.Diagnostics.Stopwatch.StartNew();
            relocateManage.RelocateLoop(atlasContext, virtualIslandArray, sizePriority, out var relocateResult);
            timer.Stop();
            relocationTime = timer.ElapsedMilliseconds;

            var rectTangleMove = relocateResult.IslandRelocationResult?.IsRectangleMove ?? true;
            Debug.Assert(rectTangleMove is true);

            PostVirtualIslandProcessing(virtualIslandArray, atlasTargeSize, atlasSetting.PixelNormalize);

            return (virtualIslandArray, relocateResult);
        }
        private static Island[] GetSourceVirtualIslandForRefOriginIslands(AtlasContext atlasContext)
        {
            var refOriginIslands = new Island[atlasContext.SourceVirtualIslands.Length];
            for (var i = 0; atlasContext.SourceVirtualIslands.Length > i; i += 1)
            {
                var refOriginIsland = atlasContext.ReverseSourceVirtualIsland2OriginIslands[atlasContext.SourceVirtualIslands[i]].First();
                refOriginIslands[i] = refOriginIsland;
            }

            return refOriginIslands;
        }
        private static IslandSelector.IslandDescription[] GenerateIslandDescription(AtlasContext atlasContext, Island[] refOriginIslands)
        {
            var islandDescription = new IslandSelector.IslandDescription[atlasContext.SourceVirtualIslands.Length];

            var sharedMaterialsCache = new Dictionary<Renderer, Material[]>();
            for (var i = 0; atlasContext.SourceVirtualIslands.Length > i; i += 1)
            {
                var refOriginIsland = refOriginIslands[i];
                var atlasSubMeshIndexID = atlasContext.AtlasIslandCtx.ReverseOriginDict[refOriginIsland];
                var md = atlasContext.NormalizedMeshCtx.GetMeshDataFromMeshID(atlasSubMeshIndexID.MeshID);

                var vertex = md.Vertices;
                var uv = md.VertexUV;
                var renderer = md.ReferenceRenderer;

                if (sharedMaterialsCache.TryGetValue(renderer, out var rMats) is false)
                    rMats = sharedMaterialsCache[renderer] = renderer.sharedMaterials;

                islandDescription[i] = new IslandSelector.IslandDescription(vertex, uv, renderer, rMats, atlasSubMeshIndexID.SubMeshIndex);
            }
            return islandDescription;
        }

        internal static void PostVirtualIslandProcessing(IslandTransform[] virtualIslandArray, Vector2Int atlasTargeSize, bool pixelNormalize)
        {
            if (pixelNormalize)
            {
                for (var i = 0; virtualIslandArray.Length > i; i += 1)
                {
                    virtualIslandArray[i].Position = AtlasContext.NormalizeMin(atlasTargeSize.x, atlasTargeSize.y, virtualIslandArray[i].Position);
                }
            }

            for (var i = 0; virtualIslandArray.Length > i; i += 1)
            {
                if (virtualIslandArray[i].Size.X <= 0.0001f) { virtualIslandArray[i].Size.X = 0.0001f; }
                if (virtualIslandArray[i].Size.Y <= 0.0001f) { virtualIslandArray[i].Size.Y = 0.0001f; }
            }//Islandが小さすぎると RectTangleMoveのコピーがうまくいかない
        }
        internal static void SetSizeDataMaxSize(Dictionary<string, TexFineTuningHolder> atlasTexFineTuningTargets, MaterialGroupingContext materialGroupingCtx)
        {
            foreach (var tuningTarget in atlasTexFineTuningTargets)
            {
                var maxSize = materialGroupingCtx.GroupMaterials.Max(i => i.GroupedTexture.TryGetValue(tuningTarget.Key, out var tex) ? tex.width : 0);
                var sizeData = tuningTarget.Value.Get<SizeData>();
                sizeData.TextureSize = maxSize;
            }
        }
        internal static void DefaultRefCopyTuning(Dictionary<string, TexFineTuningHolder> atlasTexFineTuningTargets, MaterialGroupingContext materialGroupingCtx)
        {


            var prop = atlasTexFineTuningTargets.Keys.ToArray();
            var refCopyDict = new Dictionary<string, string>();

            var gtHash = prop.ToDictionary(p => p, p => materialGroupingCtx.GroupMaterials.Where(i => i.GroupedTexture.ContainsKey(p)).Select(i => i.GroupedTexture[p]).ToHashSet());

            for (var i = 0; prop.Length > i; i += 1)
                for (var i2 = 0; prop.Length > i2; i2 += 1)
                {
                    if (i == i2) { continue; }

                    var copySource = prop[i];
                    var copyTarget = prop[i2];

                    var sTexHash = gtHash[copySource];
                    var tTexHash = gtHash[copyTarget];

                    if (sTexHash.SetEquals(tTexHash)) { refCopyDict.Remove(copySource); }

                    if (sTexHash.IsSupersetOf(tTexHash) is false) { continue; }
                    refCopyDict[copyTarget] = copySource;
                }


            var isContinue = true;
            var values = refCopyDict.Values.ToArray();
            while (isContinue)
            {
                foreach (var s in values)
                {
                    if (refCopyDict.ContainsKey(s))
                    {
                        foreach (var t in refCopyDict.Where(i => i.Value == s).ToArray())
                        {
                            refCopyDict[t.Key] = refCopyDict[s];
                        }
                        isContinue = true;
                    }
                }
                isContinue = false;
            }

            var copyRefResult = refCopyDict.GroupBy(i => i.Value).ToDictionary(i => i.Key, i => i.Select(k => k.Key).ToList());

            foreach (var fineTuning in copyRefResult.Select(i => new ReferenceCopy(new(i.Key), i.Value.Select(i => new PropertyName(i)).ToList())))
            {
                (fineTuning as ITextureFineTuning).AddSetting(atlasTexFineTuningTargets);
            }
        }

        internal static void DefaultMargeTextureDictTuning(Dictionary<string, TexFineTuningHolder> atlasTexFineTuningTargets, MaterialGroupingContext materialGroupingCtx)
        {

            var prop = atlasTexFineTuningTargets.Keys.ToArray();
            var prop2MatIDs = prop.ToDictionary(
                p => p,
                p => materialGroupingCtx.GroupMaterials
                    .Where(gt => gt.GroupedTexture.ContainsKey(p))
                    .Select(gt => materialGroupingCtx.GetMaterialGroupID(gt))
                    .ToHashSet()
            );

            var alreadySetting = new HashSet<string>();
            var margeSettingDict = new Dictionary<string, List<string>>();


            for (var i = 0; prop.Length > i; i += 1)
            {
                var mergeParent = prop[i];
                var mergedHash = prop2MatIDs[mergeParent].ToHashSet();
                var childList = new List<string>();

                for (var i2 = i; prop.Length > i2; i2 += 1)
                {
                    if (i == i2) { continue; }

                    var mergeChild = prop[i2];

                    if (alreadySetting.Contains(mergeChild)) { continue; }

                    var childHash = prop2MatIDs[mergeChild];

                    if (mergedHash.Overlaps(childHash)) { continue; }

                    childList.Add(mergeChild);
                    mergedHash.UnionWith(childHash);
                    alreadySetting.Add(mergeChild);
                }

                if (childList.Any()) { margeSettingDict[mergeParent] = childList; }
            }

            foreach (var fineTuning in margeSettingDict.Select(i => new MergeTexture(new(i.Key), i.Value.Select(i => new PropertyName(i)).ToList())))
            {
                (fineTuning as ITextureFineTuning).AddSetting(atlasTexFineTuningTargets);
            }
        }

        internal static void IndividualTuningAddSettings(Dictionary<string, TexFineTuningHolder> atlasTexFineTuningTargets, List<TextureIndividualTuning> individualTunings)
        {
            var individualApplied = new HashSet<string>();
            foreach (var individualTuning in individualTunings)
            {
                if (atlasTexFineTuningTargets.ContainsKey(individualTuning.TuningTarget) is false) { continue; }
                if (individualApplied.Contains(individualTuning.TuningTarget)) { continue; }
                individualApplied.Add(individualTuning.TuningTarget);

                var tuningTarget = atlasTexFineTuningTargets[individualTuning.TuningTarget];

                if (individualTuning.OverrideReferenceCopy) { tuningTarget.Get<ReferenceCopyData>().CopySource = individualTuning.CopyReferenceSource; }
                if (individualTuning.OverrideResize) { tuningTarget.Get<SizeData>().TextureSize = individualTuning.TextureSize; }
                if (individualTuning.OverrideCompression) { tuningTarget.Get<TextureCompressionTuningData>().CopyFrom(individualTuning.CompressionData); }
                if (individualTuning.OverrideMipMapRemove) { tuningTarget.Get<MipMapData>().UseMipMap = individualTuning.UseMipMap; }
                if (individualTuning.OverrideColorSpace) { tuningTarget.Get<ColorSpaceData>().AsLinear = individualTuning.AsLinear; }
                if (individualTuning.OverrideRemove) { tuningTarget.Get<RemoveData>().IsRemove = individualTuning.IsRemove; }
                if (individualTuning.OverrideMargeTexture) { tuningTarget.Get<MergeTextureData>().MargeParent = individualTuning.MargeRootProperty; }
            }
        }
        private static Material GenerateAtlasMat<Tex>(Material targetMat, Dictionary<string, Tex> atlasTex, AtlasMatGenerateOption option, bool remapBump2ndUV)
        where Tex : Texture
        {
            var editableTMat = UnityEngine.Object.Instantiate(targetMat);
            editableTMat.name = targetMat.name + "(TTT AtlasedMaterial)";

            foreach (var texKV in atlasTex)
            {
                if (remapBump2ndUV && texKV.Key == "_Bump2ndMap") { continue; }
                if (editableTMat.HasTexture(texKV.Key) is false) { continue; }
                var tex = editableTMat.GetTexture(texKV.Key);
                if (tex == null) { tex = null; }//これは Unity側の Null を C# の Null にしてるやつ

                if (option.ForceSetTexture is false && tex == null) { continue; }
                if (tex is not Texture2D && tex is not RenderTexture && tex is not null) { continue; }

                if (tex != null && option.UnsetTextures is not null && option.UnsetTextures.Contains(tex)) { continue; }

                editableTMat.SetTexture(texKV.Key, texKV.Value);
            }

            if (remapBump2ndUV && option.PreservedOriginalUVChannel is int preservedUVChannel)
            {
                const string bump2ndUVMode = "_Bump2ndMap_UVMode";
                if (editableTMat.HasInt(bump2ndUVMode))
                    editableTMat.SetInt(bump2ndUVMode, preservedUVChannel);
                else if (editableTMat.HasFloat(bump2ndUVMode))
                    editableTMat.SetFloat(bump2ndUVMode, preservedUVChannel);
            }

            return editableTMat;
        }
        class AtlasMatGenerateOption
        {
            public bool ForceSetTexture = false;
            public HashSet<Texture>? UnsetTextures = null;
            public HashSet<Material> PreserveBump2ndMaterials = new();
            public int? PreservedOriginalUVChannel = null;
        }




        private static HashSet<Material> GetBump2ndOriginalUVPreserveMaterials(
            HashSet<Material> targetMaterials,
            Renderer[] targetRenderers,
            IRendererTargeting targeting,
            UVChannel atlasTargetUVChannel)
        {
            var renderedMaterials = targetRenderers
                .SelectMany(targeting.GetMaterials)
                .UOfType<Material>()
                .Where(targetMaterials.Contains)
                .ToHashSet();

            var preserveMaterials = new HashSet<Material>();
            foreach (var material in renderedMaterials)
            {
                var usages = TTShaderTextureUsageInformationUtil.GetContainsUVTransformUsage(material);
                if (usages.TryGetValue("_Bump2ndMap", out var usage) is false) { continue; }
                if (TTShaderTextureUsageInformationUtil.RequiresBump2ndOriginalUVPreservation("_Bump2ndMap", usage, atlasTargetUVChannel) is false) { continue; }

                var textureProperties = material.GetTexturePropertyNames().ToHashSet();
                if (textureProperties.Contains("_Bump2ndMap") is false) { continue; }
                if (material.GetTexture("_Bump2ndMap") == null) { continue; }

                preserveMaterials.Add(material);
            }

            return preserveMaterials;
        }

        private static int? FindUnusedUVChannel(Renderer[] targetRenderers, IRendererTargeting targeting, UVChannel atlasTargetUVChannel)
        {
            for (var uvChannel = 3; uvChannel >= 0; uvChannel -= 1)
            {
                if (uvChannel == (int)atlasTargetUVChannel) { continue; }

                var isUsed = targetRenderers.Any(renderer =>
                {
                    var mesh = targeting.GetMesh(renderer);
                    return mesh != null && mesh.HasUV(uvChannel);
                });

                if (isUsed is false) { return uvChannel; }
            }

            return null;
        }

        internal List<Material> GetTargetMaterials(IDomain domain, List<Renderer> nowRenderers)
        {
            var nowContainsMatSet = new HashSet<Material>(nowRenderers.SelectMany(domain.GetMaterials).UOfType<Material>());
            var targetMaterials = nowContainsMatSet.Where(mat => AtlasTargetMaterials.Any(sMat => domain.OriginEqual(sMat, mat))).ToList();
            return targetMaterials;
        }
        internal static bool CheckRendererActive(IRendererTargeting targeting, Renderer r, bool includeDisabledRenderer)
        {
            if (includeDisabledRenderer is false)
            {
                if (targeting.IsEnable(r) is false) { return false; }
                if (targeting.IsActive(r.gameObject) is false) { return false; }
            }
            return true;
        }
        internal static List<Renderer> GetAtlasAllowedRenderers(IRendererTargeting targeting, IEnumerable<Renderer> domainRenderers, bool includeDisabledRenderer)
        {
            return domainRenderers.Where(i => IsAtlasAllowedRenderer(i))
            // ここでターゲットにならないレンダラーを弾いておかないと アトラス化対象に結局ならないマテリアリガー targetMaterials に混じってしまう。
            .Where(r => CheckRendererActive(targeting, r, includeDisabledRenderer)).ToList();
        }
        internal static bool IsAtlasAllowedRenderer(Renderer item)
        {
            if (item.tag == "EditorOnly") return false;
            if (item.GetMesh() == null) return false;
            if (item.GetMesh().uv.Any() == false) return false;
            if (item.sharedMaterials.Length == 0) return false;
            if (item.GetComponent<AtlasExcludeTag>() != null) return false;

            return true;
        }
        internal override IEnumerable<Renderer> ModificationTargetRenderers(IRendererTargeting rendererTargeting)
        {
            var isIncludeDisable = rendererTargeting.LookAtGet(this, a => a.AtlasSetting.IncludeDisabledRenderer);
            var selectedMaterials = rendererTargeting.LookAtGet(this, at => at.AtlasTargetMaterials.ToArray(), (l, r) => l.SequenceEqual(r));
            var nowRenderers = GetAtlasAllowedRenderers(rendererTargeting, rendererTargeting.EnumerateRenderer(), isIncludeDisable);

            var nowContainsMatSet = new HashSet<Material>(
                    nowRenderers
                        .SelectMany(r => rendererTargeting.GetMaterials(r))
                        .UOfType<Material>()
                );
            var targetMaterials = nowContainsMatSet.Where(mat => selectedMaterials.Any(sMat => rendererTargeting.OriginEqual(sMat, mat))).ToHashSet();

            return FilterTargetRenderers(rendererTargeting, nowRenderers, targetMaterials);

        }



    }
}
