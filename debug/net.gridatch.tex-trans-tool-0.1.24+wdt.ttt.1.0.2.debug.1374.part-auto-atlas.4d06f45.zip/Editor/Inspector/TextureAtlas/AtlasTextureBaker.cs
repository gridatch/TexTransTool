#nullable enable
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using net.rs64.TexTransCore;
using net.rs64.TexTransTool.Utils;
using net.rs64.TexTransCoreEngineForUnity;
using net.rs64.TexTransTool.Editor.OtherMenuItem;
using UnityEditor;
using UnityEngine;

namespace net.rs64.TexTransTool.TextureAtlas.Editor
{
    internal static class AtlasTextureBaker
    {
        internal static bool Bake(AtlasTexture atlasTexture)
        {
            PreviewUtility.ExitPreviews();

            var bakeName = atlasTexture.BakeName ?? "";
            if (TryValidateBakeName(bakeName, out var bakeNameError) is false)
            {
                EditorUtility.DisplayDialog("TexTransTool", bakeNameError, "OK");
                return false;
            }

            var domainRoot = DomainMarkerFinder.FindMarker(atlasTexture.gameObject);
            if (domainRoot == null)
            {
                Debug.LogError("TexTransTool: AtlasTexture domain root was not found.");
                return false;
            }

            using var resolveDomain = new NotWorkDomain(
                domainRoot.GetComponentsInChildren<Renderer>(true),
                null
            );
            var (targetMaterials, targetRenderers) =
                AtlasTextureBakeTargetResolver.ResolveBakeTargets(atlasTexture, resolveDomain);

            return BakeResolved(
                PersistentAtlasBakeSettings.FromComponent(atlasTexture),
                domainRoot,
                targetMaterials,
                targetRenderers,
                bakeName,
                GetBakeOutputAssetPath(bakeName),
                promptOverwrite: true,
                pingOutputFolder: true
            );
        }

        /// <summary>
        /// Runs the persistent Atlas bake against an explicitly supplied domain and target set.
        /// This is the reusable boundary used by workflows that operate on temporary/extracted
        /// hierarchies rather than the AtlasTexture component's normal avatar domain.
        /// </summary>
        internal static bool BakeResolved(
            PersistentAtlasBakeSettings settings,
            GameObject domainRoot,
            HashSet<Material> targetMaterials,
            Renderer[] targetRenderers,
            string bakeName,
            string outputAssetPath,
            bool promptOverwrite,
            bool pingOutputFolder,
            bool recordUndo = true)
        {
            PreviewUtility.ExitPreviews();

            if (settings == null)
            {
                Debug.LogError("TexTransTool: persistent Atlas bake settings are null.");
                return false;
            }

            if (domainRoot == null)
            {
                Debug.LogError("TexTransTool: AtlasTexture bake domain root is null.");
                return false;
            }

            if (targetMaterials == null || targetRenderers == null)
            {
                Debug.LogError("TexTransTool: AtlasTexture bake target set is null.");
                return false;
            }

            if (TryValidateBakeName(bakeName, out var bakeNameError) is false)
            {
                EditorUtility.DisplayDialog("TexTransTool", bakeNameError, "OK");
                return false;
            }

            if (TryValidateOutputAssetPath(outputAssetPath, out var outputPathError) is false)
            {
                Debug.LogError("TexTransTool: " + outputPathError);
                EditorUtility.DisplayDialog("TexTransTool", outputPathError, "OK");
                return false;
            }

            var manifestAssetPath = outputAssetPath + "/BakeManifest.asset";
            var outputExists = Directory.Exists(AssetPathToFullPath(outputAssetPath));

            AtlasTextureBakeManifest? manifest = null;
            AtlasTextureBakeManifest.Entry[] previousEntries = Array.Empty<AtlasTextureBakeManifest.Entry>();

            if (outputExists)
            {
                if (promptOverwrite
                    && EditorUtility.DisplayDialog(
                        "TexTransTool",
                        $"ベイク名「{bakeName}」は既に存在します。上書きしますか？",
                        "上書き",
                        "キャンセル"
                    ) is false)
                {
                    return false;
                }

                manifest = AssetDatabase.LoadAssetAtPath<AtlasTextureBakeManifest>(manifestAssetPath);
                if (manifest == null)
                {
                    EditorUtility.DisplayDialog(
                        "TexTransTool",
                        $"出力先「{outputAssetPath}」の管理情報が見つからないため、安全に上書きできません。",
                        "OK"
                    );
                    return false;
                }

                if (manifest.Version != AtlasTextureBakeManifest.CurrentVersion)
                {
                    EditorUtility.DisplayDialog(
                        "TexTransTool",
                        "BakeManifestのVersionが現在の形式と一致しないため、安全に上書きできません。"
                        + "\n"
                        + $"Manifest: {manifest.Version}, Current: {AtlasTextureBakeManifest.CurrentVersion}",
                        "OK"
                    );
                    return false;
                }

                previousEntries = manifest.Entries
                    .Where(entry =>
                        entry != null
                        && string.IsNullOrEmpty(entry.Role) is false
                        && string.IsNullOrEmpty(entry.AssetPath) is false
                    )
                    .Select(entry => new AtlasTextureBakeManifest.Entry
                    {
                        Role = entry.Role,
                        AssetPath = entry.AssetPath,
                    })
                    .ToArray();

                var invalidManagedEntry = previousEntries.FirstOrDefault(entry =>
                    IsPathInside(entry.AssetPath, outputAssetPath) is false
                );
                if (invalidManagedEntry != null)
                {
                    EditorUtility.DisplayDialog(
                        "TexTransTool",
                        "BakeManifestに出力フォルダ外のAssetが登録されているため、安全に上書きできません。"
                        + "\n"
                        + invalidManagedEntry.AssetPath,
                        "OK"
                    );
                    return false;
                }
            }

            var previousRoleAssets = previousEntries
                .GroupBy(entry => entry.Role)
                .ToDictionary(group => group.Key, group => group.Last().AssetPath);

            var textureAssetPath = outputAssetPath + "/Textures";
            var materialAssetPath = outputAssetPath + "/Materials";
            var meshAssetPath = outputAssetPath + "/Meshes";

            using var diskUtil = new UnityDiskUtil(false);
            var engine = new TTCEUnityWithTTT4Unity(diskUtil);

            try
            {
                using var domain = new NotWorkDomain(
                    domainRoot.GetComponentsInChildren<Renderer>(true),
                    engine
                );

                if (targetMaterials.Count == 0 || targetRenderers.Length == 0)
                {
                    Debug.LogWarning("TexTransTool: No AtlasTexture bake target was found.");
                    return false;
                }

                var domainRendererSet = domainRoot
                    .GetComponentsInChildren<Renderer>(true)
                    .ToHashSet();

                if (targetRenderers.Any(renderer => renderer == null || domainRendererSet.Contains(renderer) is false))
                {
                    Debug.LogError("TexTransTool: AtlasTexture bake targets include a renderer outside the supplied domain.");
                    return false;
                }

                var targetMeshes = targetRenderers
                    .Select(renderer => ((IRendererTargeting)domain).GetMesh(renderer))
                    .Where(mesh => mesh != null)
                    .Cast<Mesh>()
                    .ToHashSet();
                var targetTextures = GetAtlasSourceTextures(
                    targetMaterials,
                    settings.AtlasSetting.AtlasTargetUVChannel
                );

                if (ValidateAnimationObjectReferences(
                        domainRoot,
                        targetRenderers,
                        targetMaterials,
                        targetMeshes,
                        targetTextures
                    ) is false)
                {
                    return false;
                }

                var atlasResult = AtlasTexture.DoAtlasTexture(
                    domain,
                    engine,
                    targetMaterials,
                    targetRenderers,
                    settings.IslandSizePriorityTuner,
                    settings.AtlasSetting
                );

                if (atlasResult.IsSuccess is false) { return false; }

                using var atlasContext = atlasResult.AtlasContext!;
                var atlasedMeshes = atlasResult.AtlasedMeshes!;
                var compiledAtlasTextures = atlasResult.CompiledAtlasTextures!;

                var rendererMeshMap = BuildRendererMeshMap(domain, targetRenderers, atlasContext, atlasedMeshes);
                if (ValidateMeshCompatibility(domain, rendererMeshMap, targetRenderers.Length) is false)
                {
                    return false;
                }

                var experimentalOptions = settings.ExperimentalOptions;
                if (experimentalOptions == null) { experimentalOptions = null; }

                var tunedAtlasTextures = AtlasTexture.DoTextureFinTuning(
                    engine,
                    atlasContext,
                    settings.AtlasSetting,
                    compiledAtlasTextures,
                    experimentalOptions
                );

                var allRenderTextures = compiledAtlasTextures.Values
                    .Concat(tunedAtlasTextures.RenderTextures.Values)
                    .Concat(tunedAtlasTextures.TextureDescriptors.Keys)
                    .Distinct()
                    .ToArray();

                var temporaryDownloadedTextures = new List<Texture2D>();
                var generatedMaterials = new List<Material>();
                var currentEntries = new List<AtlasTextureBakeManifest.Entry>();

                using var outputTransaction = new BakeOutputTransaction(
                    outputAssetPath,
                    outputExists
                );

                Directory.CreateDirectory(AssetPathToFullPath(textureAssetPath));
                Directory.CreateDirectory(AssetPathToFullPath(materialAssetPath));
                Directory.CreateDirectory(AssetPathToFullPath(meshAssetPath));
                AssetDatabase.Refresh();

                try
                {
                    var persistentTextures = SaveTextures(
                        engine,
                        tunedAtlasTextures,
                        targetMaterials,
                        bakeName,
                        outputAssetPath,
                        textureAssetPath,
                        previousRoleAssets,
                        currentEntries,
                        temporaryDownloadedTextures
                    );

                    var (materialMap, _) = AtlasTexture.GenerateAtlasedMaterialMaps(
                        domain,
                        targetMaterials,
                        settings.AtlasSetting,
                        (
                            settings.MergeMaterialGroups,
                            settings.AllMaterialMergeReference,
                            experimentalOptions
                        ),
                        persistentTextures,
                        atlasResult.PreserveBump2ndMaterials,
                        atlasResult.PreservedOriginalUVChannel
                    );

                    generatedMaterials.AddRange(materialMap.Values.Distinct());

                    var persistentMaterialMap = SaveMaterials(
                        materialMap,
                        domainRoot,
                        domain,
                        bakeName,
                        outputAssetPath,
                        materialAssetPath,
                        previousRoleAssets,
                        currentEntries
                    );

                    var persistentRendererMeshMap = SaveMeshes(
                        domainRoot,
                        rendererMeshMap,
                        bakeName,
                        outputAssetPath,
                        meshAssetPath,
                        previousRoleAssets,
                        currentEntries
                    );

                    DeleteStaleManagedAssets(
                        previousEntries,
                        currentEntries,
                        outputAssetPath
                    );
                    manifest = SaveManifest(
                        manifest,
                        manifestAssetPath,
                        bakeName,
                        currentEntries
                    );

                    AssetDatabase.SaveAssets();
                    AssetDatabase.Refresh();

                    var rendererState = CaptureRendererState(targetRenderers);
                    try
                    {
                        ApplyBakedAtlas(
                            domainRoot,
                            targetRenderers,
                            persistentRendererMeshMap,
                            persistentMaterialMap,
                            recordUndo
                        );
                    }
                    catch
                    {
                        RestoreRendererState(rendererState);
                        throw;
                    }

                    outputTransaction.Commit();

                    if (pingOutputFolder)
                    {
                        var folderAsset = AssetDatabase.LoadAssetAtPath<DefaultAsset>(outputAssetPath);
                        if (folderAsset != null)
                        {
                            Selection.activeObject = folderAsset;
                            EditorGUIUtility.PingObject(folderAsset);
                        }
                    }

                    Debug.Log(
                        $"TexTransTool: Atlas baked to persistent assets and applied at {outputAssetPath} " +
                        $"({persistentTextures.Values.Distinct().Count()} textures, " +
                        $"{persistentMaterialMap.Values.Distinct().Count()} materials, " +
                        $"{persistentRendererMeshMap.Values.Distinct().Count()} meshes)."
                    );
                }
                finally
                {
                    foreach (var texture in temporaryDownloadedTextures)
                    {
                        if (texture != null) UnityEngine.Object.DestroyImmediate(texture);
                    }

                    foreach (var material in generatedMaterials)
                    {
                        if (material != null && AssetDatabase.Contains(material) is false)
                            UnityEngine.Object.DestroyImmediate(material);
                    }

                    foreach (var mesh in atlasedMeshes)
                    {
                        if (mesh != null && AssetDatabase.Contains(mesh) is false)
                            UnityEngine.Object.DestroyImmediate(mesh);
                    }

                    foreach (var rt in allRenderTextures)
                    {
                        rt.Dispose();
                    }
                }
            }
            finally
            {
                if (engine is IDisposable disposableEngine) disposableEngine.Dispose();
            }

            return true;
        }

        private static Dictionary<Renderer, Mesh> BuildRendererMeshMap(
            IDomain domain,
            Renderer[] targetRenderers,
            AtlasContext atlasContext,
            Mesh[] atlasedMeshes)
        {
            var rendererMeshMap = new Dictionary<Renderer, Mesh>();

            foreach (var renderer in targetRenderers)
            {
                var resolved = AtlasTexture.ResolveAtlasedMeshForRenderer(
                    domain, renderer, atlasContext, atlasedMeshes);
                if (resolved is not { } meshPair) { continue; }
                rendererMeshMap[renderer] = meshPair.atlasMesh;
            }

            return rendererMeshMap;
        }

        private static bool ValidateMeshCompatibility(
            IDomain domain,
            IReadOnlyDictionary<Renderer, Mesh> rendererMeshMap,
            int expectedRendererCount)
        {
            if (rendererMeshMap.Count != expectedRendererCount)
            {
                Debug.LogError(
                    $"TexTransTool: Atlas bake aborted because only {rendererMeshMap.Count} of {expectedRendererCount} target renderers received an atlas mesh."
                );
                return false;
            }

            foreach (var pair in rendererMeshMap)
            {
                var sourceMesh = domain.GetMesh(pair.Key);
                if (sourceMesh == null) { continue; }

                if (!ValidateReplacementMeshCompatibility(
                        pair.Key,
                        sourceMesh,
                        pair.Value))
                {
                    return false;
                }
            }

            return true;
        }

        internal static bool ValidateReplacementMeshCompatibility(
            Renderer renderer,
            Mesh sourceMesh,
            Mesh replacementMesh)
        {
            if (sourceMesh.blendShapeCount != replacementMesh.blendShapeCount)
            {
                Debug.LogError(
                    $"TexTransTool: Atlas bake aborted because blend shape count changed on {renderer.name}."
                );
                return false;
            }

            for (var shapeIndex = 0; shapeIndex < sourceMesh.blendShapeCount; shapeIndex += 1)
            {
                if (sourceMesh.GetBlendShapeName(shapeIndex)
                    != replacementMesh.GetBlendShapeName(shapeIndex))
                {
                    Debug.LogError(
                        $"TexTransTool: Atlas bake aborted because blend shape order/name changed on {renderer.name}."
                    );
                    return false;
                }

                var sourceFrameCount =
                    sourceMesh.GetBlendShapeFrameCount(shapeIndex);
                var replacementFrameCount =
                    replacementMesh.GetBlendShapeFrameCount(shapeIndex);
                if (sourceFrameCount != replacementFrameCount)
                {
                    Debug.LogError(
                        $"TexTransTool: Atlas bake aborted because blend shape frame count changed on {renderer.name}."
                    );
                    return false;
                }

                for (var frameIndex = 0; frameIndex < sourceFrameCount; frameIndex += 1)
                {
                    if (Mathf.Approximately(
                            sourceMesh.GetBlendShapeFrameWeight(
                                shapeIndex, frameIndex),
                            replacementMesh.GetBlendShapeFrameWeight(
                                shapeIndex, frameIndex))
                        is false)
                    {
                        Debug.LogError(
                            $"TexTransTool: Atlas bake aborted because blend shape frame weights changed on {renderer.name}."
                        );
                        return false;
                    }
                }
            }

            if (renderer is SkinnedMeshRenderer
                && sourceMesh.bindposes.Length != replacementMesh.bindposes.Length)
            {
                Debug.LogError(
                    $"TexTransTool: Atlas bake aborted because bindpose count changed on {renderer.name}."
                );
                return false;
            }

            return true;
        }

        internal static HashSet<Texture> GetAtlasSourceTextures(
            HashSet<Material> targetMaterials,
            UVChannel atlasTargetUVChannel)
        {
            if (targetMaterials.Count == 0)
                return new HashSet<Texture>();

            var grouping = new MaterialGroupingContext(
                targetMaterials,
                atlasTargetUVChannel,
                primaryTexturePropertyOrMaximum: null
            );

            return grouping.ContainsTextureDictionaries.Values
                .SelectMany(properties => properties.Values)
                .Where(texture => texture != null)
                .ToHashSet();
        }

        internal sealed class AnimationObjectReferenceHit
        {
            internal AnimationClip Clip = null!;
            internal EditorCurveBinding Binding;
            internal UnityEngine.Object ReferencedAsset = null!;
            internal Renderer[] TargetRenderers = Array.Empty<Renderer>();
        }

        internal static AnimationObjectReferenceHit[] CollectAnimationObjectReferences(
            GameObject domainRoot,
            IEnumerable<Renderer> targetRenderers)
        {
            var renderers = targetRenderers
                .Where(renderer => renderer != null)
                .Distinct()
                .ToArray();
            var hits = new List<AnimationObjectReferenceHit>();
            var dependencies = EditorUtility.CollectDependencies(
                new UnityEngine.Object[] { domainRoot });

            foreach (var clip in dependencies.OfType<AnimationClip>().Distinct())
            {
                foreach (var binding in
                         AnimationUtility.GetObjectReferenceCurveBindings(clip))
                {
                    var bindingTargets = ResolveBindingTargetRenderers(
                        domainRoot,
                        binding,
                        renderers);
                    if (bindingTargets.Length == 0)
                        continue;

                    foreach (var frame in
                             AnimationUtility.GetObjectReferenceCurve(
                                 clip, binding))
                    {
                        if (frame.value is not Material
                            && frame.value is not Mesh
                            && frame.value is not Texture)
                        {
                            continue;
                        }

                        hits.Add(new AnimationObjectReferenceHit
                        {
                            Clip = clip,
                            Binding = binding,
                            ReferencedAsset = frame.value,
                            TargetRenderers = bindingTargets,
                        });
                    }
                }
            }

            return hits.ToArray();
        }

        internal static bool ValidateAnimationObjectReferences(
            GameObject domainRoot,
            Renderer[] targetRenderers,
            HashSet<Material> targetMaterials,
            HashSet<Mesh> targetMeshes,
            HashSet<Texture>? targetTextures = null,
            bool displayDialog = true)
        {
            var hits = CollectAnimationObjectReferences(
                    domainRoot,
                    targetRenderers)
                .Where(hit =>
                    hit.ReferencedAsset is Material material
                        && targetMaterials.Contains(material)
                    || hit.ReferencedAsset is Mesh mesh
                        && targetMeshes.Contains(mesh)
                    || hit.ReferencedAsset is Texture texture
                        && targetTextures != null
                        && targetTextures.Contains(texture))
                .GroupBy(hit => (
                    hit.Clip,
                    hit.Binding.path,
                    hit.Binding.propertyName,
                    hit.Binding.type))
                .Select(group => group.First())
                .ToArray();

            return ValidateAnimationObjectReferenceHits(
                hits,
                displayDialog);
        }

        internal static bool ValidateAnimationObjectReferenceHits(
            IEnumerable<AnimationObjectReferenceHit> hits,
            bool displayDialog = true)
        {
            var uniqueHits = hits
                .Where(hit =>
                    hit != null
                    && hit.Clip != null
                    && hit.ReferencedAsset != null)
                .GroupBy(hit => (
                    hit.Clip,
                    hit.Binding.path,
                    hit.Binding.propertyName,
                    hit.Binding.type,
                    hit.ReferencedAsset))
                .Select(group => group.First())
                .ToArray();

            if (uniqueHits.Length == 0) { return true; }

            var messages = uniqueHits
                .Select(hit =>
                    $"{hit.Clip.name}: {hit.Binding.path} / " +
                    $"{hit.Binding.propertyName} -> " +
                    $"{hit.ReferencedAsset.GetType().Name} " +
                    $"{hit.ReferencedAsset.name}")
                .ToArray();
            var detail = string.Join("\n", messages.Take(20));
            if (messages.Length > 20)
                detail += $"\n... and {messages.Length - 20} more";

            Debug.LogError(
                "TexTransTool: Atlas bake was aborted because AnimationClip object-reference curves " +
                "directly restore one or more source Mesh/Material/Texture assets.\n" + detail
            );

            if (displayDialog)
            {
                EditorUtility.DisplayDialog(
                    "TexTransTool",
                    "アトラス化のベイクを中断しました。\n\n" +
                    "ベイク前の Mesh / Material / Texture を直接参照する AnimationClip が見つかりました。\n" +
                    "このままベイクすると、アニメーション再生時に旧アセットへ戻る可能性があります。\n\n" +
                    "Console に該当 Clip / binding を出力しています。",
                    "OK"
                );
            }

            return false;
        }

        private static Renderer[] ResolveBindingTargetRenderers(
            GameObject domainRoot,
            EditorCurveBinding binding,
            Renderer[] targetRenderers)
        {
            bool PathMatches(Renderer renderer)
            {
                return string.Equals(
                    AnimationUtility.CalculateTransformPath(
                        renderer.transform,
                        domainRoot.transform),
                    binding.path,
                    StringComparison.Ordinal);
            }

            if (binding.type == typeof(MeshFilter))
            {
                return targetRenderers
                    .OfType<MeshRenderer>()
                    .Where(PathMatches)
                    .Cast<Renderer>()
                    .ToArray();
            }

            if (binding.type == null
                || typeof(Renderer).IsAssignableFrom(binding.type) is false)
            {
                return Array.Empty<Renderer>();
            }

            return targetRenderers
                .Where(renderer =>
                    PathMatches(renderer)
                    && binding.type.IsAssignableFrom(renderer.GetType()))
                .ToArray();
        }

        internal sealed class RendererBakeState
        {
            internal Renderer Renderer = null!;
            internal Mesh? Mesh;
            internal Material[] Materials = Array.Empty<Material>();
        }

        internal static RendererBakeState[] CaptureRendererState(
            IEnumerable<Renderer> renderers)
        {
            return renderers
                .Where(renderer => renderer != null)
                .Select(renderer => new RendererBakeState
                {
                    Renderer = renderer,
                    Mesh = renderer switch
                    {
                        SkinnedMeshRenderer skinned => skinned.sharedMesh,
                        MeshRenderer => renderer.GetComponent<MeshFilter>()?.sharedMesh,
                        _ => null,
                    },
                    Materials = renderer.sharedMaterials.ToArray(),
                })
                .ToArray();
        }

        private static void RestoreRendererState(
            IEnumerable<RendererBakeState> states)
        {
            foreach (var state in states)
            {
                var renderer = state.Renderer;
                if (renderer == null) continue;

                switch (renderer)
                {
                    case SkinnedMeshRenderer skinned:
                        skinned.sharedMesh = state.Mesh;
                        EditorUtility.SetDirty(skinned);
                        break;

                    case MeshRenderer:
                        var meshFilter = renderer.GetComponent<MeshFilter>();
                        if (meshFilter != null)
                        {
                            meshFilter.sharedMesh = state.Mesh;
                            EditorUtility.SetDirty(meshFilter);
                            if (PrefabUtility.IsPartOfPrefabInstance(meshFilter))
                                PrefabUtility.RecordPrefabInstancePropertyModifications(meshFilter);
                        }
                        break;
                }

                renderer.sharedMaterials = state.Materials;
                EditorUtility.SetDirty(renderer);

                if (PrefabUtility.IsPartOfPrefabInstance(renderer))
                    PrefabUtility.RecordPrefabInstancePropertyModifications(renderer);
            }
        }

        private static void ApplyBakedAtlas(
            GameObject domainRoot,
            Renderer[] targetRenderers,
            IReadOnlyDictionary<Renderer, Mesh> rendererMeshMap,
            IReadOnlyDictionary<Material, Material> materialMap,
            bool recordUndo)
        {
            if (recordUndo)
            {
                var undoObjects = new HashSet<UnityEngine.Object>();

                foreach (var renderer in targetRenderers)
                {
                    if (renderer == null) { continue; }

                    undoObjects.Add(renderer);

                    if (renderer is MeshRenderer)
                    {
                        var meshFilter = renderer.GetComponent<MeshFilter>();
                        if (meshFilter != null) undoObjects.Add(meshFilter);
                    }
                }

                if (undoObjects.Count != 0)
                {
                    Undo.RecordObjects(
                        undoObjects.ToArray(),
                        "TexTransTool: アトラス化をベイク"
                    );
                }
            }

            foreach (var renderer in targetRenderers)
            {
                if (renderer == null) { continue; }

                if (rendererMeshMap.TryGetValue(renderer, out var atlasMesh))
                {
                    switch (renderer)
                    {
                        case SkinnedMeshRenderer skinnedMeshRenderer:
                            skinnedMeshRenderer.sharedMesh = atlasMesh;
                            EditorUtility.SetDirty(skinnedMeshRenderer);
                            RecordPrefabOverride(skinnedMeshRenderer);
                            break;

                        case MeshRenderer _:
                            var meshFilter = renderer.GetComponent<MeshFilter>();
                            if (meshFilter != null)
                            {
                                meshFilter.sharedMesh = atlasMesh;
                                EditorUtility.SetDirty(meshFilter);
                                RecordPrefabOverride(meshFilter);
                            }
                            break;
                    }
                }

                var currentMaterials = renderer.sharedMaterials;
                renderer.sharedMaterials = currentMaterials
                    .Select(material =>
                        material != null && materialMap.TryGetValue(material, out var replacement)
                            ? replacement
                            : material
                    )
                    .ToArray();

                EditorUtility.SetDirty(renderer);
                RecordPrefabOverride(renderer);
            }

            if (domainRoot.scene.IsValid())
                UnityEditor.SceneManagement.EditorSceneManager.MarkSceneDirty(domainRoot.scene);

            static void RecordPrefabOverride(UnityEngine.Object obj)
            {
                if (PrefabUtility.IsPartOfPrefabInstance(obj))
                    PrefabUtility.RecordPrefabInstancePropertyModifications(obj);
            }
        }

        private sealed class BakeOutputTransaction : IDisposable
        {
            private readonly string _assetPath;
            private readonly string _fullPath;
            private readonly string _metaPath;
            private readonly string _backupRoot;
            private readonly string _backupContentPath;
            private readonly string _backupMetaPath;
            private readonly bool _hadOriginal;
            private bool _committed;
            private bool _disposed;

            internal BakeOutputTransaction(
                string assetPath,
                bool hadOriginal)
            {
                _assetPath = assetPath;
                _fullPath = AssetPathToFullPath(assetPath)
                    .TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
                _metaPath = _fullPath + ".meta";
                _hadOriginal = hadOriginal;

                _backupRoot = Path.Combine(
                    Path.GetTempPath(),
                    "TexTransTool-AtlasBake-" + Guid.NewGuid().ToString("N")
                );
                _backupContentPath = Path.Combine(_backupRoot, "content");
                _backupMetaPath = Path.Combine(_backupRoot, "folder.meta");

                if (!_hadOriginal) return;

                if (!Directory.Exists(_fullPath))
                {
                    throw new DirectoryNotFoundException(
                        "Atlas bake output folder disappeared before backup: "
                        + _assetPath
                    );
                }

                Directory.CreateDirectory(_backupRoot);
                CopyDirectory(_fullPath, _backupContentPath);

                if (File.Exists(_metaPath))
                    File.Copy(_metaPath, _backupMetaPath, overwrite: true);
            }

            internal void Commit()
            {
                _committed = true;
            }

            public void Dispose()
            {
                if (_disposed) return;
                _disposed = true;

                try
                {
                    if (!_committed)
                        Rollback();
                }
                finally
                {
                    if (Directory.Exists(_backupRoot))
                    {
                        try
                        {
                            Directory.Delete(_backupRoot, recursive: true);
                        }
                        catch (Exception e)
                        {
                            Debug.LogWarning(
                                "TexTransTool: Failed to remove temporary Atlas bake backup: "
                                + e.Message
                            );
                        }
                    }
                }
            }

            private void Rollback()
            {
                try
                {
                    if (AssetDatabase.IsValidFolder(_assetPath))
                        AssetDatabase.DeleteAsset(_assetPath);

                    // DeleteAsset can fail (for example because of file permissions).
                    // Never restore by overlaying the backup: extra files created by the
                    // failed bake must not survive the rollback.
                    if (Directory.Exists(_fullPath))
                        Directory.Delete(_fullPath, recursive: true);

                    if (File.Exists(_metaPath))
                        File.Delete(_metaPath);

                    if (_hadOriginal)
                    {
                        CopyDirectory(_backupContentPath, _fullPath);
                        if (File.Exists(_backupMetaPath))
                            File.Copy(_backupMetaPath, _metaPath, overwrite: true);
                    }

                    AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);
                    Debug.LogWarning(
                        "TexTransTool: Atlas bake failed; persistent output assets were restored."
                    );
                }
                catch (Exception e)
                {
                    Debug.LogError(
                        "TexTransTool: Atlas bake rollback failed. "
                        + "The output folder may require manual recovery.\n"
                        + e
                    );
                }
            }

            private static void CopyDirectory(string source, string destination)
            {
                Directory.CreateDirectory(destination);

                foreach (var directory in Directory.GetDirectories(
                             source,
                             "*",
                             SearchOption.AllDirectories))
                {
                    var relative = directory.Substring(source.Length)
                        .TrimStart(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
                    Directory.CreateDirectory(Path.Combine(destination, relative));
                }

                foreach (var file in Directory.GetFiles(
                             source,
                             "*",
                             SearchOption.AllDirectories))
                {
                    var relative = file.Substring(source.Length)
                        .TrimStart(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
                    var destinationFile = Path.Combine(destination, relative);
                    Directory.CreateDirectory(Path.GetDirectoryName(destinationFile)!);
                    File.Copy(file, destinationFile, overwrite: true);
                }
            }
        }

        private static Dictionary<string, Texture2D> SaveTextures(
            ITexTransToolForUnity engine,
            FineTuning.TexFineTuningResult tunedAtlasTextures,
            IReadOnlyCollection<Material> sourceMaterials,
            string bakeName,
            string outputAssetPath,
            string textureAssetPath,
            IReadOnlyDictionary<string, string> previousRoleAssets,
            List<AtlasTextureBakeManifest.Entry> currentEntries,
            List<Texture2D> temporaryDownloadedTextures)
        {
            var renderTextureToPersistentTexture = new Dictionary<ITTRenderTexture, Texture2D>();

            foreach (var renderTexture in tunedAtlasTextures.RenderTextures.Values.Distinct())
            {
                if (tunedAtlasTextures.TextureDescriptors.TryGetValue(renderTexture, out var descriptor) is false)
                    descriptor = new TexTransToolTextureDescriptor();

                var downloaded = engine.DownloadToTexture2D(
                    renderTexture,
                    descriptor.UseMipMap,
                    null,
                    descriptor.AsLinear
                );
                temporaryDownloadedTextures.Add(downloaded);

                descriptor.WriteFillWarp(downloaded);
                downloaded.Apply(descriptor.UseMipMap, false);

                var propertyNames = tunedAtlasTextures.RenderTextures
                    .Where(kv => ReferenceEquals(kv.Value, renderTexture))
                    .Select(kv => kv.Key)
                    .OrderBy(name => name, StringComparer.Ordinal)
                    .ToArray();

                var role = "Texture:" + string.Join("|", propertyNames);
                var displayProperty = BuildTextureDisplayRole(propertyNames);

                var desiredAssetPath =
                    textureAssetPath + "/" +
                    SanitizeFileName(bakeName + "_" + displayProperty) +
                    ".png";

                var assetPath = ResolveManagedAssetPath(
                    role,
                    desiredAssetPath,
                    ".png",
                    outputAssetPath,
                    previousRoleAssets
                );

                var persistentTexture = SaveTextureAsset(
                    downloaded,
                    descriptor,
                    sourceMaterials,
                    propertyNames,
                    assetPath);

                renderTextureToPersistentTexture[renderTexture] = persistentTexture;
                currentEntries.Add(new AtlasTextureBakeManifest.Entry
                {
                    Role = role,
                    AssetPath = assetPath,
                });
            }

            return tunedAtlasTextures.RenderTextures.ToDictionary(
                kv => kv.Key,
                kv => renderTextureToPersistentTexture[kv.Value]
            );
        }

        internal static Texture2D SaveTextureAsset(
            Texture2D texture,
            TexTransToolTextureDescriptor descriptor,
            IReadOnlyCollection<Material> sourceMaterials,
            IReadOnlyCollection<string> propertyNames,
            string assetPath)
        {
            var pngBytes = ImageConversion.EncodeToPNG(texture);
            File.WriteAllBytes(AssetPathToFullPath(assetPath), pngBytes);
            AssetDatabase.ImportAsset(
                assetPath,
                ImportAssetOptions.ForceSynchronousImport);

            var importAsNormalMap = ShouldImportAsNormalMap(
                descriptor,
                sourceMaterials,
                propertyNames);
            ConfigureTextureImporter(
                assetPath,
                texture,
                descriptor,
                importAsNormalMap);

            var persistentTexture =
                AssetDatabase.LoadAssetAtPath<Texture2D>(assetPath);
            if (persistentTexture == null)
            {
                throw new InvalidOperationException(
                    "Failed to import exported atlas texture: " + assetPath);
            }

            return persistentTexture;
        }

        private static bool ShouldImportAsNormalMap(
            TexTransToolTextureDescriptor descriptor,
            IReadOnlyCollection<Material> sourceMaterials,
            IReadOnlyCollection<string> propertyNames)
        {
            if (descriptor.IsNormalMap)
                return true;

            foreach (var material in sourceMaterials)
            {
                if (material == null) continue;

                foreach (var propertyName in propertyNames)
                {
                    if (string.IsNullOrEmpty(propertyName)
                        || material.HasProperty(propertyName) is false)
                    {
                        continue;
                    }

                    var sourceTexture = material.GetTexture(propertyName);
                    if (sourceTexture != null)
                    {
                        var sourcePath = AssetDatabase.GetAssetPath(sourceTexture);
                        if (string.IsNullOrEmpty(sourcePath) is false
                            && AssetImporter.GetAtPath(sourcePath) is TextureImporter sourceImporter
                            && sourceImporter.textureType == TextureImporterType.NormalMap)
                        {
                            return true;
                        }
                    }

                    var shader = material.shader;
                    if (shader == null) continue;

                    var propertyCount = ShaderUtil.GetPropertyCount(shader);
                    for (var propertyIndex = 0; propertyIndex < propertyCount; propertyIndex++)
                    {
                        if (string.Equals(
                                ShaderUtil.GetPropertyName(shader, propertyIndex),
                                propertyName,
                                StringComparison.Ordinal
                            ) is false)
                        {
                            continue;
                        }

                        if (shader.GetPropertyAttributes(propertyIndex)
                            .Any(attribute =>
                                string.Equals(
                                    attribute,
                                    "Normal",
                                    StringComparison.OrdinalIgnoreCase
                                )))
                        {
                            return true;
                        }

                        break;
                    }
                }
            }

            return false;
        }

        private static void ConfigureTextureImporter(
            string assetPath,
            Texture2D downloaded,
            TexTransToolTextureDescriptor descriptor,
            bool importAsNormalMap)
        {
            if (AssetImporter.GetAtPath(assetPath) is not TextureImporter importer) { return; }

            importer.textureType = importAsNormalMap
                ? TextureImporterType.NormalMap
                : TextureImporterType.Default;
            importer.sRGBTexture = importAsNormalMap is false
                && descriptor.AsLinear is false;
            importer.mipmapEnabled = descriptor.UseMipMap;
            importer.filterMode = descriptor.filterMode;
            importer.anisoLevel = descriptor.anisoLevel;
            importer.mipMapBias = descriptor.mipMapBias;
            importer.wrapModeU = descriptor.wrapModeU;
            importer.wrapModeV = descriptor.wrapModeV;
            importer.wrapModeW = descriptor.wrapModeW;
            importer.npotScale = TextureImporterNPOTScale.None;
            importer.maxTextureSize = Mathf.Clamp(
                Mathf.NextPowerOfTwo(Mathf.Max(downloaded.width, downloaded.height)),
                32,
                8192
            );

            var (textureFormat, compressionQuality) = descriptor.TextureFormat.Get(downloaded);
            importer.compressionQuality = compressionQuality;

            if (descriptor.TextureFormat is TextureCompressionData compressionData)
            {
                importer.textureCompression = compressionData.FormatQualityValue switch
                {
                    FormatQuality.None => TextureImporterCompression.Uncompressed,
                    FormatQuality.Low => TextureImporterCompression.CompressedLQ,
                    FormatQuality.Normal => TextureImporterCompression.Compressed,
                    FormatQuality.High => TextureImporterCompression.CompressedHQ,
                    _ => TextureImporterCompression.Compressed,
                };

                if (compressionData.UseOverride)
                    ApplyExplicitTextureFormat(importer, textureFormat, compressionQuality);
            }
            else
            {
                ApplyExplicitTextureFormat(importer, textureFormat, compressionQuality);
            }

            importer.SaveAndReimport();

            static void ApplyExplicitTextureFormat(
                TextureImporter importer,
                TextureFormat textureFormat,
                int compressionQuality)
            {
                if (Enum.TryParse(textureFormat.ToString(), out TextureImporterFormat importerFormat) is false)
                    return;

                var platformSettings = importer.GetDefaultPlatformTextureSettings();
                platformSettings.maxTextureSize = importer.maxTextureSize;
                platformSettings.compressionQuality = compressionQuality;
                platformSettings.format = importerFormat;
                importer.SetPlatformTextureSettings(platformSettings);
            }
        }

        private static Dictionary<Material, Material> SaveMaterials(
            IReadOnlyDictionary<Material, Material> materialMap,
            GameObject domainRoot,
            IRendererTargeting targeting,
            string bakeName,
            string outputAssetPath,
            string materialAssetPath,
            IReadOnlyDictionary<string, string> previousRoleAssets,
            List<AtlasTextureBakeManifest.Entry> currentEntries)
        {
            var generatedToPersistent = new Dictionary<Material, Material>();

            foreach (var group in materialMap.GroupBy(pair => pair.Value))
            {
                var generatedMaterial = group.Key;
                var sourceKeys = group
                    .Select(pair => GetStableMaterialKey(pair.Key, domainRoot, targeting))
                    .OrderBy(key => key, StringComparer.Ordinal)
                    .ToArray();

                var role = "Material:" + string.Join("|", sourceKeys);
                var desiredAssetPath =
                    materialAssetPath + "/" +
                    SanitizeFileName(bakeName + "_" + generatedMaterial.name) +
                    ".mat";

                var assetPath = ResolveManagedAssetPath(
                    role,
                    desiredAssetPath,
                    ".mat",
                    outputAssetPath,
                    previousRoleAssets
                );

                var assetObjectName = Path.GetFileNameWithoutExtension(assetPath);
                var existingMaterial = AssetDatabase.LoadAssetAtPath<Material>(assetPath);
                Material persistentMaterial;

                if (existingMaterial != null)
                {
                    EditorUtility.CopySerialized(generatedMaterial, existingMaterial);
                    existingMaterial.name = assetObjectName;
                    EditorUtility.SetDirty(existingMaterial);
                    persistentMaterial = existingMaterial;
                }
                else
                {
                    var existingAsset = AssetDatabase.LoadMainAssetAtPath(assetPath);
                    if (existingAsset != null)
                    {
                        throw new InvalidOperationException(
                            $"Cannot update Atlas bake material because another asset exists at {assetPath}."
                        );
                    }

                    generatedMaterial.name = assetObjectName;
                    AssetDatabase.CreateAsset(generatedMaterial, assetPath);
                    persistentMaterial = generatedMaterial;
                }

                generatedToPersistent[generatedMaterial] = persistentMaterial;
                currentEntries.Add(new AtlasTextureBakeManifest.Entry
                {
                    Role = role,
                    AssetPath = assetPath,
                });
            }

            return materialMap.ToDictionary(
                pair => pair.Key,
                pair => generatedToPersistent[pair.Value]
            );
        }

        private static Dictionary<Renderer, Mesh> SaveMeshes(
            GameObject domainRoot,
            IReadOnlyDictionary<Renderer, Mesh> rendererMeshMap,
            string bakeName,
            string outputAssetPath,
            string meshAssetPath,
            IReadOnlyDictionary<string, string> previousRoleAssets,
            List<AtlasTextureBakeManifest.Entry> currentEntries)
        {
            var generatedToPersistent = new Dictionary<Mesh, Mesh>();

            foreach (var group in rendererMeshMap.GroupBy(pair => pair.Value))
            {
                var generatedMesh = group.Key;
                var renderers = group.Select(pair => pair.Key).ToArray();
                var rendererKeys = renderers
                    .Select(renderer => GetStableRendererKey(domainRoot, renderer))
                    .OrderBy(key => key, StringComparer.Ordinal)
                    .ToArray();

                var role = "Mesh:" + string.Join("|", rendererKeys);
                var displayName = renderers.Length == 1
                    ? renderers[0].gameObject.name
                    : generatedMesh.name;

                if (string.IsNullOrWhiteSpace(displayName))
                    displayName = "Mesh";

                var desiredAssetPath =
                    meshAssetPath + "/" +
                    SanitizeFileName(bakeName + "_" + displayName) +
                    ".asset";

                var assetPath = ResolveManagedAssetPath(
                    role,
                    desiredAssetPath,
                    ".asset",
                    outputAssetPath,
                    previousRoleAssets
                );

                var assetObjectName = Path.GetFileNameWithoutExtension(assetPath);
                var existingMesh = AssetDatabase.LoadAssetAtPath<Mesh>(assetPath);
                Mesh persistentMesh;

                if (existingMesh != null)
                {
                    EditorUtility.CopySerialized(generatedMesh, existingMesh);
                    existingMesh.name = assetObjectName;
                    EditorUtility.SetDirty(existingMesh);
                    persistentMesh = existingMesh;
                }
                else
                {
                    var existingAsset = AssetDatabase.LoadMainAssetAtPath(assetPath);
                    if (existingAsset != null)
                    {
                        throw new InvalidOperationException(
                            $"Cannot update Atlas bake mesh because another asset exists at {assetPath}."
                        );
                    }

                    generatedMesh.name = assetObjectName;
                    AssetDatabase.CreateAsset(generatedMesh, assetPath);
                    persistentMesh = generatedMesh;
                }

                generatedToPersistent[generatedMesh] = persistentMesh;
                currentEntries.Add(new AtlasTextureBakeManifest.Entry
                {
                    Role = role,
                    AssetPath = assetPath,
                });
            }

            return rendererMeshMap.ToDictionary(
                pair => pair.Key,
                pair => generatedToPersistent[pair.Value]
            );
        }

        private static AtlasTextureBakeManifest SaveManifest(
            AtlasTextureBakeManifest? manifest,
            string manifestAssetPath,
            string bakeName,
            IEnumerable<AtlasTextureBakeManifest.Entry> entries)
        {
            var isNew = manifest == null;
            manifest ??= ScriptableObject.CreateInstance<AtlasTextureBakeManifest>();

            manifest.name = Path.GetFileNameWithoutExtension(manifestAssetPath);
            manifest.Version = AtlasTextureBakeManifest.CurrentVersion;
            manifest.BakeName = bakeName;
            manifest.Entries = entries
                .OrderBy(entry => entry.Role, StringComparer.Ordinal)
                .Select(entry => new AtlasTextureBakeManifest.Entry
                {
                    Role = entry.Role,
                    AssetPath = entry.AssetPath,
                })
                .ToList();

            if (isNew)
                AssetDatabase.CreateAsset(manifest, manifestAssetPath);
            else
                EditorUtility.SetDirty(manifest);

            return manifest;
        }

        private static void DeleteStaleManagedAssets(
            IEnumerable<AtlasTextureBakeManifest.Entry> previousEntries,
            IEnumerable<AtlasTextureBakeManifest.Entry> currentEntries,
            string outputAssetPath)
        {
            var current = currentEntries.ToArray();
            var currentPaths = new HashSet<string>(
                current.Select(entry => entry.AssetPath),
                StringComparer.Ordinal
            );

            foreach (var previous in previousEntries)
            {
                var matchingRole = current.FirstOrDefault(entry => entry.Role == previous.Role);
                if (matchingRole != null && matchingRole.AssetPath == previous.AssetPath)
                    continue;

                if (currentPaths.Contains(previous.AssetPath))
                    continue;

                if (string.IsNullOrEmpty(previous.AssetPath)
                    || IsPathInside(previous.AssetPath, outputAssetPath) is false)
                {
                    Debug.LogError(
                        "TexTransTool: BakeManifest contained an unmanaged stale asset path; deletion was skipped: "
                        + previous.AssetPath
                    );
                    continue;
                }

                AssetDatabase.DeleteAsset(previous.AssetPath);
            }
        }

        private static string ResolveManagedAssetPath(
            string role,
            string desiredAssetPath,
            string expectedExtension,
            string outputAssetPath,
            IReadOnlyDictionary<string, string> previousRoleAssets)
        {
            if (previousRoleAssets.TryGetValue(role, out var previousAssetPath)
                && IsPathInside(previousAssetPath, outputAssetPath)
                && string.Equals(
                    Path.GetExtension(previousAssetPath),
                    expectedExtension,
                    StringComparison.OrdinalIgnoreCase
                ))
            {
                return previousAssetPath;
            }

            return AssetDatabase.GenerateUniqueAssetPath(desiredAssetPath);
        }

        private static bool IsPathInside(string assetPath, string folderAssetPath)
        {
            var normalizedFolder = folderAssetPath.TrimEnd('/') + "/";
            return assetPath.StartsWith(normalizedFolder, StringComparison.Ordinal);
        }

        private static string GetStableMaterialKey(
            Material material,
            GameObject domainRoot,
            IRendererTargeting targeting)
        {
            if (AssetDatabase.TryGetGUIDAndLocalFileIdentifier(
                    material,
                    out var guid,
                    out long localId
                )
                && string.IsNullOrEmpty(guid) is false)
            {
                return guid + ":" + localId;
            }

            var referenceLocations = targeting.EnumerateRenderer()
                .Where(renderer =>
                    renderer != null
                    && (renderer.transform == domainRoot.transform
                        || renderer.transform.IsChildOf(domainRoot.transform)))
                .SelectMany(renderer =>
                    targeting.GetMaterials(renderer)
                        .Select((candidate, materialIndex) => new
                        {
                            Renderer = renderer,
                            Material = candidate,
                            MaterialIndex = materialIndex,
                        }))
                .Where(entry => ReferenceEquals(entry.Material, material))
                .Select(entry =>
                    HierarchyIdentityUtility.GetRendererKey(
                        domainRoot,
                        entry.Renderer
                    )
                    + "#"
                    + entry.MaterialIndex)
                .OrderBy(location => location, StringComparer.Ordinal)
                .ToArray();

            if (referenceLocations.Length == 0)
            {
                throw new InvalidOperationException(
                    "Cannot create a stable persistent-bake key for non-persistent material '"
                    + material.name
                    + "' because it is not referenced by any renderer in the bake domain."
                );
            }

            return "RendererSlots:" + string.Join("|", referenceLocations);
        }

        private static string GetStableRendererKey(GameObject domainRoot, Renderer renderer)
        {
            return HierarchyIdentityUtility.GetRendererKey(domainRoot, renderer);
        }

        private static readonly IReadOnlyDictionary<string, string> TexturePropertyDisplayRoles =
            new Dictionary<string, string>(StringComparer.Ordinal)
            {
                ["_MainTex"] = "Main",
                ["_BaseMap"] = "Main",
                ["_BaseColorMap"] = "Main",
                ["_Main2ndTex"] = "Main2nd",
                ["_Main3rdTex"] = "Main3rd",
                ["_MainGradationTex"] = "MainGradation",
                ["_MainColorAdjustMask"] = "MainColorAdjustMask",
                ["_Main2ndBlendMask"] = "Main2ndBlendMask",
                ["_Main3rdBlendMask"] = "Main3rdBlendMask",
                ["_Main2ndDissolveMask"] = "Main2ndDissolveMask",
                ["_Main2ndDissolveNoiseMask"] = "Main2ndDissolveNoiseMask",
                ["_Main3rdDissolveMask"] = "Main3rdDissolveMask",
                ["_Main3rdDissolveNoiseMask"] = "Main3rdDissolveNoiseMask",
                ["_AlphaMask"] = "AlphaMask",
                ["_BumpMap"] = "Normal",
                ["_Bump2ndMap"] = "Normal2nd",
                ["_Bump2ndScaleMask"] = "Normal2ndScaleMask",
                ["_AnisotropyTangentMap"] = "AnisotropyTangent",
                ["_AnisotropyScaleMask"] = "AnisotropyScaleMask",
                ["_AnisotropyShiftNoiseMask"] = "AnisotropyShiftNoiseMask",
                ["_BacklightColorTex"] = "BacklightColor",
                ["_ShadowStrengthMask"] = "ShadowStrengthMask",
                ["_ShadowBorderMask"] = "ShadowBorderMask",
                ["_ShadowBlurMask"] = "ShadowBlurMask",
                ["_ShadowColorTex"] = "ShadowColor",
                ["_Shadow2ndColorTex"] = "Shadow2ndColor",
                ["_Shadow3rdColorTex"] = "Shadow3rdColor",
                ["_RimShadeMask"] = "RimShadeMask",
                ["_SmoothnessTex"] = "Smoothness",
                ["_MetallicGlossMap"] = "MetallicGloss",
                ["_ReflectionColorTex"] = "ReflectionColor",
                ["_MatCapTex"] = "MatCap",
                ["_MatCapBlendMask"] = "MatCapBlendMask",
                ["_MatCapBumpMap"] = "MatCapNormal",
                ["_MatCap2ndTex"] = "MatCap2nd",
                ["_MatCap2ndBlendMask"] = "MatCap2ndBlendMask",
                ["_MatCap2ndBumpMap"] = "MatCap2ndNormal",
                ["_RimColorTex"] = "RimColor",
                ["_GlitterColorTex"] = "GlitterColor",
                ["_GlitterShapeTex"] = "GlitterShape",
                ["_EmissionMap"] = "Emission",
                ["_Emission2ndMap"] = "Emission2nd",
                ["_EmissionBlendMask"] = "EmissionBlendMask",
                ["_Emission2ndBlendMask"] = "Emission2ndBlendMask",
                ["_EmissionGradTex"] = "EmissionGrad",
                ["_Emission2ndGradTex"] = "Emission2ndGrad",
                ["_ParallaxMap"] = "Parallax",
                ["_AudioLinkMask"] = "AudioLinkMask",
                ["_OutlineTex"] = "Outline",
                ["_OutlineWidthMask"] = "OutlineWidthMask",
                ["_OutlineVectorTex"] = "OutlineVector",
                ["_OutlineMask"] = "OutlineMask",
                ["_FurNoiseMask"] = "FurNoiseMask",
                ["_FurMask"] = "FurMask",
                ["_FurLengthMask"] = "FurLengthMask",
                ["_FurVectorTex"] = "FurVector",
                ["_DitherTex"] = "Dither",
                ["_DissolveMask"] = "DissolveMask",
                ["_DissolveNoiseMask"] = "DissolveNoiseMask",
                ["_OcclusionMap"] = "Occlusion",
                ["_DetailMask"] = "DetailMask",
                ["_DetailAlbedoMap"] = "DetailAlbedo",
                ["_DetailNormalMap"] = "DetailNormal",
                ["_MetallicMap"] = "Metallic",
                ["_GlossMap"] = "Gloss",
                ["_Matcap"] = "MatCap",
                ["_MatcapMask"] = "MatCapMask",
                ["_Ramp"] = "Ramp",
                ["_HueShiftMask"] = "HueShiftMask",
                ["_ColorMask"] = "ColorMask",
            };

        private static readonly IReadOnlyDictionary<string, int> TextureRoleSortOrder =
            new Dictionary<string, int>(StringComparer.Ordinal)
            {
                ["Main"] = 0,
                ["Main2nd"] = 1,
                ["Main3rd"] = 2,
                ["Normal"] = 10,
                ["Normal2nd"] = 11,
                ["Emission"] = 20,
                ["Emission2nd"] = 21,
                ["MatCap"] = 30,
                ["MatCap2nd"] = 31,
            };

        internal static string BuildTextureDisplayRole(IReadOnlyCollection<string> propertyNames)
        {
            var roles = propertyNames
                .Where(name => string.IsNullOrWhiteSpace(name) is false)
                .Select(NormalizeTexturePropertyDisplayRole)
                .Where(name => string.IsNullOrWhiteSpace(name) is false)
                .Distinct(StringComparer.Ordinal)
                .OrderBy(GetTextureRoleSortOrder)
                .ThenBy(name => name, StringComparer.Ordinal)
                .ToArray();

            if (roles.Length == 0) return "Texture";

            var joined = string.Join("_", roles);
            if (roles.Length <= 4 && joined.Length <= 72)
                return joined;

            var source = string.Join(
                "|",
                propertyNames
                    .Where(name => string.IsNullOrWhiteSpace(name) is false)
                    .OrderBy(name => name, StringComparer.Ordinal)
            );

            return "Shared_"
                + roles[0]
                + "_Plus"
                + (roles.Length - 1)
                + "_"
                + StableShortHash(source);
        }

        private static string NormalizeTexturePropertyDisplayRole(string propertyName)
        {
            if (TexturePropertyDisplayRoles.TryGetValue(propertyName, out var role))
                return role;

            var normalized = propertyName.TrimStart('_');
            return string.IsNullOrEmpty(normalized) ? propertyName : normalized;
        }

        private static int GetTextureRoleSortOrder(string role)
        {
            return TextureRoleSortOrder.TryGetValue(role, out var order) ? order : 1000;
        }

        private static string StableShortHash(string value)
        {
            using var sha256 = SHA256.Create();
            var bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(value));
            var builder = new StringBuilder(8);
            for (var index = 0; index < 4; index++)
                builder.Append(bytes[index].ToString("X2"));
            return builder.ToString();
        }

        internal static bool TryValidateBakeName(string bakeName, out string error)
        {
            if (string.IsNullOrWhiteSpace(bakeName))
            {
                error = "ベイク名を入力してください。";
                return false;
            }

            if (bakeName != bakeName.Trim())
            {
                error = "ベイク名の先頭または末尾に空白は使用できません。";
                return false;
            }

            if (bakeName is "." or "..")
            {
                error = "このベイク名は使用できません。";
                return false;
            }

            var invalidChars = new HashSet<char>(
                Path.GetInvalidFileNameChars()
                    .Concat(new[] { '/', '\\', ':', '*', '?', '"', '<', '>', '|' })
            );

            if (bakeName.Any(invalidChars.Contains) || bakeName.EndsWith(".", StringComparison.Ordinal))
            {
                error = "ベイク名にファイル名として使用できない文字が含まれています。";
                return false;
            }

            if (bakeName.Length > 120)
            {
                error = "ベイク名は120文字以内で入力してください。";
                return false;
            }

            error = "";
            return true;
        }

        private static string GetBakeOutputAssetPath(string bakeName)
        {
            return "Assets/TexTransToolGenerated/AtlasTexture/"
                + bakeName;
        }

        private static bool TryValidateOutputAssetPath(string outputAssetPath, out string error)
        {
            if (string.IsNullOrWhiteSpace(outputAssetPath)
                || outputAssetPath == "Assets"
                || outputAssetPath.StartsWith("Assets/", StringComparison.Ordinal) is false)
            {
                error = "Atlas bake output path must be a folder below Assets/.";
                return false;
            }

            if (outputAssetPath.IndexOfAny(new[] { '\\', ':', '*', '?', '"', '<', '>', '|' }) >= 0)
            {
                error = "Atlas bake output path contains an invalid character.";
                return false;
            }

            error = "";
            return true;
        }

        internal static string AssetPathToFullPath(string assetPath)
        {
            var projectRoot = Directory.GetParent(Application.dataPath)!.FullName;
            return Path.GetFullPath(Path.Combine(projectRoot, assetPath));
        }

        internal static string SanitizeFileName(string name)
        {
            var invalid = Path.GetInvalidFileNameChars();
            var chars = name.Select(c => invalid.Contains(c) || c == '/' || c == '\\' ? '_' : c).ToArray();
            var sanitized = new string(chars).Trim();

            if (string.IsNullOrEmpty(sanitized)) sanitized = "AtlasAsset";
            if (sanitized.Length > 120) sanitized = sanitized.Substring(0, 120);

            return sanitized;
        }
    }
}
