#nullable enable
using System;
using System.Collections.Generic;
using System.Linq;
using nadena.dev.ndmf;
using net.rs64.TexTransCore;
using net.rs64.TexTransCore.UVIsland;
using net.rs64.TexTransTool.TextureAtlas;
using net.rs64.TexTransTool.Editor;
using net.rs64.TexTransTool.TextureAtlas.FineTuning;
using net.rs64.TexTransTool.TextureAtlas.IslandSizePriorityTuner;
using net.rs64.TexTransTool.Utils;
using UnityEngine;

namespace net.rs64.TexTransTool.NDMF
{
    /// <summary>
    /// Runs after regular, explicitly configured AtlasTexture components.
    /// AutoAtlasTexture is deliberately not in the ordinary component phase list.
    /// </summary>
    internal sealed class AutoAtlasTexturePass : TTTPass<AutoAtlasTexturePass>
    {
        protected override void Execute(BuildContext context)
        {
            var configurations = AutoAtlasTextureProcessor.GetActiveConfigurations(
                context.AvatarRootObject);

            if (configurations.Length == 0) return;
            if (configurations.Length != 1)
            {
                Debug.LogWarning("AutoAtlasTexture: 同一アバターに有効な設定が複数あります。二重処理を防ぐため実行しません。");
                return;
            }

            var session = TTTContext(context);
            var manualAtlases = session.PhaseAtList[TexTransPhase.Optimizing]
                .OfType<AtlasTexture>()
                .Where(atlas => TexTransBehaviorSearch.CheckIsActiveBehavior(
                    atlas, context.AvatarRootObject))
                .ToArray();
            AutoAtlasTextureProcessor.Execute(
                session.Domain, context.AvatarRootObject, configurations[0], manualAtlases);
        }
    }

    internal static class AutoAtlasTextureProcessor
    {
        internal static AutoAtlasTexture[] GetActiveConfigurations(GameObject root)
        {
            return root.GetComponentsInChildren<AutoAtlasTexture>(true)
                .Where(component => component != null &&
                    TexTransBehaviorSearch.CheckIsActive(component.gameObject, root))
                .ToArray();
        }

        // This is an upper bound computed before the AAO-specific UV negotiation,
        // not the final atlas selection, which can change during later NDMF phases.
        internal static Renderer[] GetPotentialRenderers(IRendererTargeting domain,
            AutoAtlasTexture configuration)
        {
            var allowed = AtlasTexture.GetAtlasAllowedRenderers(
                    domain, domain.EnumerateRenderer(), includeDisabledRenderer: true)
                .Where(renderer => !configuration.ExcludedRenderers.Any(excluded =>
                    excluded != null && domain.OriginEqual(excluded, renderer)))
                .ToArray();

            // UV0 is the only channel repacked by AutoAtlasTexture. Do not
            // evacuate UVs for renderers whose materials have no compatible
            // textured properties at the time of negotiation.
            var materials = allowed.SelectMany(domain.GetMaterials)
                .UOfType<Material>().ToHashSet();
            if (materials.Count == 0) return Array.Empty<Renderer>();
            var textureUsages = new MaterialGroupingContext(materials, UVChannel.UV0, null);
            var candidates = textureUsages.ContainsTextureDictionaries
                .Where(pair => pair.Value.Count != 0)
                .Select(pair => pair.Key)
                .ToHashSet();
            return allowed.Where(renderer =>
                domain.GetMaterials(renderer).UOfType<Material>().Any(candidates.Contains))
                .ToArray();
        }

        internal static void Execute(IDomain domain, GameObject avatarRoot,
            AutoAtlasTexture configuration, IReadOnlyCollection<AtlasTexture> manualAtlases)
        {
            var report = new AutoAtlasTextureBuildReport { AvatarName = avatarRoot.name };
            // The report is reset for every build, including builds without candidates.
            AutoAtlasTextureReportStore.Set(report);

            string OriginalMaterialName(Material material)
            {
                // Reuse NDMF's object identity; build-stage suffixes are not
                // stripped or guessed from the material name.
                var identity = ObjectRegistry.GetReference(material);
                if (identity?.Object is Material source && source != null) return source.name;
                // ObjectReference snapshots its display name at creation; this
                // remains available even if the original Unity object was destroyed.
                return identity?.ToString() ?? material.name;
            }

            var allRenderers = domain.EnumerateRenderer().Where(renderer => renderer != null).ToArray();
            var allowedRenderers = GetPotentialRenderers(domain, configuration).ToHashSet();

            // Selection is renderer-scoped. Domain.GetAllMaterials() is used
            // separately for safety checks because it also includes animation refs.
            var allMaterials = allRenderers.SelectMany(domain.GetMaterials)
                .UOfType<Material>().ToHashSet();
            // Includes animation material references in the NDMF domain.
            var allReferencedMaterials = domain.GetAllMaterials();
            if (allMaterials.Count == 0)
            {
                TTTLog.ReportingObject(configuration, () =>
                    TTTLog.Info("AutoAtlasTexture:info:NoChanges"));
                return;
            }

            // Material groups follow the textures actually transformed by TTT for UV0,
            // not merely common shaders or all texture references in the material.
            var textureUsages = new MaterialGroupingContext(
                allMaterials, UVChannel.UV0, primaryTexturePropertyOrMaximum: null);
            var propertyTextures = textureUsages.ContainsTextureDictionaries;
            var excludedMaterials = configuration.ExcludedMaterials
                .Where(material => material != null)
                .ToArray();

            // Resolve manual AtlasTexture targets through TTT's existing lookup
            // rather than rescanning hierarchy and comparing raw user selections.
            var manuallySelectedMaterials = manualAtlases
                .SelectMany(atlas => atlas.GetTargetMaterials(domain,
                    AtlasTexture.GetAtlasAllowedRenderers(domain,
                        domain.EnumerateRenderer(), atlas.AtlasSetting.IncludeDisabledRenderer)))
                .ToHashSet();

            var settings = new AtlasSetting
            {
                AutoAtlasTextureSize = true,
                UsePrimaryMaximumTexture = true,
                IncludeDisabledRenderer = true,
                AtlasTargetUVChannel = UVChannel.UV0,
                IslandPadding = Mathf.Clamp(configuration.IslandPadding, 0f, 0.05f),
            };
            // Lossless placement is separate from FineTuning. Do not apply the
            // default 512px resize to non-main textures for this component.
            settings.TextureFineTuning.RemoveAll(tuning => tuning is Resize);

            var maxSize = Mathf.Clamp(configuration.MaxAtlasSize, 256, 4096);
            var groups = MakeTextureConnectedGroups(allMaterials, propertyTextures);
            foreach (var group in groups)
            {
                if (group.Any(material => excludedMaterials.Any(excluded =>
                        domain.OriginEqual(excluded, material)) ||
                    manuallySelectedMaterials.Any(selected =>
                        domain.OriginEqual(selected, material))))
                {
                    continue;
                }

                // Every renderer referencing a material must be transformed together:
                // replacing a shared material while leaving another mesh's UVs intact
                // would corrupt that mesh's appearance.
                var referencingRenderers = allRenderers.Where(renderer =>
                    domain.GetMaterials(renderer).UOfType<Material>().Any(group.Contains)).ToArray();
                if (referencingRenderers.Length == 0 ||
                    referencingRenderers.Any(renderer => !allowedRenderers.Contains(renderer)))
                {
                    continue;
                }

                var atlasRenderers = AtlasTexture.FilterExistUVChannel(
                    domain, referencingRenderers, UVChannel.UV0);
                if (atlasRenderers.Length != referencingRenderers.Length)
                {
                    continue;
                }

                var texturesToReplace = group
                    .SelectMany(material => propertyTextures[material].Values)
                    .Where(texture => texture != null)
                    .ToHashSet();
                if (texturesToReplace.Count == 0)
                {
                    continue;
                }

                // A source texture cannot be removed if it is also referenced by a
                // property outside this atlas operation. The complete source set
                // must be eligible; otherwise generating an additional atlas can
                // increase memory usage.
                if (!ReferencesAreExclusive(
                    allReferencedMaterials, group, propertyTextures, texturesToReplace))
                {
                    continue;
                }

                var originalPixels = texturesToReplace.Sum(texture =>
                    (long)texture.width * texture.height);

                var engine = domain.GetTexTransCoreEngineForUnity();
                var atlasResult = AtlasTexture.DoAtlasTexture(
                    domain,
                    engine,
                    group,
                    atlasRenderers,
                    new List<IIslandSizePriorityTuner?>(),
                    settings,
                    requireLossless: true,
                    maxAtlasSize: maxSize,
                    acceptAtlasSize: (atlasContext, size) =>
                    {
                        var texturePropertyCount =
                            atlasContext.MaterialGroupingCtx.GetContainsAllProperties().Count;
                        if (texturePropertyCount == 0) return false;
                        var outputPixels = (long)size.x * size.y * texturePropertyCount;
                        return outputPixels < originalPixels;
                    },
                    reportProgressInfo: false);

                if (!atlasResult.IsSuccess) continue;

                using var atlasContext = atlasResult.AtlasContext!;
                var compiledTextures = atlasResult.CompiledAtlasTextures!;
                var tuningResult = AtlasTexture.DoTextureFinTuning(
                    engine, atlasContext, settings, compiledTextures, null);
                var resultingTextures = tuningResult.RenderTextures.ToDictionary(
                    item => item.Key,
                    item => engine.GetReferenceRenderTexture(item.Value));
                var retainedRenderTextures = tuningResult.TextureDescriptors.Keys.ToHashSet();

                // Capture immutable names/dimensions while the source references still exist.
                var groupReport = new AutoAtlasTextureGroupReport
                {
                    MaterialNames = group.Select(OriginalMaterialName)
                        .Distinct().OrderBy(name => name, StringComparer.Ordinal).ToArray(),
                    TopFreeFraction = atlasResult.TopFreeFraction ?? 0f,
                    // One row per generated RenderTexture rather than per material
                    // property. ReferenceCopy aliases are therefore shown only once.
                    PropertyChanges = tuningResult.RenderTextures
                        .GroupBy(entry => entry.Value)
                        .OrderBy(entries => entries.Min(entry => entry.Key), StringComparer.Ordinal)
                        .Select(entries => new AutoAtlasTexturePropertyReport
                        {
                            PropertyNames = entries.Select(entry => entry.Key)
                                .OrderBy(name => name, StringComparer.Ordinal)
                                .ToArray(),
                            SourceTextures = entries
                                .SelectMany(entry => group.Select(material =>
                                    propertyTextures[material].TryGetValue(entry.Key, out var texture)
                                        ? texture
                                        : null))
                                .Where(texture => texture != null)
                                .Cast<Texture>()
                                .Distinct()
                                .OrderBy(texture => texture.name, StringComparer.Ordinal)
                                .Select(texture => new AutoAtlasTextureImageReport
                                {
                                    Name = texture.name,
                                    Width = texture.width,
                                    Height = texture.height,
                                })
                                .ToArray(),
                            GeneratedTexture = new AutoAtlasTextureImageReport
                            {
                                Name = entries.Key.Name,
                                Width = entries.Key.Width,
                                Height = entries.Key.Hight,
                            },
                        }).ToArray(),
                    RendererNames = atlasRenderers.Select(renderer =>
                        UnityEditor.AnimationUtility.CalculateTransformPath(
                            renderer.transform, avatarRoot.transform))
                        .OrderBy(name => name).ToArray(),
                    SourceTextures = texturesToReplace
                        .OrderBy(texture => texture.name)
                        .Select(texture => new AutoAtlasTextureImageReport
                        {
                            Name = texture.name,
                            Width = texture.width,
                            Height = texture.height,
                            Properties = string.Join(", ", group.SelectMany(material =>
                                propertyTextures[material]
                                    .Where(item => item.Value == texture)
                                    .Select(item => OriginalMaterialName(material) + "." + item.Key))
                                .Distinct().OrderBy(name => name)),
                        }).ToArray(),
                    GeneratedTextures = tuningResult.RenderTextures
                        .GroupBy(item => item.Value)
                        .Select(entries => new AutoAtlasTextureImageReport
                        {
                            Name = entries.Key.Name,
                            Width = entries.Key.Width,
                            Height = entries.Key.Hight,
                            Properties = string.Join(", ", entries.Select(entry => entry.Key)
                                .OrderBy(name => name)),
                        })
                        .OrderBy(image => image.Name).ToArray(),
                };

                AtlasTexture.ReplaceMesh(
                    domain, atlasRenderers, atlasContext, atlasResult.AtlasedMeshes!);
                AtlasTexture.ReplaceAtlasedMaterials(
                    domain,
                    group,
                    settings,
                    (new List<AtlasTexture.MaterialMergeGroup>(), null, null),
                    resultingTextures,
                    atlasResult.PreserveBump2ndMaterials,
                    atlasResult.PreservedOriginalUVChannel);

                foreach (var rt in compiledTextures.Values)
                    if (!retainedRenderTextures.Contains(rt)) rt.Dispose();

                foreach (var descriptor in tuningResult.TextureDescriptors)
                    domain.RegisterPostProcessingAndLazyGPUReadBack(
                        descriptor.Key, descriptor.Value);

                report.Completed.Add(groupReport);
            }

            LogResults();

            void LogResults()
            {
                // A successful atlas operation is the unit of reporting.
                // No console spam for groups that did not need changing.
                if (report.Completed.Count == 0)
                {
                    TTTLog.ReportingObject(configuration, () =>
                        TTTLog.Info("AutoAtlasTexture:info:NoChanges"));
                    return;
                }

                foreach (var groupReport in report.Completed)
                {
                    var changes = string.Join("\n", groupReport.PropertyChanges.Select(change =>
                    {
                        var before = change.SourceTextures.Length == 0
                            ? "—"
                            : string.Join(" / ", change.SourceTextures
                                .Select(texture => $"{texture.Width}×{texture.Height}")
                                .Distinct());
                        var after = change.GeneratedTexture;
                        var props = string.Join(" / ", change.PropertyNames);
                        return $"  {props}: {before} → {after.Width}×{after.Height}";
                    }));

                    var materialNames = string.Join("\n", groupReport.MaterialNames
                        .Select(name => "  " + name));
                    TTTLog.ReportingObject(configuration, () =>
                        TTTLog.Info("AutoAtlasTexture:info:AppliedGroup",
                            materialNames,
                            changes,
                            (groupReport.TopFreeFraction * 100f).ToString("F1")));
                }
            }
        }

        private static bool ReferencesAreExclusive(
            HashSet<Material> allReferencedMaterials,
            HashSet<Material> group,
            IReadOnlyDictionary<Material, IReadOnlyDictionary<string, Texture>> propertyTextures,
            HashSet<Texture> replacedTextures)
        {
            foreach (var material in allReferencedMaterials)
            {
                var isTarget = group.Contains(material);
                propertyTextures.TryGetValue(material, out var atlasProperties);
                // Reuse TTT's shader-aware property enumeration. The old
                // implementation only saw renderer materials and could overlook
                // materials referenced exclusively by animations.
                foreach (var property in material.GetTextureReferences())
                {
                    if (!replacedTextures.Contains(property.Value)) continue;
                    if (!isTarget || atlasProperties == null ||
                        !atlasProperties.TryGetValue(property.Key, out var atlasTexture) ||
                        atlasTexture != property.Value)
                        return false;
                }
            }
            return true;
        }

        private static List<HashSet<Material>> MakeTextureConnectedGroups(
            HashSet<Material> materials,
            IReadOnlyDictionary<Material, IReadOnlyDictionary<string, Texture>> properties)
        {
            var materialsByTexture = new Dictionary<Texture, HashSet<Material>>();
            foreach (var material in materials)
            {
                foreach (var texture in properties[material].Values)
                {
                    if (texture == null) continue;
                    if (!materialsByTexture.TryGetValue(texture, out var consumers))
                        materialsByTexture[texture] = consumers = new HashSet<Material>();
                    consumers.Add(material);
                }
            }

            var remaining = new HashSet<Material>(materials.Where(material =>
                properties[material].Count != 0));
            var results = new List<HashSet<Material>>();
            while (remaining.Count != 0)
            {
                var seed = remaining.First();
                remaining.Remove(seed);
                var group = new HashSet<Material> { seed };
                var pending = new Queue<Material>();
                pending.Enqueue(seed);

                while (pending.Count != 0)
                {
                    var current = pending.Dequeue();
                    foreach (var texture in properties[current].Values)
                    {
                        if (texture == null) continue;
                        foreach (var adjacent in materialsByTexture[texture])
                        {
                            if (!remaining.Remove(adjacent)) continue;
                            group.Add(adjacent);
                            pending.Enqueue(adjacent);
                        }
                    }
                }
                results.Add(group);
            }
            return results;
        }
    }
}
