#nullable enable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using net.rs64.TexTransCore;

namespace net.rs64.TexTransTool.TextureAtlas
{
    internal readonly struct AtlasResolutionChange
    {
        internal readonly int SourceWidth;
        internal readonly int SourceHeight;
        internal readonly int OutputWidth;
        internal readonly int OutputHeight;
        internal readonly int Count;

        internal AtlasResolutionChange(
            int sourceWidth,
            int sourceHeight,
            int outputWidth,
            int outputHeight,
            int count)
        {
            SourceWidth = sourceWidth;
            SourceHeight = sourceHeight;
            OutputWidth = outputWidth;
            OutputHeight = outputHeight;
            Count = count;
        }
    }

    internal static class AtlasResolutionChangeReport
    {
        private const string ResolutionChangeLocalizationKey =
            "AtlasTexture:info:ResolutionChange";

        internal static AtlasResolutionChange[] Collect(
            MaterialGroupingContext materialGroupingContext,
            IReadOnlyDictionary<string, ITTRenderTexture> outputTextures)
        {
            return materialGroupingContext.ContainsTextureDictionaries
                .SelectMany(material => material.Value
                    .Where(property => outputTextures.ContainsKey(property.Key))
                    .Select(property => new
                    {
                        Source = property.Value,
                        Output = outputTextures[property.Key],
                    }))
                // The same source texture may be referenced by multiple materials or
                // shader properties. Count it only once for each final resolution.
                .GroupBy(entry => (
                    entry.Source,
                    entry.Output.Width,
                    entry.Output.Hight))
                .Select(entries => entries.First())
                .GroupBy(entry => (
                    SourceWidth: entry.Source.width,
                    SourceHeight: entry.Source.height,
                    OutputWidth: entry.Output.Width,
                    OutputHeight: entry.Output.Hight))
                .OrderByDescending(entries =>
                    (long)entries.Key.SourceWidth * entries.Key.SourceHeight)
                .ThenByDescending(entries =>
                    (long)entries.Key.OutputWidth * entries.Key.OutputHeight)
                .Select(entries => new AtlasResolutionChange(
                    entries.Key.SourceWidth,
                    entries.Key.SourceHeight,
                    entries.Key.OutputWidth,
                    entries.Key.OutputHeight,
                    entries.Count()
                ))
                .ToArray();
        }

        internal static FormattableString[] CreateLocalizedLogLines(
            IEnumerable<AtlasResolutionChange> changes)
        {
            return changes.Select(change => FormattableStringFactory.Create(
                ResolutionChangeLocalizationKey,
                new object[]
                {
                    change.SourceWidth,
                    change.SourceHeight,
                    change.OutputWidth,
                    change.OutputHeight,
                    change.Count,
                }
            )).ToArray();
        }
    }
}
