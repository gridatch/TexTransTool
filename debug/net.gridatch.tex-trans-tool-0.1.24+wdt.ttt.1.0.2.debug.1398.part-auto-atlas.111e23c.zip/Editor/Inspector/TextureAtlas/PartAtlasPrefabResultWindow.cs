#nullable enable
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace net.rs64.TexTransTool.TextureAtlas.Editor
{
    internal sealed class PartAtlasPrefabResultWindow : EditorWindow
    {
        private PartAtlasPrefabExecutionSummary? _summary;
        private Vector2 _scroll;

        internal static void ShowResult(
            PartAtlasPrefabExecutionSummary summary)
        {
            var window =
                CreateInstance<PartAtlasPrefabResultWindow>();
            window._summary = summary;
            window.titleContent =
                new GUIContent("Prefab抽出結果");
            window.minSize = new Vector2(560f, 440f);
            window.ShowUtility();
        }

        private void OnGUI()
        {
            if (_summary == null)
            {
                Close();
                return;
            }

            _scroll = EditorGUILayout.BeginScrollView(_scroll);
            DrawSummary(_summary);
            EditorGUILayout.EndScrollView();

            EditorGUILayout.Space(8f);
            using (new EditorGUILayout.HorizontalScope())
            {
                GUILayout.FlexibleSpace();
                if (GUILayout.Button(
                        "閉じる",
                        GUILayout.Width(96f),
                        GUILayout.Height(26f)))
                {
                    Close();
                }
            }
            EditorGUILayout.Space(6f);
        }

        private static void DrawSummary(
            PartAtlasPrefabExecutionSummary summary)
        {
            var extraction = summary.Extraction;

            EditorGUILayout.LabelField(
                "Prefab抽出結果",
                EditorStyles.boldLabel);
            EditorGUILayout.Space(4f);

            DrawValue(
                "日時",
                summary.CompletedAt.ToString("yyyy-MM-dd HH:mm:ss"));
            DrawValue("入力Prefab", extraction.SourceName);
            DrawValue("生成物", extraction.ResultName);
            DrawValue("生成Prefab", extraction.PrefabPath);
            DrawValue("出力フォルダ", extraction.OutputFolder);

            EditorGUILayout.Space(10f);
            DrawSectionTitle("抽出結果");
            DrawValue(
                "抽出したRenderer",
                extraction.KeptRendererPaths.Count + " 件");
            DrawValue(
                "削除したGameObject",
                extraction.DeletedObjectCount + " 個");
            DrawValue(
                "削除したRenderer",
                extraction.DeletedRendererCount + " 件");
            DrawValue(
                "Renderer Componentのみ削除",
                extraction.StrippedRendererCount + " 件");
            DrawValue(
                "除外したComponent",
                extraction.DroppedComponentCount + " 個");
            DrawValue(
                "出力内GameObject",
                extraction.OutputGameObjectCount + " 個");

            DrawList(
                "抽出したRenderer",
                extraction.KeptRendererPaths);
            DrawList(
                "ボーン配列の切り詰め",
                extraction.TrimLog);
            DrawList(
                "保護して残したGameObject",
                extraction.ProtectedPaths);
            DrawList(
                "削除したHierarchy Root",
                extraction.DeletedRoots);
            DrawList(
                "生成したMesh",
                extraction.GeneratedMeshes);

            if (summary.AutoAtlas is { Executed: true } autoAtlas)
            {
                EditorGUILayout.Space(10f);
                DrawSectionTitle("自動アトラス化");

                foreach (var message in autoAtlas.ReportMessages)
                {
                    EditorGUILayout.Space(4f);
                    EditorGUILayout.LabelField(
                        message.FormatLocalized(),
                        EditorStyles.wordWrappedLabel);
                }

                if (autoAtlas.HasChanges)
                {
                    EditorGUILayout.Space(6f);
                    DrawValue(
                        "生成Texture",
                        autoAtlas.TextureCount + " 件");
                    DrawValue(
                        "生成Material",
                        autoAtlas.MaterialCount + " 件");
                    DrawValue(
                        "生成Mesh",
                        autoAtlas.MeshCount + " 件");
                    DrawValue(
                        "Asset出力先",
                        summary.AtlasOutputFolder);
                }
            }

            DrawList("補足", extraction.Notes);
        }

        private static void DrawSectionTitle(string title)
        {
            EditorGUILayout.LabelField(
                title,
                EditorStyles.boldLabel);
        }

        private static void DrawValue(
            string label,
            string value)
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                EditorGUILayout.LabelField(
                    label,
                    GUILayout.Width(190f));
                GUILayout.Label(
                    value ?? "",
                    EditorStyles.wordWrappedLabel,
                    GUILayout.ExpandWidth(true));
            }
        }

        private static void DrawList(
            string title,
            IReadOnlyList<string> values)
        {
            if (values.Count == 0)
                return;

            EditorGUILayout.Space(8f);
            DrawSectionTitle(
                title + " (" + values.Count + " 件)");
            using (new EditorGUI.IndentLevelScope())
            {
                foreach (var value in values)
                {
                    EditorGUILayout.LabelField(
                        "・" + value,
                        EditorStyles.wordWrappedLabel);
                }
            }
        }
    }
}
