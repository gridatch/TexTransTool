using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using net.rs64.TexTransTool.TextureAtlas;
using net.rs64.TexTransTool.TextureAtlas.AAOCode;
using net.rs64.TexTransTool.TextureAtlas.FineTuning;
using net.rs64.TexTransTool.TextureAtlas.IslandRelocator;
using net.rs64.TexTransTool.TextureAtlas.Editor;
using net.rs64.TexTransTool.Utils;
using UnityEngine;
using UnityEngine.Experimental.Rendering;

namespace net.rs64.TexTransTool.NDMF.TestCode
{
    internal class AutoAtlasTextureMergePlannerSafetyTest
    {
        [Test]
        public void PartAutoAtlasDefaultsIncludeRetainedDisabledRenderers()
        {
            var settings =
                ScriptableObject.CreateInstance<PartAutoAtlasSettings>();
            try
            {
                Assert.That(settings.Enabled, Is.True);
                var execution = settings.ToExecutionSettings();
                Assert.That(execution.IncludeDisabledRenderer, Is.True);
                Assert.That(execution.EnableAdditionalAtlasMerging, Is.True);
                Assert.That(execution.OptimizeConstantTextures, Is.True);
                Assert.That(
                    execution.ConstantTextureColorTolerance,
                    Is.EqualTo(2));
                Assert.That(
                    execution.DisableVisuallyUnusedShaderFeatures,
                    Is.True);
                Assert.That(
                    execution.ExcludeVisibilityAnimatedItemsFromTextureMerging,
                    Is.False);
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(settings);
            }
        }

        private sealed class LiltoonTextureUvProbe
            : IMaterialInformationCallbackAbstractionInterface
        {
            internal readonly Dictionary<string, int?> IntValues = new();
            internal readonly Dictionary<string, float?> FloatValues = new();
            internal readonly Dictionary<string, Vector4?> VectorValues = new();
            internal readonly Dictionary<string, UsingUVChannels>
                TextureUvChannels = new();

            public int? GetInteger(string propertyName, bool considerAnimation = true)
                => IntValues.GetValueOrDefault(propertyName, 0);
            public int? GetInt(string propertyName, bool considerAnimation = true)
                => IntValues.GetValueOrDefault(propertyName, 0);
            public float? GetFloat(string propertyName, bool considerAnimation = true)
                => FloatValues.GetValueOrDefault(propertyName, 0f);
            public Vector4? GetVector(string propertyName, bool considerAnimation = true)
            {
                if (VectorValues.TryGetValue(propertyName, out var value))
                    return value;
                if (propertyName.EndsWith("_ST"))
                    return new Vector4(1f, 1f, 0f, 0f);
                if (propertyName.EndsWith("_ScrollRotate"))
                    return Vector4.zero;
                if (propertyName.EndsWith("DecalAnimation"))
                    return new Vector4(1f, 1f, 1f, 30f);
                if (propertyName.EndsWith("DecalSubParam"))
                    return new Vector4(1f, 1f, 0f, 1f);
                return Vector4.zero;
            }
            public bool? IsShaderKeywordEnabled(string keywordName) => false;
            public void RegisterOtherUVUsage(UsingUVChannels uvChannel) { }
            public void RegisterTextureUVUsage(
                string textureMaterialPropertyName,
                SamplerStateInformation samplerState,
                UsingUVChannels uvChannels,
                Matrix2x3? uvMatrix)
                => TextureUvChannels[textureMaterialPropertyName] = uvChannels;
            public void RegisterVertexIndexUsage() { }
        }

        [Test]
        public void LiltoonMain3rdUsesItsOwnUvMode()
        {
            var probe = new LiltoonTextureUvProbe();
            probe.IntValues["_UseMain3rdTex"] = 1;
            probe.IntValues["_Main2ndTex_UVMode"] = 0;
            probe.IntValues["_Main3rdTex_UVMode"] = 1;
            LiltoonShaderInformation.GetMaterialInformation(probe, isOutline: false);
            Assert.That(
                probe.TextureUvChannels["_Main3rdTex"],
                Is.EqualTo(UsingUVChannels.UV1));
        }

        [Test]
        public void LiltoonGlitterColorUsesItsOwnUvMode()
        {
            var probe = new LiltoonTextureUvProbe();
            probe.IntValues["_UseGlitter"] = 1;
            probe.IntValues["_GlitterColorTex_UVMode"] = 2;
            LiltoonShaderInformation.GetMaterialInformation(probe, isOutline: false);
            Assert.That(
                probe.TextureUvChannels["_GlitterColorTex"],
                Is.EqualTo(UsingUVChannels.UV2));
        }

        [Test]
        public void LiltoonOutlineVectorUsesItsOwnUvMode()
        {
            var probe = new LiltoonTextureUvProbe();
            probe.IntValues["_OutlineVectorUVMode"] = 2;
            probe.IntValues["_AudioLinkMask_UVMode"] = 0;
            LiltoonShaderInformation.GetMaterialInformation(probe, isOutline: true);
            Assert.That(
                probe.TextureUvChannels["_OutlineVectorTex"],
                Is.EqualTo(UsingUVChannels.UV2));
        }

        [Test]
        public void NfdhOversizedIslandsFailWithoutInvokingBrokenSort()
        {
            var islands = new[]
            {
                new net.rs64.TexTransCore.UVIsland.IslandTransform
                {
                    Size = new System.Numerics.Vector2(4f, 3f),
                },
                new net.rs64.TexTransCore.UVIsland.IslandTransform
                {
                    Size = new System.Numerics.Vector2(0.5f, 0.25f),
                },
            };

            Assert.That(
                IslandRelocationManager.IsGuaranteedNfdhFailure(
                    islands,
                    targetHeight: 1f,
                    padding: 0.01f),
                Is.True);

            Assert.DoesNotThrow(() =>
            {
                var result = IslandRelocationManager.RelocateSafely(
                    new net.rs64.TexTransCore.UVIsland.NFDHPlasFC(),
                    new net.rs64.TexTransCore.UVIsland.RelocationContext(
                        1f,
                        0.01f),
                    islands);
                Assert.That(result.IsSuccess, Is.False);
            });
        }

        [Test]
        public void NfdhPreflightAllowsFitCapableIslands()
        {
            var islands = new[]
            {
                new net.rs64.TexTransCore.UVIsland.IslandTransform
                {
                    Size = new System.Numerics.Vector2(0.4f, 0.2f),
                },
                new net.rs64.TexTransCore.UVIsland.IslandTransform
                {
                    Size = new System.Numerics.Vector2(0.25f, 0.1f),
                },
            };

            Assert.That(
                IslandRelocationManager.IsGuaranteedNfdhFailure(
                    islands,
                    targetHeight: 1f,
                    padding: 0.01f),
                Is.False);
        }

        [Test]
        public void MergeHostWidthsRemainAtLeast256()
        {
            Assert.That(
                AutoAtlasTextureMergePlanner.AutoAtlasMergeHostWidthCandidates,
                Is.EqualTo(new[] { 256, 512, 1024, 2048, 4096 }));
        }

        [Test]
        public void RuntimeRelevantTextureConsumersIgnoreHiddenWithoutVisibilityEvidence()
        {
            var shader = Shader.Find("Standard");
            Assert.That(shader, Is.Not.Null);

            var used = new Material(shader);
            var emptySlot = new Material(shader);
            var disabled = new Material(shader);
            var inactive = new Material(shader);
            var nonMesh = new Material(shader);
            var mesh = new Mesh();
            var disabledMesh = new Mesh();
            var inactiveMesh = new Mesh();
            var root = new GameObject("root");
            var disabledObject = new GameObject("disabled");
            var inactiveObject = new GameObject("inactive");
            var lineObject = new GameObject("line");
            try
            {
                mesh.vertices = new[]
                {
                    Vector3.zero,
                    Vector3.right,
                    Vector3.up,
                };
                mesh.subMeshCount = 2;
                mesh.SetTriangles(new[] { 0, 1, 2 }, 0);
                mesh.SetTriangles(System.Array.Empty<int>(), 1);

                var filter = root.AddComponent<MeshFilter>();
                filter.sharedMesh = mesh;
                var renderer = root.AddComponent<MeshRenderer>();
                renderer.sharedMaterials = new[] { used, emptySlot };

                disabledMesh.vertices = mesh.vertices;
                disabledMesh.triangles = new[] { 0, 1, 2 };
                var disabledFilter =
                    disabledObject.AddComponent<MeshFilter>();
                disabledFilter.sharedMesh = disabledMesh;
                var disabledRenderer =
                    disabledObject.AddComponent<MeshRenderer>();
                disabledRenderer.sharedMaterial = disabled;
                disabledRenderer.enabled = false;

                inactiveMesh.vertices = mesh.vertices;
                inactiveMesh.triangles = new[] { 0, 1, 2 };
                var inactiveFilter =
                    inactiveObject.AddComponent<MeshFilter>();
                inactiveFilter.sharedMesh = inactiveMesh;
                var inactiveRenderer =
                    inactiveObject.AddComponent<MeshRenderer>();
                inactiveRenderer.sharedMaterial = inactive;
                inactiveObject.SetActive(false);

                var lineRenderer = lineObject.AddComponent<LineRenderer>();
                lineRenderer.sharedMaterial = nonMesh;
                lineRenderer.positionCount = 2;
                lineRenderer.SetPosition(0, Vector3.zero);
                lineRenderer.SetPosition(1, Vector3.right);

                var consumers =
                    AutoAtlasTextureProcessor.CollectRuntimeRelevantTextureConsumers(
                        new RendererTargetingForTest(
                            new Renderer[]
                            {
                                renderer,
                                disabledRenderer,
                                inactiveRenderer,
                                lineRenderer,
                            }));

                Assert.That(consumers.Materials, Has.Member(used));
                Assert.That(
                    consumers.Materials,
                    Has.No.Member(emptySlot),
                    "A material assigned only to an empty submesh is not a texture-memory consumer.");
                Assert.That(
                    consumers.Materials,
                    Has.No.Member(disabled),
                    "A hidden renderer without visibility evidence is not a runtime texture consumer.");
                Assert.That(
                    consumers.Materials,
                    Has.No.Member(inactive),
                    "An inactive GameObject without visibility evidence is not a runtime texture consumer.");
                Assert.That(
                    consumers.Materials,
                    Has.Member(nonMesh),
                    "An active non-mesh renderer is still a real texture consumer.");

                var visibilityStates = new Dictionary<
                    Renderer, AtlasRendererVisibilityState>
                {
                    [disabledRenderer] =
                        new AtlasRendererVisibilityState(true, true),
                    [inactiveRenderer] =
                        new AtlasRendererVisibilityState(true, true),
                };
                consumers =
                    AutoAtlasTextureProcessor
                        .CollectRuntimeRelevantTextureConsumers(
                            new RendererTargetingForTest(
                                new Renderer[]
                                {
                                    renderer,
                                    disabledRenderer,
                                    inactiveRenderer,
                                    lineRenderer,
                                }),
                            visibilityStates);

                Assert.That(
                    consumers.Materials,
                    Has.Member(disabled),
                    "An initially disabled renderer that can become visible is a runtime texture consumer.");
                Assert.That(
                    consumers.Materials,
                    Has.Member(inactive),
                    "An initially inactive renderer that can become visible is a runtime texture consumer.");
            }
            finally
            {
                Object.DestroyImmediate(root);
                Object.DestroyImmediate(disabledObject);
                Object.DestroyImmediate(inactiveObject);
                Object.DestroyImmediate(lineObject);
                Object.DestroyImmediate(mesh);
                Object.DestroyImmediate(disabledMesh);
                Object.DestroyImmediate(inactiveMesh);
                Object.DestroyImmediate(used);
                Object.DestroyImmediate(emptySlot);
                Object.DestroyImmediate(disabled);
                Object.DestroyImmediate(inactive);
                Object.DestroyImmediate(nonMesh);
            }
        }

        [Test]
        public void RuntimeRelevantDrawableExternalConsumersRetainSourceCost()
        {
            var shader = Shader.Find("Standard");
            Assert.That(shader, Is.Not.Null);

            var source = new Texture2D(4, 4);
            var target = new Material(shader);
            var activeExternal = new Material(shader);
            var unusedReferenceOnly = new Material(shader);
            var targetMesh = new Mesh();
            var externalMesh = new Mesh();
            var targetObject = new GameObject("target");
            var externalObject = new GameObject("external");
            try
            {
                target.SetTexture("_MainTex", source);
                activeExternal.SetTexture("_MainTex", source);
                unusedReferenceOnly.SetTexture("_MainTex", source);

                foreach (var mesh in new[] { targetMesh, externalMesh })
                {
                    mesh.vertices = new[]
                    {
                        Vector3.zero,
                        Vector3.right,
                        Vector3.up,
                    };
                    mesh.triangles = new[] { 0, 1, 2 };
                }

                var targetFilter =
                    targetObject.AddComponent<MeshFilter>();
                targetFilter.sharedMesh = targetMesh;
                var targetRenderer =
                    targetObject.AddComponent<MeshRenderer>();
                targetRenderer.sharedMaterial = target;

                var externalFilter =
                    externalObject.AddComponent<MeshFilter>();
                externalFilter.sharedMesh = externalMesh;
                var externalRenderer =
                    externalObject.AddComponent<MeshRenderer>();
                externalRenderer.sharedMaterial = activeExternal;

                var consumers =
                    AutoAtlasTextureProcessor.CollectRuntimeRelevantTextureConsumers(
                        new RendererTargetingForTest(
                            new Renderer[]
                            {
                                targetRenderer,
                                externalRenderer,
                            }));

                var retained =
                    AutoAtlasTextureProcessor
                        .FindExternallyRetainedSourceTextures(
                            consumers,
                            new HashSet<Material> { target },
                            new HashSet<Texture> { source });

                Assert.That(
                    retained,
                    Is.EquivalentTo(new Texture[] { source }));

                externalRenderer.enabled = false;
                consumers =
                    AutoAtlasTextureProcessor.CollectRuntimeRelevantTextureConsumers(
                        new RendererTargetingForTest(
                            new Renderer[]
                            {
                                targetRenderer,
                                externalRenderer,
                            }));
                retained =
                    AutoAtlasTextureProcessor
                        .FindExternallyRetainedSourceTextures(
                            consumers,
                            new HashSet<Material> { target },
                            new HashSet<Texture> { source });

                Assert.That(
                    retained,
                    Is.Empty,
                    "A material asset that merely references the texture must not become resident cost without a runtime-relevant drawable renderer consumer.");

                consumers =
                    AutoAtlasTextureProcessor
                        .CollectRuntimeRelevantTextureConsumers(
                            new RendererTargetingForTest(
                                new Renderer[]
                                {
                                    targetRenderer,
                                    externalRenderer,
                                }),
                            new Dictionary<
                                Renderer, AtlasRendererVisibilityState>
                            {
                                [externalRenderer] =
                                    new AtlasRendererVisibilityState(
                                        true, true),
                            });
                retained =
                    AutoAtlasTextureProcessor
                        .FindExternallyRetainedSourceTextures(
                            consumers,
                            new HashSet<Material> { target },
                            new HashSet<Texture> { source });
                Assert.That(
                    retained,
                    Is.EquivalentTo(new Texture[] { source }),
                    "An initially hidden external renderer that can become visible must retain the source cost.");
                Assert.That(
                    unusedReferenceOnly.GetTexture("_MainTex"),
                    Is.SameAs(source),
                    "The regression keeps an unused material reference present while proving it has no cost effect.");
            }
            finally
            {
                Object.DestroyImmediate(targetObject);
                Object.DestroyImmediate(externalObject);
                Object.DestroyImmediate(targetMesh);
                Object.DestroyImmediate(externalMesh);
                Object.DestroyImmediate(target);
                Object.DestroyImmediate(activeExternal);
                Object.DestroyImmediate(unusedReferenceOnly);
                Object.DestroyImmediate(source);
            }
        }

        [Test]
        public void RemovedTargetBindingAndUnusedMaterialReferenceDoNotRetainCost()
        {
            var shader = Shader.Find("Standard");
            Assert.That(shader, Is.Not.Null);

            var source = new Texture2D(4, 4);
            var target = new Material(shader);
            var unusedReferenceOnly = new Material(shader);
            var mesh = new Mesh();
            var targetObject = new GameObject("target");
            try
            {
                target.SetTexture("_MainTex", source);
                unusedReferenceOnly.SetTexture("_MainTex", source);

                mesh.vertices = new[]
                {
                    Vector3.zero,
                    Vector3.right,
                    Vector3.up,
                };
                mesh.triangles = new[] { 0, 1, 2 };
                var filter = targetObject.AddComponent<MeshFilter>();
                filter.sharedMesh = mesh;
                var renderer = targetObject.AddComponent<MeshRenderer>();
                renderer.sharedMaterial = target;

                var consumers =
                    AutoAtlasTextureProcessor.CollectRuntimeRelevantTextureConsumers(
                        new RendererTargetingForTest(
                            new Renderer[] { renderer }));
                var group = new HashSet<Material> { target };
                var originalSources = new HashSet<Texture> { source };
                var targetRetained =
                    AutoAtlasTextureProcessor
                        .FindTargetRetainedSourceTextures(
                            group,
                            new Dictionary<
                                Material,
                                IReadOnlyDictionary<string, Texture>>
                            {
                                [target] =
                                    new Dictionary<string, Texture>(),
                            },
                            originalSources,
                            new HashSet<(Material material, string property)>
                            {
                                (target, "_MainTex"),
                            });
                var externalRetained =
                    AutoAtlasTextureProcessor
                        .FindExternallyRetainedSourceTextures(
                            consumers,
                            group,
                            originalSources);

                Assert.That(targetRetained, Is.Empty);
                Assert.That(externalRetained, Is.Empty);
                Assert.That(
                    unusedReferenceOnly.GetTexture("_MainTex"),
                    Is.SameAs(source),
                    "The unused reference remains present but is deliberately outside the cost-consumer set.");
            }
            finally
            {
                Object.DestroyImmediate(targetObject);
                Object.DestroyImmediate(mesh);
                Object.DestroyImmediate(target);
                Object.DestroyImmediate(unusedReferenceOnly);
                Object.DestroyImmediate(source);
            }
        }

        [Test]
        public void TargetLocalRetentionIsSeparatedFromExternalCostRetention()
        {
            var shader = Shader.Find("Standard");
            Assert.That(shader, Is.Not.Null);

            var source = new Texture2D(4, 4);
            var target = new Material(shader);
            try
            {
                target.SetTexture("_MainTex", source);
                target.SetTexture("_BumpMap", source);

                var retained =
                    AutoAtlasTextureProcessor
                        .FindTargetRetainedSourceTextures(
                            new HashSet<Material> { target },
                            new Dictionary<
                                Material,
                                IReadOnlyDictionary<string, Texture>>
                            {
                                [target] =
                                    new Dictionary<string, Texture>
                                    {
                                        ["_MainTex"] = source,
                                    },
                            },
                            new HashSet<Texture> { source });

                Assert.That(
                    retained,
                    Is.EquivalentTo(new Texture[] { source }),
                    "A target-local property outside the rewrite is a generated-material expectation, independently of external consumer cost.");
            }
            finally
            {
                Object.DestroyImmediate(target);
                Object.DestroyImmediate(source);
            }
        }

        [Test]
        public void SourceOnlyBaselineRequiresStrictPixelAndMemoryBenefit()
        {
            var original = Plan(new[]
            {
                Entry(1024, 1024, 1),
            });
            var smaller = Plan(new[]
            {
                Entry(512, 512, 1),
            });
            var same = Plan(new[]
            {
                Entry(1024, 1024, 1),
            });

            Assert.That(
                AutoAtlasTextureMergePlanner.SelectNonAtlasMode(
                    original, smaller),
                Is.EqualTo(
                    AutoAtlasTextureMergePlanner.NonAtlasMode.SourceOnly));
            Assert.That(
                AutoAtlasTextureMergePlanner.SelectNonAtlasMode(
                    original, same),
                Is.EqualTo(
                    AutoAtlasTextureMergePlanner.NonAtlasMode.Original));
        }

        [Test]
        public void RetainedSourceCostCanStillAllowStrictBenefit()
        {
            var original = Plan(new[]
            {
                Entry(1024, 1024, 1),
                Entry(1024, 1024, 1),
            });
            var generated = Plan(new[]
            {
                Entry(512, 512, 1),
            });
            var retained = Plan(new[]
            {
                Entry(1024, 1024, 1),
            });
            var finalCost =
                AutoAtlasTextureMergePlanner.TextureCostPlan.Combine(
                    new[] { generated, retained });

            Assert.That(
                Candidate(original, finalCost).IsAdoptable,
                Is.True);
        }

        [Test]
        public void RetainedSourceCostRejectsNonReducingAtlas()
        {
            var original = Plan(new[]
            {
                Entry(1024, 1024, 1),
                Entry(1024, 1024, 1),
            });
            var generated = Plan(new[]
            {
                Entry(1024, 1024, 1),
            });
            var retained = Plan(new[]
            {
                Entry(1024, 1024, 1),
            });
            var finalCost =
                AutoAtlasTextureMergePlanner.TextureCostPlan.Combine(
                    new[] { generated, retained });

            Assert.That(
                Candidate(original, finalCost).IsAdoptable,
                Is.False);
        }

        [Test]
        public void UnknownMemoryBlockLayoutsFailClosed()
        {
            Assert.That(
                AtlasTexture.TryGetMemoryBlockLayout(
                    (TextureFormat)int.MaxValue,
                    out _),
                Is.False);
            Assert.That(
                AtlasTexture.TryGetMemoryBlockLayout(
                    (GraphicsFormat)int.MaxValue,
                    out _),
                Is.False);

            Assert.That(
                AtlasTexture.TryGetMemoryBlockLayout(
                    TextureFormat.RGBA32,
                    out var rgbaBlock),
                Is.True);
            Assert.That(rgbaBlock, Is.EqualTo((1u, 1u, 4u)));
        }

        [Test]
        public void SourceTextureMemoryUsesActualMipCount()
        {
            var texture = new Texture2D(
                16,
                16,
                TextureFormat.RGBA32,
                2,
                false);
            try
            {
                Assert.That(texture.mipmapCount, Is.EqualTo(2));

                var descriptor = new TexTransToolTextureDescriptor
                {
                    UseMipMap = true,
                };
                Assert.That(
                    AtlasTexture.GetSourceTextureMipCount(
                        texture,
                        descriptor),
                    Is.EqualTo(2));

                descriptor.UseMipMap = false;
                Assert.That(
                    AtlasTexture.GetSourceTextureMipCount(
                        texture,
                        descriptor),
                    Is.EqualTo(1));
            }
            finally
            {
                Object.DestroyImmediate(texture);
            }
        }

        [Test]
        public void RetainedSourceTextureIsDetectedBeforeMaterialReplacement()
        {
            var shader = Shader.Find("Standard");
            Assert.That(shader, Is.Not.Null);

            var source = new Texture2D(4, 4);
            var replacement = new Texture2D(4, 4);
            var material = new Material(shader);
            try
            {
                material.SetTexture("_MainTex", source);
                var sourceTextures = new HashSet<Texture> { source };

                Assert.That(
                    AutoAtlasTextureProcessor.RetainsAnySourceTexture(
                        new[] { material },
                        sourceTextures),
                    Is.True);

                material.SetTexture("_MainTex", replacement);
                Assert.That(
                    AutoAtlasTextureProcessor.RetainsAnySourceTexture(
                        new[] { material },
                        sourceTextures),
                    Is.False);
            }
            finally
            {
                Object.DestroyImmediate(material);
                Object.DestroyImmediate(source);
                Object.DestroyImmediate(replacement);
            }
        }

        [Test]
        public void GeneratedSourceReferencesAreCheckedAgainstTargetExpectations()
        {
            var shader = Shader.Find("Standard");
            Assert.That(shader, Is.Not.Null);

            var source = new Texture2D(4, 4);
            var generated = new Material(shader);
            try
            {
                generated.SetTexture("_MainTex", source);
                var sources = new HashSet<Texture> { source };

                Assert.That(
                    AutoAtlasTextureProcessor
                        .HasUnexpectedGeneratedSourceReference(
                            new[] { generated },
                            sources,
                            new HashSet<Texture>()),
                    Is.True,
                    "External cost-retention must not authorize a generated target material to keep an original source.");

                Assert.That(
                    AutoAtlasTextureProcessor
                        .HasUnexpectedGeneratedSourceReference(
                            new[] { generated },
                            sources,
                            new HashSet<Texture> { source }),
                    Is.False,
                    "Only a target-local intentionally retained source may remain on the generated material.");
            }
            finally
            {
                Object.DestroyImmediate(generated);
                Object.DestroyImmediate(source);
            }
        }

        [Test]
        public void DestroyUnappliedAtlasedMaterialsDestroysTemporaryMaterials()
        {
            var shader = Shader.Find("Hidden/InternalErrorShader");
            Assert.That(shader, Is.Not.Null);

            var first = new Material(shader);
            var second = new Material(shader);

            AutoAtlasTextureProcessor.DestroyUnappliedAtlasedMaterials(
                new[] { first, first, second });

            Assert.That(first == null, Is.True);
            Assert.That(second == null, Is.True);
        }

        [Test]
        public void DestroyUnappliedAtlasedMeshesDestroysTemporaryMeshes()
        {
            var first = new Mesh();
            var second = new Mesh();

            AutoAtlasTextureProcessor.DestroyUnappliedAtlasedMeshes(
                new[] { first, first, second });

            Assert.That(first == null, Is.True);
            Assert.That(second == null, Is.True);
        }

        [Test]
        public void ReferenceCopyRejectsOnlyMergeIntroducedSourceProperty()
        {
            var shader = Shader.Find("Standard");
            Assert.That(shader, Is.Not.Null);

            var mainMaterial = new Material(shader);
            var bumpMaterial = new Material(shader);
            var mainTexture = new Texture2D(4, 4);
            var bumpTexture = new Texture2D(4, 4);
            try
            {
                mainMaterial.SetTexture("_MainTex", mainTexture);
                bumpMaterial.SetTexture("_BumpMap", bumpTexture);

                var settings = new AtlasSetting
                {
                    TextureFineTuning = new List<ITextureFineTuning>
                    {
                        new ReferenceCopy
                        {
                            SourcePropertyName = new PropertyName("_MainTex"),
                            TargetPropertyNameList =
                                new List<PropertyName>
                                {
                                    new PropertyName("_BumpMap"),
                                },
                        },
                    },
                };

                var propertyTextures =
                    new Dictionary<
                        Material,
                        IReadOnlyDictionary<string, Texture>>
                    {
                        [mainMaterial] = new Dictionary<string, Texture>
                        {
                            ["_MainTex"] = mainTexture,
                        },
                        [bumpMaterial] = new Dictionary<string, Texture>(),
                    };
                var mainGroup =
                    new AutoAtlasTextureMergePlanner.PreparedGroup
                    {
                        Id = 0,
                        Materials = new HashSet<Material> { mainMaterial },
                    };
                var bumpGroup =
                    new AutoAtlasTextureMergePlanner.PreparedGroup
                    {
                        Id = 1,
                        Materials = new HashSet<Material> { bumpMaterial },
                    };

                Assert.That(
                    AutoAtlasTextureMergePlanner
                        .PreservesReferenceCopySemantics(
                            new[] { mainGroup },
                            propertyTextures,
                            settings),
                    Is.True,
                    "Standalone AutoAtlas follows normal AtlasTexture semantics.");

                Assert.That(
                    AutoAtlasTextureMergePlanner
                        .PreservesReferenceCopySemantics(
                            new[] { bumpGroup },
                            propertyTextures,
                            settings),
                    Is.True,
                    "A standalone group without the copy source must not be rejected.");

                Assert.That(
                    AutoAtlasTextureMergePlanner
                        .PreservesReferenceCopySemantics(
                            new[] { mainGroup, bumpGroup },
                            propertyTextures,
                            settings),
                    Is.False,
                    "Merging must not introduce a copy source that rewrites another atomic group's existing target texture, even when that target is not itself atlased.");
            }
            finally
            {
                Object.DestroyImmediate(mainTexture);
                Object.DestroyImmediate(bumpTexture);
                Object.DestroyImmediate(mainMaterial);
                Object.DestroyImmediate(bumpMaterial);
            }
        }

        [Test]
        public void ReferenceCopyDoesNotRevalidateNormalAtlasSemantics()
        {
            var shader = Shader.Find("Standard");
            Assert.That(shader, Is.Not.Null);

            var first = new Material(shader);
            var second = new Material(shader);
            var firstMain = new Texture2D(4, 4);
            var firstBump = new Texture2D(4, 4);
            var secondMain = new Texture2D(4, 4);
            var secondBump = new Texture2D(4, 4);
            try
            {
                first.SetTexture("_MainTex", firstMain);
                first.SetTexture("_BumpMap", firstBump);
                first.SetTextureScale("_BumpMap", new Vector2(2f, 1f));
                second.SetTexture("_MainTex", secondMain);
                second.SetTexture("_BumpMap", secondBump);

                var settings = new AtlasSetting
                {
                    TextureFineTuning = new List<ITextureFineTuning>
                    {
                        new ReferenceCopy
                        {
                            SourcePropertyName = new PropertyName("_MainTex"),
                            TargetPropertyNameList =
                                new List<PropertyName>
                                {
                                    new PropertyName("_BumpMap"),
                                },
                        },
                    },
                };

                var propertyTextures =
                    new Dictionary<
                        Material,
                        IReadOnlyDictionary<string, Texture>>
                    {
                        [first] = new Dictionary<string, Texture>
                        {
                            ["_MainTex"] = firstMain,
                            ["_BumpMap"] = firstBump,
                        },
                        [second] = new Dictionary<string, Texture>
                        {
                            ["_MainTex"] = secondMain,
                            ["_BumpMap"] = secondBump,
                        },
                    };
                var groups = new[]
                {
                    new AutoAtlasTextureMergePlanner.PreparedGroup
                    {
                        Id = 0,
                        Materials = new HashSet<Material> { first },
                    },
                    new AutoAtlasTextureMergePlanner.PreparedGroup
                    {
                        Id = 1,
                        Materials = new HashSet<Material> { second },
                    },
                };

                Assert.That(
                    AutoAtlasTextureMergePlanner
                        .PreservesReferenceCopySemantics(
                            groups,
                            propertyTextures,
                            settings),
                    Is.True,
                    "Different target textures or UV transforms are normal AtlasTexture semantics, not an AutoAtlas merge veto.");
            }
            finally
            {
                Object.DestroyImmediate(firstMain);
                Object.DestroyImmediate(firstBump);
                Object.DestroyImmediate(secondMain);
                Object.DestroyImmediate(secondBump);
                Object.DestroyImmediate(first);
                Object.DestroyImmediate(second);
            }
        }

        [Test]
        public void RequiredAtlasMeshIgnoresEmptyTargetSubmeshButKeepsRepeatedGeometry()
        {
            var shader = Shader.Find("Hidden/InternalErrorShader");
            Assert.That(shader, Is.Not.Null);

            var target = new Material(shader);
            var other = new Material(shader);
            var mesh = new Mesh();
            var gameObject = new GameObject("RequiredAtlasMesh");
            try
            {
                mesh.vertices = new[]
                {
                    Vector3.zero,
                    Vector3.right,
                    Vector3.up,
                };
                mesh.uv = new[]
                {
                    Vector2.zero,
                    Vector2.right,
                    Vector2.up,
                };
                mesh.subMeshCount = 2;
                mesh.SetTriangles(System.Array.Empty<int>(), 0);
                mesh.SetTriangles(new[] { 0, 1, 2 }, 1);

                var filter = gameObject.AddComponent<MeshFilter>();
                filter.sharedMesh = mesh;
                var renderer = gameObject.AddComponent<MeshRenderer>();

                renderer.sharedMaterials = new[] { target, other };
                var targeting = new RendererTargetingForTest(
                    new Renderer[] { renderer });

                Assert.That(
                    AutoAtlasTextureProcessor.RendererRequiresAtlasMesh(
                        targeting,
                        renderer,
                        new HashSet<Material> { target }),
                    Is.False,
                    "A target material used only by an empty effective submesh has no UVs to rewrite.");

                renderer.sharedMaterials = new[] { other, target };
                Assert.That(
                    AutoAtlasTextureProcessor.RendererRequiresAtlasMesh(
                        targeting,
                        renderer,
                        new HashSet<Material> { target }),
                    Is.True);

                mesh.subMeshCount = 1;
                mesh.SetTriangles(new[] { 0, 1, 2 }, 0);
                renderer.sharedMaterials = new[] { other, target };
                Assert.That(
                    AutoAtlasTextureProcessor.RendererRequiresAtlasMesh(
                        targeting,
                        renderer,
                        new HashSet<Material> { target }),
                    Is.True,
                    "Extra material slots repeat the final non-empty submesh.");
            }
            finally
            {
                Object.DestroyImmediate(gameObject);
                Object.DestroyImmediate(mesh);
                Object.DestroyImmediate(target);
                Object.DestroyImmediate(other);
            }
        }

        [Test]
        public void AtlasSubSetIgnoresTargetMaterialOnEmptySubMesh()
        {
            var shader = Shader.Find("Hidden/InternalErrorShader");
            Assert.That(shader, Is.Not.Null);

            var material = new Material(shader);
            var mesh = new Mesh();
            try
            {
                mesh.vertices = new[]
                {
                    Vector3.zero,
                    Vector3.right,
                    Vector3.up,
                };
                mesh.subMeshCount = 1;
                mesh.SetTriangles(System.Array.Empty<int>(), 0);

                var targetMaterials = new HashSet<Material> { material };
                var grouping = new MaterialGroupingContext(
                    targetMaterials,
                    new Dictionary<
                        Material,
                        IReadOnlyDictionary<string, Texture>>
                    {
                        [material] =
                            new Dictionary<string, Texture>(),
                    },
                    null);

                var subSet =
                    AtlasSubMeshIndexIDSetContext.BuildAtlasSubSet(
                        mesh,
                        new Material[] { material },
                        7,
                        targetMaterials,
                        grouping);

                Assert.That(subSet.All(item => !item.HasValue), Is.True);
            }
            finally
            {
                Object.DestroyImmediate(mesh);
                Object.DestroyImmediate(material);
            }
        }

        [Test]
        public void AtlasSubSetKeepsNonEmptySlotsAndRepeatedLastSubMesh()
        {
            var shader = Shader.Find("Hidden/InternalErrorShader");
            Assert.That(shader, Is.Not.Null);

            var material = new Material(shader);
            var mesh = new Mesh();
            try
            {
                mesh.vertices = new[]
                {
                    Vector3.zero,
                    Vector3.right,
                    Vector3.up,
                };
                mesh.subMeshCount = 2;
                mesh.SetTriangles(new[] { 0, 1, 2 }, 0);
                mesh.SetTriangles(System.Array.Empty<int>(), 1);

                var targetMaterials = new HashSet<Material> { material };
                var grouping = new MaterialGroupingContext(
                    targetMaterials,
                    new Dictionary<
                        Material,
                        IReadOnlyDictionary<string, Texture>>
                    {
                        [material] =
                            new Dictionary<string, Texture>(),
                    },
                    null);

                var mixed =
                    AtlasSubMeshIndexIDSetContext.BuildAtlasSubSet(
                        mesh,
                        new Material[] { material, material },
                        3,
                        targetMaterials,
                        grouping);
                Assert.That(mixed[0].HasValue, Is.True);
                Assert.That(mixed[1].HasValue, Is.False);

                mesh.SetTriangles(new[] { 0, 1, 2 }, 1);
                var repeated =
                    AtlasSubMeshIndexIDSetContext.BuildAtlasSubSet(
                        mesh,
                        new Material[] { material, material, material },
                        3,
                        targetMaterials,
                        grouping);
                Assert.That(repeated.All(item => item.HasValue), Is.True);
                Assert.That(repeated[2]!.Value.SubMeshIndex, Is.EqualTo(2));
            }
            finally
            {
                Object.DestroyImmediate(mesh);
                Object.DestroyImmediate(material);
            }
        }

        [TestCase(1L, 2L, true)]
        [TestCase(2L, 2L, false)]
        [TestCase(3L, 2L, false)]
        [TestCase(0L, 2L, false)]
        public void FinalMergePixelBenefitMustBeStrict(
            long finalPixels,
            long baselinePixels,
            bool expected)
        {
            Assert.That(
                AutoAtlasTextureProcessor.HasStrictMergePixelBenefit(
                    finalPixels,
                    baselinePixels),
                Is.EqualTo(expected));
        }

        [Test]
        public void CandidateAcceptsStrictlyBetterNonRegressingMerge()
        {
            var baseline = Plan(
                new[]
                {
                    Entry(64, 64, 1),
                    Entry(64, 64, 1),
                },
                new Dictionary<int, double>
                {
                    [0] = 4d,
                    [1] = 4d,
                });
            var merged = Plan(
                new[]
                {
                    Entry(64, 64, 1),
                },
                new Dictionary<int, double>
                {
                    [0] = 4d,
                    [1] = 4d,
                });

            Assert.That(Candidate(baseline, merged).IsAdoptable, Is.True);
        }

        [Test]
        public void CandidateRejectsWhenPixelCountDoesNotDecrease()
        {
            var baseline = Plan(new[]
            {
                Entry(64, 64, 1, blockSize: 4),
                Entry(64, 64, 1, blockSize: 4),
            });
            var merged = Plan(new[]
            {
                Entry(64, 64, 1, blockSize: 2),
                Entry(64, 64, 1, blockSize: 2),
            });

            Assert.That(Candidate(baseline, merged).IsAdoptable, Is.False);
        }

        [Test]
        public void CandidateRejectsWhenResidentMemoryDoesNotDecrease()
        {
            var baseline = Plan(new[]
            {
                Entry(64, 64, 1, blockSize: 2),
                Entry(64, 64, 1, blockSize: 2),
            });
            var merged = Plan(new[]
            {
                Entry(64, 64, 1, blockSize: 4),
            });

            Assert.That(Candidate(baseline, merged).IsAdoptable, Is.False);
        }

        [Test]
        public void CandidateAllowsMaximumTextureDimensionIncreaseWhenOtherCostsImprove()
        {
            var baseline = Plan(new[]
            {
                Entry(128, 128, 1),
                Entry(128, 128, 1),
            });
            var merged = Plan(new[]
            {
                Entry(256, 32, 1),
            });

            Assert.That(Candidate(baseline, merged).IsAdoptable, Is.True);
        }

        [Test]
        public void CandidateAllowsPropertyDimensionAtAutoAtlasLimit()
        {
            var baseline = Plan(new[]
            {
                Entry(2048, 64, 1),
                Entry(2048, 64, 1),
            });
            var merged = Plan(new[]
            {
                Entry(4096, 16, 1),
            });
            var candidate = new AutoAtlasTextureMergePlanner.Candidate(
                new[] { 0, 1 },
                baseline,
                merged,
                new Vector2Int(4096, 256),
                new Dictionary<string, Vector2Int>
                {
                    ["_MainTex"] = new Vector2Int(4096, 16),
                });

            Assert.That(candidate.IsAdoptable, Is.True);
        }

        [Test]
        public void CandidateRejectsPropertyDimensionAboveAutoAtlasLimit()
        {
            var baseline = Plan(new[]
            {
                Entry(4096, 64, 1),
                Entry(4096, 64, 1),
            });
            var merged = Plan(new[]
            {
                Entry(8192, 8, 1),
            });
            var candidate = new AutoAtlasTextureMergePlanner.Candidate(
                new[] { 0, 1 },
                baseline,
                merged,
                new Vector2Int(4096, 256),
                new Dictionary<string, Vector2Int>
                {
                    ["_MainTex"] = new Vector2Int(8192, 8),
                });

            Assert.That(candidate.IsAdoptable, Is.False);
            Assert.That(
                candidate.RejectionReason,
                Is.EqualTo(
                    AutoAtlasTextureMergePlanner
                        .CandidateRejectionReason.MaxDimension));
        }

        [Test]
        public void MergeSelectionCarriesPredictedCostMetrics()
        {
            var baseline = Plan(new[]
            {
                Entry(128, 128, 1),
                Entry(128, 128, 1),
            });
            var merged = Plan(new[]
            {
                Entry(256, 64, 1),
            });
            var candidate = new AutoAtlasTextureMergePlanner.Candidate(
                new[] { 2, 5 },
                baseline,
                merged,
                new Vector2Int(256, 64),
                new Dictionary<string, Vector2Int>
                {
                    ["_MainTex"] = new Vector2Int(256, 64),
                });
            var selection =
                new AutoAtlasTextureMergePlanner.MergeSelection(candidate);

            Assert.That(selection.BaselinePixels,
                Is.EqualTo(baseline.PixelCount));
            Assert.That(selection.PredictedMergedPixels,
                Is.EqualTo(merged.PixelCount));
            Assert.That(selection.BaselineBytes,
                Is.EqualTo(baseline.FullResidentBytes));
            Assert.That(selection.PredictedMergedBytes,
                Is.EqualTo(merged.FullResidentBytes));
            Assert.That(selection.PredictedSavingBytes,
                Is.EqualTo(
                    baseline.FullResidentBytes
                    - merged.FullResidentBytes));
        }

        [Test]
        public void CandidateRejectsSamplingCostRegression()
        {
            var baseline = Plan(
                new[]
                {
                    Entry(64, 64, 1),
                    Entry(64, 64, 1),
                },
                new Dictionary<int, double>
                {
                    [0] = 4d,
                    [1] = 4d,
                });
            var merged = Plan(
                new[]
                {
                    Entry(64, 64, 1),
                },
                new Dictionary<int, double>
                {
                    [0] = 8d,
                    [1] = 4d,
                });

            Assert.That(Candidate(baseline, merged).IsAdoptable, Is.False);
        }

        [Test]
        public void AtlasRendererEligibilityRejectsMeshWithoutSubMeshes()
        {
            var shader = Shader.Find("Hidden/InternalErrorShader");
            Assert.That(shader, Is.Not.Null);

            var material = new Material(shader);
            var mesh = new Mesh();
            var gameObject = new GameObject("NoSubMeshes");
            try
            {
                mesh.vertices = new[]
                {
                    Vector3.zero,
                    Vector3.right,
                    Vector3.up,
                };
                mesh.uv = new[]
                {
                    Vector2.zero,
                    Vector2.right,
                    Vector2.up,
                };
                mesh.subMeshCount = 0;

                var filter = gameObject.AddComponent<MeshFilter>();
                filter.sharedMesh = mesh;
                var renderer = gameObject.AddComponent<MeshRenderer>();
                renderer.sharedMaterial = material;

                Assert.That(
                    AtlasTexture.IsAtlasAllowedRenderer(renderer),
                    Is.False);
            }
            finally
            {
                Object.DestroyImmediate(gameObject);
                Object.DestroyImmediate(mesh);
                Object.DestroyImmediate(material);
            }
        }

        [Test]
        public void AtlasRendererEligibilityRequiresDrawableTriangles()
        {
            var shader = Shader.Find("Hidden/InternalErrorShader");
            Assert.That(shader, Is.Not.Null);

            var material = new Material(shader);
            var mesh = new Mesh();
            var gameObject = new GameObject("Topology");
            try
            {
                mesh.vertices = new[]
                {
                    Vector3.zero,
                    Vector3.right,
                    Vector3.up,
                };
                mesh.uv = new[]
                {
                    Vector2.zero,
                    Vector2.right,
                    Vector2.up,
                };
                mesh.subMeshCount = 1;

                var filter = gameObject.AddComponent<MeshFilter>();
                filter.sharedMesh = mesh;
                var renderer = gameObject.AddComponent<MeshRenderer>();
                renderer.sharedMaterial = material;

                mesh.SetIndices(
                    System.Array.Empty<int>(),
                    MeshTopology.Triangles,
                    0);
                Assert.That(
                    AtlasTexture.IsAtlasAllowedRenderer(renderer),
                    Is.False);

                mesh.SetIndices(
                    System.Array.Empty<int>(),
                    MeshTopology.Lines,
                    0);
                Assert.That(
                    AtlasTexture.IsAtlasAllowedRenderer(renderer),
                    Is.False,
                    "Even an empty non-triangle submesh is unsupported because AtlasTexture reads every submesh through triangle-only APIs.");

                mesh.SetIndices(
                    new[] { 0, 1 },
                    MeshTopology.Lines,
                    0);
                Assert.That(
                    AtlasTexture.IsAtlasAllowedRenderer(renderer),
                    Is.False);

                mesh.SetTriangles(new[] { 0, 1, 2 }, 0);
                Assert.That(
                    AtlasTexture.IsAtlasAllowedRenderer(renderer),
                    Is.True);
            }
            finally
            {
                Object.DestroyImmediate(gameObject);
                Object.DestroyImmediate(mesh);
                Object.DestroyImmediate(material);
            }
        }

        [Test]
        public void AutoAtlasRendererEligibilityMatchesRuntimeAwareManualDefault()
        {
            var shader = Shader.Find("Hidden/InternalErrorShader");
            Assert.That(shader, Is.Not.Null);

            var material = new Material(shader);
            var mesh = new Mesh();
            var root = new GameObject("root");
            try
            {
                mesh.vertices = new[]
                {
                    Vector3.zero,
                    Vector3.right,
                    Vector3.up,
                };
                mesh.uv = new[]
                {
                    Vector2.zero,
                    Vector2.right,
                    Vector2.up,
                };
                mesh.SetTriangles(new[] { 0, 1, 2 }, 0);

                MeshRenderer AddRenderer(string name)
                {
                    var go = new GameObject(name);
                    go.transform.SetParent(root.transform, false);
                    var filter = go.AddComponent<MeshFilter>();
                    filter.sharedMesh = mesh;
                    var renderer = go.AddComponent<MeshRenderer>();
                    renderer.sharedMaterial = material;
                    return renderer;
                }

                var active = AddRenderer("active");
                var disabledRuntimeVisible = AddRenderer(
                    "disabledRuntimeVisible");
                disabledRuntimeVisible.enabled = false;
                var inactiveRuntimeVisible = AddRenderer(
                    "inactiveRuntimeVisible");
                inactiveRuntimeVisible.gameObject.SetActive(false);
                var permanentlyHidden = AddRenderer("permanentlyHidden");
                permanentlyHidden.enabled = false;
                var explicitlyExcluded = AddRenderer("explicitlyExcluded");

                var configuration =
                    root.AddComponent<TextureAtlas.AutoAtlasTexture>();
                configuration.ExcludedRenderers.Add(explicitlyExcluded);

                var targeting = new RendererTargetingForTest(new Renderer[]
                {
                    active,
                    disabledRuntimeVisible,
                    inactiveRuntimeVisible,
                    permanentlyHidden,
                    explicitlyExcluded,
                });
                var visibilityStates = new Dictionary<
                    Renderer, AtlasRendererVisibilityState>
                {
                    [disabledRuntimeVisible] =
                        new AtlasRendererVisibilityState(true, true),
                    [inactiveRuntimeVisible] =
                        new AtlasRendererVisibilityState(true, true),
                    [permanentlyHidden] =
                        new AtlasRendererVisibilityState(false, true),
                    [explicitlyExcluded] =
                        new AtlasRendererVisibilityState(true, true),
                };

                var manualDefault = TextureAtlas.AtlasTexture
                    .GetAtlasAllowedRenderers(
                        targeting,
                        targeting.EnumerateRenderer(),
                        includeDisabledRenderer: false,
                        visibilityStates)
                    .Where(renderer =>
                        renderer != explicitlyExcluded)
                    .ToHashSet();

                var auto = AutoAtlasTextureProcessor
                    .GetAutoAtlasAllowedRenderers(
                        targeting,
                        configuration,
                        visibilityStates)
                    .ToHashSet();

                Assert.That(auto.SetEquals(manualDefault), Is.True);
                Assert.That(auto.Contains(active), Is.True);
                Assert.That(
                    auto.Contains(disabledRuntimeVisible), Is.True);
                Assert.That(
                    auto.Contains(inactiveRuntimeVisible), Is.True);
                Assert.That(auto.Contains(permanentlyHidden), Is.False);
                Assert.That(auto.Contains(explicitlyExcluded), Is.False);

                var manualIncludeDisabled = TextureAtlas.AtlasTexture
                    .GetAtlasAllowedRenderers(
                        targeting,
                        targeting.EnumerateRenderer(),
                        includeDisabledRenderer: true,
                        visibilityStates)
                    .ToHashSet();
                Assert.That(
                    manualIncludeDisabled.Contains(permanentlyHidden),
                    Is.True);

                var standaloneSettings =
                    AutoAtlasTextureExecutionSettings.FromComponent(
                        configuration);
                standaloneSettings.IncludeDisabledRenderer = true;
                var standalone = AutoAtlasTextureProcessor
                    .GetAutoAtlasAllowedRenderers(
                        targeting,
                        standaloneSettings,
                        visibilityStates)
                    .ToHashSet();
                Assert.That(standalone.Contains(active), Is.True);
                Assert.That(
                    standalone.Contains(disabledRuntimeVisible), Is.True);
                Assert.That(
                    standalone.Contains(inactiveRuntimeVisible), Is.True);
                Assert.That(
                    standalone.Contains(permanentlyHidden), Is.True);
                Assert.That(
                    standalone.Contains(explicitlyExcluded), Is.False);

                var resolved = AutoAtlasTextureProcessor
                    .ResolveAutoAtlasTargetRenderers(
                        targeting,
                        configuration,
                        new HashSet<Material> { material },
                        visibilityStates)
                    .ToHashSet();
                Assert.That(resolved.SetEquals(auto), Is.True);

                var aao = AutoAtlasTextureProcessor
                    .GetAAONegotiationRenderers(
                        targeting,
                        configuration,
                        visibilityStates)
                    .ToHashSet();
                Assert.That(aao.SetEquals(auto), Is.True);
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(root);
                UnityEngine.Object.DestroyImmediate(mesh);
                UnityEngine.Object.DestroyImmediate(material);
            }
        }

        [Test]
        public void MaterialCandidateResolverSeparatesInactiveWithoutDuplicates()
        {
            var shader = Shader.Find("Hidden/InternalErrorShader");
            Assert.That(shader, Is.Not.Null);

            var activeMaterial = new Material(shader);
            var inactiveMaterial = new Material(shader);
            var editorOnlyMaterial = new Material(shader);
            var mesh = CreateDrawableTriangleMesh();
            var root = new GameObject("root");
            try
            {
                var active = AddTestRenderer(
                    root, "active", mesh, activeMaterial);
                var inactive = AddTestRenderer(
                    root, "inactive", mesh, inactiveMaterial);
                inactive.sharedMaterials =
                    new[] { activeMaterial, inactiveMaterial };
                inactive.gameObject.SetActive(false);

                var editorOnly = AddTestRenderer(
                    root, "editor-only", mesh, editorOnlyMaterial);
                editorOnly.gameObject.tag = "EditorOnly";

                var candidates =
                    AtlasTextureMaterialCandidateResolver.Resolve(root);

                Assert.That(
                    candidates.ActiveMaterials,
                    Is.EquivalentTo(new[] { activeMaterial }));
                Assert.That(
                    candidates.InactiveMaterials,
                    Is.EquivalentTo(new[] { inactiveMaterial }));
                Assert.That(
                    candidates.InactiveMaterials,
                    Has.No.Member(activeMaterial),
                    "A material already visible in the active section must not be duplicated in the inactive foldout.");
                Assert.That(
                    candidates.InactiveMaterials,
                    Has.No.Member(editorOnlyMaterial));
            }
            finally
            {
                Object.DestroyImmediate(root);
                Object.DestroyImmediate(mesh);
                Object.DestroyImmediate(activeMaterial);
                Object.DestroyImmediate(inactiveMaterial);
                Object.DestroyImmediate(editorOnlyMaterial);
            }
        }

        [Test]
        public void BakeCandidatesIncludeInactiveRenderersUsingSelectedMaterial()
        {
            var shader = Shader.Find("Hidden/InternalErrorShader");
            Assert.That(shader, Is.Not.Null);

            var targetMaterial = new Material(shader);
            var otherMaterial = new Material(shader);
            var mesh = CreateDrawableTriangleMesh();
            var root = new GameObject("root");
            try
            {
                var atlas = root.AddComponent<AtlasTexture>();
                atlas.AtlasTargetMaterials.Add(targetMaterial);
                atlas.BakeRendererSelectionVersion =
                    AtlasTexture.CurrentBakeRendererSelectionVersion;

                var active = AddTestRenderer(
                    root, "active", mesh, targetMaterial);
                var inactive = AddTestRenderer(
                    root, "inactive", mesh, targetMaterial);
                inactive.gameObject.SetActive(false);
                var other = AddTestRenderer(
                    root, "other", mesh, otherMaterial);
                other.gameObject.SetActive(false);

                var renderers = root
                    .GetComponentsInChildren<Renderer>(true);
                using var domain =
                    new NotWorkDomain(renderers, null);

                var candidates =
                    AtlasTextureBakeTargetResolver.GetCandidateRenderers(
                        atlas, domain);

                Assert.That(candidates, Has.Member(active));
                Assert.That(candidates, Has.Member(inactive));
                Assert.That(candidates, Has.No.Member(other));
                Assert.That(
                    AtlasTextureBakeTargetResolver.IsRendererIncluded(
                        atlas, domain, active),
                    Is.True);
                Assert.That(
                    AtlasTextureBakeTargetResolver.IsRendererIncluded(
                        atlas, domain, inactive),
                    Is.False);

                atlas.BakeIncludedInactiveRenderers.Add(inactive);
                Assert.That(
                    AtlasTextureBakeTargetResolver.IsRendererIncluded(
                        atlas, domain, inactive),
                    Is.True);
            }
            finally
            {
                Object.DestroyImmediate(root);
                Object.DestroyImmediate(mesh);
                Object.DestroyImmediate(targetMaterial);
                Object.DestroyImmediate(otherMaterial);
            }
        }

        [Test]
        public void BakeSelectionMigrationPreservesLegacyInactiveInclusion()
        {
            var shader = Shader.Find("Hidden/InternalErrorShader");
            Assert.That(shader, Is.Not.Null);

            var material = new Material(shader);
            var mesh = CreateDrawableTriangleMesh();
            var root = new GameObject("root");
            try
            {
                var atlas = root.AddComponent<AtlasTexture>();
                atlas.AtlasTargetMaterials.Add(material);
                atlas.AtlasSetting.IncludeDisabledRenderer = true;

                var inactive = AddTestRenderer(
                    root, "inactive", mesh, material);
                inactive.gameObject.SetActive(false);

                var renderers = root
                    .GetComponentsInChildren<Renderer>(true);
                using var domain =
                    new NotWorkDomain(renderers, null);

                Assert.That(
                    atlas.BakeRendererSelectionVersion,
                    Is.EqualTo(0));
                Assert.That(
                    AtlasTextureBakeTargetResolver.EnsureSelectionMigrated(
                        atlas, domain),
                    Is.True);
                Assert.That(
                    atlas.BakeRendererSelectionVersion,
                    Is.EqualTo(
                        AtlasTexture.CurrentBakeRendererSelectionVersion));
                Assert.That(
                    atlas.BakeIncludedInactiveRenderers,
                    Has.Member(inactive));
                Assert.That(
                    AtlasTextureBakeTargetResolver.IsRendererIncluded(
                        atlas, domain, inactive),
                    Is.True);

                Assert.That(
                    AtlasTextureBakeTargetResolver.EnsureSelectionMigrated(
                        atlas, domain),
                    Is.False,
                    "The migration must be idempotent after the version is updated.");
            }
            finally
            {
                Object.DestroyImmediate(root);
                Object.DestroyImmediate(mesh);
                Object.DestroyImmediate(material);
            }
        }

        [Test]
        public void BakeSelectionMigrationPreservesLegacyInactiveExclusion()
        {
            var shader = Shader.Find("Hidden/InternalErrorShader");
            Assert.That(shader, Is.Not.Null);

            var material = new Material(shader);
            var mesh = CreateDrawableTriangleMesh();
            var root = new GameObject("root");
            try
            {
                var atlas = root.AddComponent<AtlasTexture>();
                atlas.AtlasTargetMaterials.Add(material);
                atlas.AtlasSetting.IncludeDisabledRenderer = true;

                var inactive = AddTestRenderer(
                    root, "inactive", mesh, material);
                inactive.gameObject.SetActive(false);
                atlas.BakeExcludedRenderers.Add(inactive);

                var renderers = root
                    .GetComponentsInChildren<Renderer>(true);
                using var domain =
                    new NotWorkDomain(renderers, null);

                AtlasTextureBakeTargetResolver.EnsureSelectionMigrated(
                    atlas, domain);

                Assert.That(
                    atlas.BakeIncludedInactiveRenderers,
                    Has.No.Member(inactive));
                Assert.That(
                    AtlasTextureBakeTargetResolver.IsRendererIncluded(
                        atlas, domain, inactive),
                    Is.False);
            }
            finally
            {
                Object.DestroyImmediate(root);
                Object.DestroyImmediate(mesh);
                Object.DestroyImmediate(material);
            }
        }

        [Test]
        public void BakeSelectionMigrationDoesNotOptInNewInactiveTargetsByDefault()
        {
            var shader = Shader.Find("Hidden/InternalErrorShader");
            Assert.That(shader, Is.Not.Null);

            var material = new Material(shader);
            var mesh = CreateDrawableTriangleMesh();
            var root = new GameObject("root");
            try
            {
                var atlas = root.AddComponent<AtlasTexture>();
                atlas.AtlasTargetMaterials.Add(material);
                atlas.AtlasSetting.IncludeDisabledRenderer = false;

                var inactive = AddTestRenderer(
                    root, "inactive", mesh, material);
                inactive.gameObject.SetActive(false);

                var renderers = root
                    .GetComponentsInChildren<Renderer>(true);
                using var domain =
                    new NotWorkDomain(renderers, null);

                AtlasTextureBakeTargetResolver.EnsureSelectionMigrated(
                    atlas, domain);

                Assert.That(
                    atlas.BakeIncludedInactiveRenderers,
                    Has.No.Member(inactive));
                Assert.That(
                    AtlasTextureBakeTargetResolver.GetCandidateRenderers(
                        atlas, domain),
                    Has.Member(inactive),
                    "The renderer is visible as a bake candidate even though legacy selection did not include it.");
                Assert.That(
                    AtlasTextureBakeTargetResolver.IsRendererIncluded(
                        atlas, domain, inactive),
                    Is.False);
            }
            finally
            {
                Object.DestroyImmediate(root);
                Object.DestroyImmediate(mesh);
                Object.DestroyImmediate(material);
            }
        }

        [Test]
        public void RuntimeRelevantUntransformedMaterialConsumerFailsClosed()
        {
            var shader = Shader.Find("Hidden/InternalErrorShader");
            Assert.That(shader, Is.Not.Null);

            var material = new Material(shader);
            var root = new GameObject("active-consumer-root");
            try
            {
                MeshRenderer AddRenderer(string name)
                {
                    var go = new GameObject(name);
                    go.transform.SetParent(root.transform, false);
                    var renderer = go.AddComponent<MeshRenderer>();
                    renderer.sharedMaterial = material;
                    return renderer;
                }

                var transformed = AddRenderer("transformed");
                var unsupported = AddRenderer("unsupported");
                var disabled = AddRenderer("disabled");
                disabled.enabled = false;

                var targeting = new RendererTargetingForTest(
                    new Renderer[]
                    {
                        transformed,
                        unsupported,
                        disabled,
                    });
                var group = new HashSet<Material> { material };

                Assert.That(
                    AutoAtlasTextureProcessor
                        .HasRuntimeRelevantUntransformedMaterialConsumer(
                            targeting,
                            group,
                            new Renderer[] { transformed }),
                    Is.True);

                unsupported.enabled = false;
                Assert.That(
                    AutoAtlasTextureProcessor
                        .HasRuntimeRelevantUntransformedMaterialConsumer(
                            targeting,
                            group,
                            new Renderer[] { transformed }),
                    Is.False);
                Assert.That(
                    AutoAtlasTextureProcessor
                        .HasRuntimeRelevantUntransformedMaterialConsumer(
                            targeting,
                            group,
                            new Renderer[] { transformed },
                            new Dictionary<
                                Renderer, AtlasRendererVisibilityState>
                            {
                                [unsupported] =
                                    new AtlasRendererVisibilityState(
                                        true, true),
                            }),
                    Is.True,
                    "An initially hidden untransformed consumer that can become visible must still block global replacement.");

                unsupported.enabled = true;
                unsupported.gameObject.SetActive(false);
                Assert.That(
                    AutoAtlasTextureProcessor
                        .HasRuntimeRelevantUntransformedMaterialConsumer(
                            targeting,
                            group,
                            new Renderer[] { transformed }),
                    Is.False);
            }
            finally
            {
                Object.DestroyImmediate(root);
                Object.DestroyImmediate(material);
            }
        }

        private static Mesh CreateDrawableTriangleMesh()
        {
            var mesh = new Mesh
            {
                vertices = new[]
                {
                    Vector3.zero,
                    Vector3.right,
                    Vector3.up,
                },
                uv = new[]
                {
                    Vector2.zero,
                    Vector2.right,
                    Vector2.up,
                },
            };
            mesh.SetTriangles(new[] { 0, 1, 2 }, 0);
            return mesh;
        }

        private static MeshRenderer AddTestRenderer(
            GameObject root,
            string name,
            Mesh mesh,
            Material material)
        {
            var gameObject = new GameObject(name);
            gameObject.transform.SetParent(root.transform, false);
            var filter = gameObject.AddComponent<MeshFilter>();
            filter.sharedMesh = mesh;
            var renderer = gameObject.AddComponent<MeshRenderer>();
            renderer.sharedMaterial = material;
            return renderer;
        }

        private sealed class RendererTargetingForTest : IRendererTargeting
        {
            private readonly Renderer[] _renderers;

            internal RendererTargetingForTest(Renderer[] renderers)
            {
                _renderers = renderers;
            }

            public IEnumerable<Renderer> EnumerateRenderer() => _renderers;

            public bool OriginEqual(
                UnityEngine.Object left,
                UnityEngine.Object right)
            {
                return left == right;
            }
        }

        [Test]
        public void CandidateRejectsUnexecutableAtomicGroupMapping()
        {
            var baseline = Plan(new[]
            {
                Entry(64, 64, 1),
                Entry(64, 64, 1),
            });
            var merged = Plan(new[]
            {
                Entry(64, 64, 1),
            });

            var candidate = new AutoAtlasTextureMergePlanner.Candidate(
                new[] { 0, 1 },
                baseline,
                merged,
                new Vector2Int(64, 64),
                new Dictionary<string, Vector2Int>(),
                preservesAtomicGroupMapping: false);

            Assert.That(candidate.IsAdoptable, Is.False);
            Assert.That(
                candidate.RejectionReason,
                Is.EqualTo(
                    AutoAtlasTextureMergePlanner
                        .CandidateRejectionReason
                        .AtomicGroupMapping));
        }

        [Test]
        public void MaterialGroupingMustPreserveAtomicGroupBoundaries()
        {
            var shader = Shader.Find("Standard");
            Assert.That(shader, Is.Not.Null);

            var textureA = new Texture2D(4, 4);
            var textureB = new Texture2D(4, 4);
            var materialA = new Material(shader);
            var materialB = new Material(shader);
            try
            {
                var groups = new[]
                {
                    new AutoAtlasTextureMergePlanner.PreparedGroup
                    {
                        Id = 0,
                        Materials = new HashSet<Material> { materialA },
                    },
                    new AutoAtlasTextureMergePlanner.PreparedGroup
                    {
                        Id = 1,
                        Materials = new HashSet<Material> { materialB },
                    },
                };

                var disjointProperties =
                    new Dictionary<
                        Material,
                        IReadOnlyDictionary<string, Texture>>
                    {
                        [materialA] =
                            new Dictionary<string, Texture>
                            {
                                ["_MainTex"] = textureA,
                            },
                        [materialB] =
                            new Dictionary<string, Texture>
                            {
                                ["_BumpMap"] = textureB,
                            },
                    };

                Assert.That(
                    AutoAtlasTextureMergePlanner
                        .PreservesAtomicGroupBoundaries(
                            groups,
                            disjointProperties),
                    Is.False,
                    "Compatible disjoint properties are grouped together, so one material group would span two planned atomic regions.");

                var conflictingSharedProperty =
                    new Dictionary<
                        Material,
                        IReadOnlyDictionary<string, Texture>>
                    {
                        [materialA] =
                            new Dictionary<string, Texture>
                            {
                                ["_MainTex"] = textureA,
                            },
                        [materialB] =
                            new Dictionary<string, Texture>
                            {
                                ["_MainTex"] = textureB,
                            },
                    };

                Assert.That(
                    AutoAtlasTextureMergePlanner
                        .PreservesAtomicGroupBoundaries(
                            groups,
                            conflictingSharedProperty),
                    Is.True,
                    "Different textures on the same property force separate material groups and keep the atomic regions executable.");
            }
            finally
            {
                Object.DestroyImmediate(materialA);
                Object.DestroyImmediate(materialB);
                Object.DestroyImmediate(textureA);
                Object.DestroyImmediate(textureB);
            }
        }

        [Test]
        public void CandidateRejectsComplementaryPropertyDensityInflation()
        {
            // Two groups have opposite high/low requirements across two
            // properties. Putting both properties on one wider shared layout
            // raises both generated property textures to the larger envelope.
            var baseline = Plan(new[]
            {
                Entry(64, 64, 1),
                Entry(32, 32, 1),
                Entry(32, 32, 1),
                Entry(64, 64, 1),
            });
            var merged = Plan(new[]
            {
                Entry(128, 64, 1),
                Entry(128, 64, 1),
            });

            Assert.That(merged.PixelCount, Is.GreaterThan(baseline.PixelCount));
            Assert.That(Candidate(baseline, merged).IsAdoptable, Is.False);
        }

        [Test]
        public void CandidateCanBecomeBeneficialAfterAddingThirdGroup()
        {
            // The pair is not useful by itself: the shared output only ties the
            // two standalone textures. A third group can make the same shared
            // output strictly cheaper than keeping all three independently.
            var pairBaseline = Plan(new[]
            {
                Entry(64, 64, 1),
                Entry(64, 64, 1),
            });
            var pairMerged = Plan(new[]
            {
                Entry(128, 64, 1),
            });

            Assert.That(
                Candidate(pairBaseline, pairMerged, new[] { 0, 1 }).IsAdoptable,
                Is.False);

            var tripleBaseline = Plan(new[]
            {
                Entry(64, 64, 1),
                Entry(64, 64, 1),
                Entry(128, 64, 1),
            });
            var tripleMerged = Plan(new[]
            {
                Entry(128, 64, 1),
            });

            Assert.That(
                tripleMerged.PixelCount,
                Is.LessThan(tripleBaseline.PixelCount));
            Assert.That(
                Candidate(
                    tripleBaseline,
                    tripleMerged,
                    new[] { 0, 1, 2 }).IsAdoptable,
                Is.True);
        }

        [Test]
        public void TextureMergingExclusionAppliesToRendererWithoutRemovingGroup()
        {
            var root = new GameObject("TextureMergingExclusionTest");
            try
            {
                var a = root.AddComponent<MeshRenderer>();
                var bObject = new GameObject("Other");
                bObject.transform.SetParent(root.transform);
                var b = bObject.AddComponent<MeshRenderer>();
                var exclusions = new HashSet<Renderer> { a };

                Assert.That(AutoAtlasTextureProcessor.IsExcludedFromTextureMerging(
                    new HashSet<Material>(), new Renderer[] { a, b },
                    new HashSet<Material>(), exclusions), Is.True);
                Assert.That(AutoAtlasTextureProcessor.IsExcludedFromTextureMerging(
                    new HashSet<Material>(), new Renderer[] { b },
                    new HashSet<Material>(), exclusions), Is.False);
            }
            finally
            {
                Object.DestroyImmediate(root);
            }
        }

        [Test]
        public void TextureMergingExclusionAppliesToAnyMaterialInAtomicGroup()
        {
            var shader = Shader.Find("Hidden/InternalErrorShader");
            Assert.That(shader, Is.Not.Null);
            var material = new Material(shader);
            try
            {
                Assert.That(AutoAtlasTextureProcessor.IsExcludedFromTextureMerging(
                    new HashSet<Material> { material },
                    System.Array.Empty<Renderer>(),
                    new HashSet<Material> { material },
                    new HashSet<Renderer>()), Is.True);
                Assert.That(AutoAtlasTextureProcessor.IsExcludedFromTextureMerging(
                    new HashSet<Material> { material },
                    System.Array.Empty<Renderer>(),
                    new HashSet<Material>(),
                    new HashSet<Renderer>()), Is.False);
            }
            finally
            {
                Object.DestroyImmediate(material);
            }
        }

        [Test]
        public void SkylineDominanceRequiresEveryColumnNoHigher()
        {
            System.Func<IReadOnlyList<int>, IReadOnlyList<int>, bool> dominates =
                AutoAtlasTextureMergePlanner.SkylineDominates;
            Assert.That(dominates(new[] { 128, 256 }, new[] { 256, 256 }),
                Is.True);
            Assert.That(dominates(new[] { 256, 256 }, new[] { 128, 256 }),
                Is.False);
            Assert.That(dominates(new[] { 128, 256 }, new[] { 256, 128 }),
                Is.False);
            Assert.That(dominates(new[] { 128, 256 }, new[] { 128, 256 }),
                Is.True);
            Assert.That(dominates(new[] { 128 }, new[] { 128, 128 }),
                Is.False);
        }

        [Test]
        public void TwoDimensionalRegionPaddingPreservesAtomicPixelDistance()
        {
            const float profilePadding = 0.01f;
            const int atlasWidth = 4096;
            const int regionWidth = 2048;

            var atlasUvPadding =
                AutoAtlas2DMergeIslandRelocator.GetRegionPaddingInAtlasUv(
                    profilePadding,
                    atlasWidth,
                    regionWidth);

            Assert.That(
                atlasUvPadding,
                Is.EqualTo(0.005f).Within(0.000001f));
            Assert.That(
                atlasUvPadding * atlasWidth,
                Is.EqualTo(profilePadding * regionWidth)
                    .Within(0.00001f));
        }

        [Test]
        public void TwoDimensionalPackingRejectsOverlapAndOutOfBounds()
        {
            var valid = new Dictionary<int, RectInt>
            {
                [3] = new RectInt(0, 0, 512, 512),
                [6] = new RectInt(512, 0, 512, 1024),
            };
            Assert.That(AutoAtlas2DMergeIslandRelocator.ValidatePlannedRegions(
                valid, 1024), Is.True);

            var overlap = new Dictionary<int, RectInt>
            {
                [3] = new RectInt(0, 0, 512, 512),
                [6] = new RectInt(256, 256, 512, 512),
            };
            Assert.That(AutoAtlas2DMergeIslandRelocator.ValidatePlannedRegions(
                overlap, 1024), Is.False);

            var outside = new Dictionary<int, RectInt>
            {
                [3] = new RectInt(0, 0, 512, 512),
                [6] = new RectInt(512, 0, 1024, 512),
            };
            Assert.That(AutoAtlas2DMergeIslandRelocator.ValidatePlannedRegions(
                outside, 1024), Is.False);

            Assert.That(AutoAtlas2DMergeIslandRelocator.ValidatePlannedRegions(
                new Dictionary<int, RectInt> { [3] = valid[3] }, 1024),
                Is.False);
        }

        [Test]
        public void TwoDimensionalPackingAcceptsValidNfdhPlacementNearBorder()
        {
            // Reproduces the measured g3 box from Seiran_Koiboshi:
            // the island is within its assigned 1024x371 region, but the
            // previous check added another full 0.01 padding to its right
            // edge and rejected it.
            var island = new net.rs64.TexTransCore.UVIsland.IslandTransform
            {
                Position = new System.Numerics.Vector2(
                    0.8077679f, 0.00999999f),
                Size = new System.Numerics.Vector2(
                    0.9929619f - 0.8077679f,
                    0.06580675f - 0.00999999f),
            };

            Assert.That(
                AutoAtlas2DMergeIslandRelocator.IsWithinPlannedRegion(
                    island, new RectInt(0, 0, 1024, 371), 1024, 0.01f),
                Is.True);
        }

        [Test]
        public void TwoDimensionalPackingProtectsInternalRegionPadding()
        {
            // Internal region boundaries must preserve the complete
            // pixel-equivalent transfer padding. For a 512-wide region in a
            // 1024 atlas, 0.01 profile padding becomes 0.005 atlas UV.
            var island = new net.rs64.TexTransCore.UVIsland.IslandTransform
            {
                Position = new System.Numerics.Vector2(0.491f, 0.01f),
                Size = new System.Numerics.Vector2(0.005f, 0.04f),
            };
            Assert.That(
                AutoAtlas2DMergeIslandRelocator.IsWithinPlannedRegion(
                    island, new RectInt(0, 0, 512, 512), 1024, 0.01f),
                Is.False);

            island.Position = new System.Numerics.Vector2(0.49f, 0.01f);
            island.Size = new System.Numerics.Vector2(0.005f, 0.04f);
            Assert.That(
                AutoAtlas2DMergeIslandRelocator.IsWithinPlannedRegion(
                    island, new RectInt(0, 0, 512, 512), 1024, 0.01f),
                Is.True);
        }


        [Test]
        public void TwoDimensionalPackingAllowsMeasuredOuterEdgePaddingClip()
        {
            // Seiran_ShuwashuwaPearl g5 measured box. The region reaches the
            // right edge of the final atlas, so transfer padding may be clipped
            // there exactly as in ordinary AtlasTexture.
            var islands = new[]
            {
                new net.rs64.TexTransCore.UVIsland.IslandTransform
                {
                    Position = new System.Numerics.Vector2(
                        0.9964194f, 0.7842883f),
                    Size = new System.Numerics.Vector2(
                        0.9970903f - 0.9964194f,
                        0.7842968f - 0.7842883f),
                },
                new net.rs64.TexTransCore.UVIsland.IslandTransform
                {
                    Position = new System.Numerics.Vector2(0.51f, 0.745f),
                    Size = new System.Numerics.Vector2(0.05f, 0.025f),
                },
            };
            var region = new RectInt(512, 751, 512, 83);
            foreach (var island in islands)
                Assert.That(
                    AutoAtlas2DMergeIslandRelocator.IsWithinPlannedRegion(
                        island, region, 1024, 0.01f), Is.True);

            var before = islands.Select(island => island.Position).ToArray();
            Assert.That(
                AutoAtlas2DMergeIslandRelocator.TryTranslateIslandsWithinPlannedRegion(
                    islands, region, 1024, 0.01f), Is.True);
            Assert.That(islands.Select(island => island.Position),
                Is.EqualTo(before));
        }

        [Test]
        public void TwoDimensionalPackingLeavesValidGroupUnchanged()
        {
            var island = new net.rs64.TexTransCore.UVIsland.IslandTransform
            {
                Position = new System.Numerics.Vector2(0.55f, 0.75f),
                Size = new System.Numerics.Vector2(0.1f, 0.025f),
            };
            var previous = island.Position;
            Assert.That(
                AutoAtlas2DMergeIslandRelocator.TryTranslateIslandsWithinPlannedRegion(
                    new[] { island }, new RectInt(512, 751, 512, 83),
                    1024, 0.01f), Is.True);
            Assert.That(island.Position, Is.EqualTo(previous));
        }

        [Test]
        public void TwoDimensionalPackingRejectsUntranslatableInternalGroupWithoutMutation()
        {
            var islands = new[]
            {
                new net.rs64.TexTransCore.UVIsland.IslandTransform
                {
                    Position = new System.Numerics.Vector2(0.257f, 0.30f),
                    Size = new System.Numerics.Vector2(0.01f, 0.01f),
                },
                new net.rs64.TexTransCore.UVIsland.IslandTransform
                {
                    Position = new System.Numerics.Vector2(0.745f, 0.30f),
                    Size = new System.Numerics.Vector2(0.004f, 0.01f),
                },
            };
            var before0 = islands[0].Position;
            var before1 = islands[1].Position;
            Assert.That(
                AutoAtlas2DMergeIslandRelocator.TryTranslateIslandsWithinPlannedRegion(
                    islands, new RectInt(256, 256, 512, 512),
                    1024, 0.01f), Is.False);
            Assert.That(islands[0].Position, Is.EqualTo(before0));
            Assert.That(islands[1].Position, Is.EqualTo(before1));
        }

        [Test]
        public void TwoDimensionalPackingPreservesRotatedIslandGeometry()
        {
            var island = new net.rs64.TexTransCore.UVIsland.IslandTransform
            {
                Position = new System.Numerics.Vector2(0.994f, 0.77f),
                Size = new System.Numerics.Vector2(0.006f, 0.003f),
                Rotation = -(float)System.Math.PI / 2f,
            };
            var originalSize = island.Size;
            var originalRotation = island.Rotation;
            var region = new RectInt(512, 751, 512, 83);
            Assert.That(
                AutoAtlas2DMergeIslandRelocator.TryTranslateIslandsWithinPlannedRegion(
                    new[] { island }, region, 1024, 0.01f), Is.True);
            Assert.That(AutoAtlas2DMergeIslandRelocator.IsWithinPlannedRegion(
                island, region, 1024, 0.01f), Is.True);
            Assert.That(island.Size.X, Is.EqualTo(originalSize.X));
            Assert.That(island.Size.Y, Is.EqualTo(originalSize.Y));
            Assert.That(island.Rotation, Is.EqualTo(originalRotation));
        }

        [Test]
        public void TwoDimensionalPackingRejectsExcessiveHeightWithoutMutation()
        {
            var island = new net.rs64.TexTransCore.UVIsland.IslandTransform
            {
                Position = new System.Numerics.Vector2(0.52f, 0.735f),
                Size = new System.Numerics.Vector2(0.1f, 0.076f),
            };
            var originalPosition = island.Position;
            Assert.That(
                AutoAtlas2DMergeIslandRelocator.TryTranslateIslandsWithinPlannedRegion(
                    new[] { island }, new RectInt(512, 751, 512, 83),
                    1024, 0.01f), Is.False);
            Assert.That(island.Position, Is.EqualTo(originalPosition));
        }

        [Test]
        public void TwoDimensionalSelectionCarriesPlannedRegions()
        {
            var baseline = Plan(new[]
            {
                Entry(64, 64, 1),
                Entry(64, 64, 1),
            });
            var merged = Plan(new[]
            {
                Entry(64, 64, 1),
            });
            var candidate = Candidate(baseline, merged, new[] { 3, 6 });
            var regions = new Dictionary<int, RectInt>
            {
                [3] = new RectInt(0, 0, 256, 128),
                [6] = new RectInt(256, 0, 256, 128),
            };
            var selection = new AutoAtlasTextureMergePlanner.MergeSelection(
                candidate, regions);

            Assert.That(selection.PackedRegions, Is.Not.Null);
            Assert.That(selection.GroupIds, Is.EqualTo(new[] { 3, 6 }));
            Assert.That(selection.PackedRegions[6].x, Is.EqualTo(256));
            Assert.That(selection.PredictedSavingBytes, Is.GreaterThan(0));
        }

        [Test]
        public void ProductionSelectionUsesTwoDimensionalCandidatesOnly()
        {
            var baseline = Plan(new[]
            {
                Entry(128, 128, 1),
                Entry(128, 128, 1),
            });
            var merged = Plan(new[]
            {
                Entry(128, 128, 1),
            });
            var candidate = Candidate(baseline, merged, new[] { 1, 2 });
            var band = new AutoAtlasTextureMergePlanner.MergeSelection(candidate);
            var regions = new Dictionary<int, RectInt>
            {
                [1] = new RectInt(0, 0, 256, 128),
                [2] = new RectInt(256, 0, 256, 128),
            };
            var twoD = new AutoAtlasTextureMergePlanner.MergeSelection(
                candidate, regions);

            var selected = AutoAtlasTextureMergePlanner
                .SelectTwoDimensionalMerges(new[] { band, twoD });

            Assert.That(selected.Count, Is.EqualTo(1));
            Assert.That(selected[0], Is.SameAs(twoD));
        }

        [Test]
        public void ExactSelectionCombinesDisjointCandidatesWhenGreedyMissesSaving()
        {
            // A wins individually, but B+C are disjoint and save more.
            var a = TwoGroupSelection(0, 1, 16);
            var b = TwoGroupSelection(0, 2, 24);
            var c = TwoGroupSelection(1, 3, 24);
            Assert.That(a.PredictedSavingBytes, Is.GreaterThan(b.PredictedSavingBytes));
            Assert.That(a.PredictedSavingBytes, Is.LessThan(
                b.PredictedSavingBytes + c.PredictedSavingBytes));

            var selected = AutoAtlasTextureMergePlanner
                .SelectTwoDimensionalMerges(new[] { a, b, c });

            Assert.That(selected, Is.EquivalentTo(new[] { b, c }));
            Assert.That(selected[0], Is.SameAs(b));
            Assert.That(selected[1], Is.SameAs(c));

        }

        [Test]
        public void ExactSelectionPreservesGreedyOnEqualTotalSaving()
        {
            var a = TwoGroupSelection(0, 1, 16);
            var b = TwoGroupSelection(0, 2, 16);
            var independent = TwoGroupSelection(3, 4, 16);

            var selected = AutoAtlasTextureMergePlanner
                .SelectTwoDimensionalMerges(new[] { a, b, independent });

            Assert.That(selected, Is.EqualTo(new[] { a, independent }));

        }

        [Test]
        public void LargeCandidateSetUsesExactGroupMaskWhenGroupUniverseIsBounded()
        {
            var candidates = new List<AutoAtlasTextureMergePlanner.MergeSelection>();
            for (var id = 1; id <= 17; id++)
                candidates.Add(TwoGroupSelection(
                    0, id, id % 2 == 0 ? 16 : 24));

            var selected = AutoAtlasTextureMergePlanner
                .SelectTwoDimensionalMerges(candidates);

            Assert.That(selected.Count, Is.EqualTo(1));
            Assert.That(selected[0], Is.SameAs(candidates[1]));
        }

        [Test]
        public void ExactGroupMaskImprovesGreedyWithMoreThanSixteenCandidates()
        {
            var a = TwoGroupSelection(0, 1, 16);
            var b = TwoGroupSelection(0, 2, 24);
            var c = TwoGroupSelection(1, 3, 24);
            var candidates =
                new List<AutoAtlasTextureMergePlanner.MergeSelection>
                {
                    a, b, c,
                };
            for (var id = 4; id <= 17; id++)
                candidates.Add(TwoGroupSelection(0, id, 32));

            Assert.That(candidates.Count, Is.EqualTo(17));

            var selected = AutoAtlasTextureMergePlanner
                .SelectTwoDimensionalMerges(candidates);

            Assert.That(selected, Is.EqualTo(new[] { b, c }));
        }

        [Test]
        public void LargeGroupUniverseKeepsBoundedGreedySelection()
        {
            var candidates = new List<AutoAtlasTextureMergePlanner.MergeSelection>();
            for (var id = 1; id <= 21; id++)
                candidates.Add(TwoGroupSelection(
                    0, id, id % 2 == 0 ? 16 : 24));

            var selected = AutoAtlasTextureMergePlanner
                .SelectTwoDimensionalMerges(candidates);

            Assert.That(selected.Count, Is.EqualTo(1));
            Assert.That(selected[0], Is.SameAs(candidates[1]));
        }

        private static AutoAtlasTextureMergePlanner.MergeSelection
            TwoGroupSelection(int left, int right, int mergedWidth)
        {
            var baseline = Plan(new[]
            {
                Entry(32, 32, 1),
                Entry(32, 32, 1),
            });
            var merged = Plan(new[]
            {
                Entry(mergedWidth, mergedWidth, 1),
            });
            var candidate = Candidate(baseline, merged, new[] { left, right });
            Assert.That(candidate.IsAdoptable, Is.True);
            return new AutoAtlasTextureMergePlanner.MergeSelection(
                candidate,
                new Dictionary<int, RectInt>
                {
                    [left] = new RectInt(0, 0, 32, 32),
                    [right] = new RectInt(32, 0, 32, 32),
                });
        }

        [Test]
        public void ExecutionQueuePreservesDisjointMergedAndStandaloneGroups()
        {
            var textures = new[]
            {
                new Texture2D(2, 2),
                new Texture2D(2, 2),
                new Texture2D(2, 2),
                new Texture2D(2, 2),
                new Texture2D(2, 2),
            };
            try
            {
                var groups = new AutoAtlasTextureMergePlanner.PreparedGroup[textures.Length];
                for (var id = 0; id < groups.Length; id++)
                {
                    groups[id] = new AutoAtlasTextureMergePlanner.PreparedGroup
                    {
                        Id = id,
                        SourceTextures = new HashSet<Texture> { textures[id] },
                    };
                }

                var first = TwoGroupSelection(0, 1, 16);
                var second = TwoGroupSelection(3, 4, 16);
                var queue = AutoAtlasTextureProcessor.CreateExecutionGroups(
                    groups, new[] { first, second });

                Assert.That(queue.Count, Is.EqualTo(3));
                var mergedFirst = queue.Dequeue();
                Assert.That(mergedFirst.MergeSelection, Is.SameAs(first));
                Assert.That(mergedFirst.SourceTextures, Is.EquivalentTo(
                    new Texture[] { textures[0], textures[1] }));
                var mergedSecond = queue.Dequeue();
                Assert.That(mergedSecond.MergeSelection, Is.SameAs(second));
                Assert.That(mergedSecond.SourceTextures, Is.EquivalentTo(
                    new Texture[] { textures[3], textures[4] }));
                var standalone = queue.Dequeue();
                Assert.That(standalone.MergeSelection, Is.Null);
                Assert.That(
                    standalone.Mode,
                    Is.EqualTo(
                        AutoAtlasTextureProcessor.ExecutionMode.Atlas));
                Assert.That(standalone.AtomicGroup, Is.SameAs(groups[2]));
                Assert.That(standalone.SourceTextures,
                    Is.SameAs(groups[2].SourceTextures));
                Assert.That(queue.Count, Is.Zero);
            }
            finally
            {
                foreach (var texture in textures)
                    UnityEngine.Object.DestroyImmediate(texture);
            }
        }

        [Test]
        public void FailedMergeQueuesOriginalAtomicGroupsWithoutTouchingOtherWork()
        {
            var textures = new[]
            {
                new Texture2D(2, 2),
                new Texture2D(2, 2),
                new Texture2D(2, 2),
                new Texture2D(2, 2),
                new Texture2D(2, 2),
            };
            try
            {
                var groups = new AutoAtlasTextureMergePlanner.PreparedGroup[textures.Length];
                for (var id = 0; id < groups.Length; id++)
                {
                    groups[id] = new AutoAtlasTextureMergePlanner.PreparedGroup
                    {
                        Id = id,
                        SourceTextures = new HashSet<Texture> { textures[id] },
                    };
                }

                var failed = TwoGroupSelection(0, 1, 16);
                var unaffected = TwoGroupSelection(3, 4, 16);
                var queue = AutoAtlasTextureProcessor.CreateExecutionGroups(
                    groups, new[] { failed, unaffected });

                Assert.That(queue.Dequeue().MergeSelection, Is.SameAs(failed));
                AutoAtlasTextureProcessor.EnqueueNonMergedFallback(
                    queue, failed, groups);

                // Other selected merges and originally standalone groups stay
                // ahead of the failed merge's individual retries.
                Assert.That(queue.Count, Is.EqualTo(4));
                Assert.That(queue.Dequeue().MergeSelection, Is.SameAs(unaffected));
                var originalStandalone = queue.Dequeue();
                Assert.That(originalStandalone.MergeSelection, Is.Null);
                Assert.That(originalStandalone.SourceTextures,
                    Is.SameAs(groups[2].SourceTextures));
                var retry0 = queue.Dequeue();
                var retry1 = queue.Dequeue();
                Assert.That(retry0.MergeSelection, Is.Null);
                Assert.That(retry1.MergeSelection, Is.Null);
                Assert.That(
                    retry0.Mode,
                    Is.EqualTo(
                        AutoAtlasTextureProcessor.ExecutionMode.Atlas));
                Assert.That(
                    retry1.Mode,
                    Is.EqualTo(
                        AutoAtlasTextureProcessor.ExecutionMode.Atlas));
                Assert.That(retry0.AtomicGroup, Is.SameAs(groups[0]));
                Assert.That(retry1.AtomicGroup, Is.SameAs(groups[1]));
                Assert.That(retry0.SourceTextures, Is.SameAs(groups[0].SourceTextures));
                Assert.That(retry1.SourceTextures, Is.SameAs(groups[1].SourceTextures));
                Assert.That(queue.Count, Is.Zero);
            }
            finally
            {
                foreach (var texture in textures)
                    UnityEngine.Object.DestroyImmediate(texture);
            }
        }

        [Test]
        public void VisibilityAnalyzerFindsEffectiveToggleability()
        {
            var root = new GameObject("Avatar");
            var outfit = new GameObject("Outfit");
            var underOutfit = new GameObject("Part");
            var accessory = new GameObject("Accessory");
            var staticItem = new GameObject("Static");
            try
            {
                outfit.transform.SetParent(root.transform);
                underOutfit.transform.SetParent(outfit.transform);
                accessory.transform.SetParent(root.transform);
                staticItem.transform.SetParent(root.transform);

                var outfitRenderer = underOutfit.AddComponent<MeshRenderer>();
                var accessoryRenderer = accessory.AddComponent<MeshRenderer>();
                var staticRenderer = staticItem.AddComponent<MeshRenderer>();

                var clip = nadena.dev.ndmf.animator.VirtualClip.Create("toggles");
                clip.SetFloatCurve(
                    UnityEditor.EditorCurveBinding.FloatCurve(
                        "Outfit", typeof(GameObject), "m_IsActive"),
                    AnimationCurve.Constant(0f, 1f, 0f));
                clip.SetFloatCurve(
                    UnityEditor.EditorCurveBinding.FloatCurve(
                        "Accessory", typeof(MeshRenderer), "m_Enabled"),
                    AnimationCurve.Constant(0f, 1f, 0f));

                var index = new nadena.dev.ndmf.animator.AnimationIndex(
                    new nadena.dev.ndmf.animator.VirtualNode[] { clip });
                var paths = new Dictionary<Transform, string>
                {
                    [root.transform] = "",
                    [outfit.transform] = "Outfit",
                    [underOutfit.transform] = "Outfit/Part",
                    [accessory.transform] = "Accessory",
                    [staticItem.transform] = "Static",
                };

                var states = AtlasRendererVisibilityAnalyzer.Analyze(
                    index,
                    root.transform,
                    new Renderer[]
                    {
                        outfitRenderer,
                        accessoryRenderer,
                        staticRenderer,
                    },
                    transform => new[] { paths[transform] });

                Assert.That(
                    states[outfitRenderer].CanBecomeVisible, Is.True);
                Assert.That(
                    states[outfitRenderer].CanBecomeHidden, Is.True);
                Assert.That(
                    states[outfitRenderer].CanToggleVisibility, Is.True);
                Assert.That(
                    states[accessoryRenderer].CanToggleVisibility, Is.True);
                Assert.That(
                    states[staticRenderer].CanBecomeVisible, Is.True);
                Assert.That(
                    states[staticRenderer].CanBecomeHidden, Is.False);
                Assert.That(
                    states[staticRenderer].CanToggleVisibility, Is.False);
            }
            finally
            {
                Object.DestroyImmediate(root);
            }
        }

        [Test]
        public void VisibilityAnalyzerRejectsChildToggleUnderPermanentOffParent()
        {
            var root = new GameObject("Avatar");
            var parent = new GameObject("Parent");
            var child = new GameObject("Child");
            try
            {
                parent.transform.SetParent(root.transform);
                child.transform.SetParent(parent.transform);
                parent.SetActive(false);
                child.SetActive(false);
                var renderer = child.AddComponent<MeshRenderer>();

                var clip = nadena.dev.ndmf.animator.VirtualClip.Create(
                    "child-only-toggle");
                clip.SetFloatCurve(
                    UnityEditor.EditorCurveBinding.FloatCurve(
                        "Parent/Child",
                        typeof(GameObject),
                        "m_IsActive"),
                    AnimationCurve.Constant(0f, 1f, 1f));
                var index = new nadena.dev.ndmf.animator.AnimationIndex(
                    new nadena.dev.ndmf.animator.VirtualNode[] { clip });

                var states = AtlasRendererVisibilityAnalyzer.Analyze(
                    index,
                    root.transform,
                    new Renderer[] { renderer },
                    transform =>
                    {
                        if (transform == root.transform)
                            return new[] { "" };
                        if (transform == parent.transform)
                            return new[] { "Parent" };
                        return new[] { "Parent/Child" };
                    });

                Assert.That(
                    states[renderer].CanBecomeVisible, Is.False);
                Assert.That(
                    states[renderer].CanBecomeHidden, Is.True);
                Assert.That(
                    states[renderer].CanToggleVisibility, Is.False);
            }
            finally
            {
                Object.DestroyImmediate(root);
            }
        }

        [Test]
        public void VisibilityAnalyzerHonorsActiveInheritanceBreaker()
        {
            var root = new GameObject("Avatar");
            var parent = new GameObject("Parent");
            var child = new GameObject("Child");
            try
            {
                parent.transform.SetParent(root.transform);
                child.transform.SetParent(parent.transform);
                parent.SetActive(false);
                child.AddComponent<IsActiveInheritBreaker>();
                var renderer = child.AddComponent<MeshRenderer>();
                renderer.enabled = false;

                var clip = nadena.dev.ndmf.animator.VirtualClip.Create(
                    "renderer-enable");
                clip.SetFloatCurve(
                    UnityEditor.EditorCurveBinding.FloatCurve(
                        "Parent/Child",
                        typeof(MeshRenderer),
                        "m_Enabled"),
                    AnimationCurve.Constant(0f, 1f, 1f));
                var index = new nadena.dev.ndmf.animator.AnimationIndex(
                    new nadena.dev.ndmf.animator.VirtualNode[] { clip });

                var states = AtlasRendererVisibilityAnalyzer.Analyze(
                    index,
                    root.transform,
                    new Renderer[] { renderer },
                    transform =>
                    {
                        if (transform == root.transform)
                            return new[] { "" };
                        if (transform == parent.transform)
                            return new[] { "Parent" };
                        return new[] { "Parent/Child" };
                    });

                Assert.That(
                    states[renderer].CanBecomeVisible, Is.True);
                Assert.That(
                    states[renderer].CanToggleVisibility, Is.True);
            }
            finally
            {
                Object.DestroyImmediate(root);
            }
        }

        [Test]
        public void VisibilityAnalyzerAcceptsWhenEveryFalseGateCanBecomeTrue()
        {
            var root = new GameObject("Avatar");
            var parent = new GameObject("Parent");
            var child = new GameObject("Child");
            try
            {
                parent.transform.SetParent(root.transform);
                child.transform.SetParent(parent.transform);
                parent.SetActive(false);
                child.SetActive(false);
                var renderer = child.AddComponent<MeshRenderer>();
                renderer.enabled = false;

                var clip = nadena.dev.ndmf.animator.VirtualClip.Create(
                    "all-gates");
                clip.SetFloatCurve(
                    UnityEditor.EditorCurveBinding.FloatCurve(
                        "Parent", typeof(GameObject), "m_IsActive"),
                    AnimationCurve.Constant(0f, 1f, 1f));
                clip.SetFloatCurve(
                    UnityEditor.EditorCurveBinding.FloatCurve(
                        "Parent/Child",
                        typeof(GameObject),
                        "m_IsActive"),
                    AnimationCurve.Constant(0f, 1f, 1f));
                clip.SetFloatCurve(
                    UnityEditor.EditorCurveBinding.FloatCurve(
                        "Parent/Child",
                        typeof(MeshRenderer),
                        "m_Enabled"),
                    AnimationCurve.Constant(0f, 1f, 1f));
                var index = new nadena.dev.ndmf.animator.AnimationIndex(
                    new nadena.dev.ndmf.animator.VirtualNode[] { clip });

                var states = AtlasRendererVisibilityAnalyzer.Analyze(
                    index,
                    root.transform,
                    new Renderer[] { renderer },
                    transform =>
                    {
                        if (transform == root.transform)
                            return new[] { "" };
                        if (transform == parent.transform)
                            return new[] { "Parent" };
                        return new[] { "Parent/Child" };
                    });

                Assert.That(
                    states[renderer].CanBecomeVisible, Is.True);
                Assert.That(
                    states[renderer].CanBecomeHidden, Is.True);
                Assert.That(
                    states[renderer].CanToggleVisibility, Is.True);
            }
            finally
            {
                Object.DestroyImmediate(root);
            }
        }

        [Test]
        public void VisibilityAnalyzerChecksAllMappedAliases()
        {
            var root = new GameObject("Avatar");
            var clothing = new GameObject("NewClothing");
            var clothingPart = new GameObject("Part");
            try
            {
                clothing.transform.SetParent(root.transform);
                clothingPart.transform.SetParent(clothing.transform);
                clothing.SetActive(false);
                var renderer = clothingPart.AddComponent<MeshRenderer>();

                var clip = nadena.dev.ndmf.animator.VirtualClip.Create(
                    "old-alias");
                clip.SetFloatCurve(
                    UnityEditor.EditorCurveBinding.FloatCurve(
                        "OldClothing",
                        typeof(GameObject),
                        "m_IsActive"),
                    AnimationCurve.Constant(0f, 1f, 1f));
                var index = new nadena.dev.ndmf.animator.AnimationIndex(
                    new nadena.dev.ndmf.animator.VirtualNode[] { clip });
                var paths = new Dictionary<Transform, string[]>
                {
                    [root.transform] = new[] { "" },
                    [clothing.transform] =
                        new[] { "NewClothing", "OldClothing" },
                    [clothingPart.transform] =
                        new[] { "NewClothing/Part" },
                };

                var firstPathOnly = AtlasRendererVisibilityAnalyzer.Analyze(
                    index,
                    root.transform,
                    new Renderer[] { renderer },
                    transform => paths[transform].Take(1));
                Assert.That(
                    firstPathOnly[renderer].CanBecomeVisible, Is.False);

                var withAliases = AtlasRendererVisibilityAnalyzer.Analyze(
                    index,
                    root.transform,
                    new Renderer[] { renderer },
                    transform => paths[transform]);
                Assert.That(
                    withAliases[renderer].CanBecomeVisible, Is.True);
            }
            finally
            {
                Object.DestroyImmediate(root);
            }
        }

        [Test]
        public void VisibilityAnalyzerConstantCurrentStateDoesNotCreateToggle()
        {
            var clip = nadena.dev.ndmf.animator.VirtualClip.Create("constant");
            clip.SetFloatCurve(
                UnityEditor.EditorCurveBinding.FloatCurve(
                    "Accessory", typeof(MeshRenderer), "m_Enabled"),
                AnimationCurve.Constant(0f, 1f, 1f));

            var root = new GameObject("Avatar");
            var child = new GameObject("Accessory");
            try
            {
                child.transform.SetParent(root.transform);
                var renderer = child.AddComponent<MeshRenderer>();
                var index = new nadena.dev.ndmf.animator.AnimationIndex(
                    new nadena.dev.ndmf.animator.VirtualNode[] { clip });

                var visibleStates =
                    AtlasRendererVisibilityAnalyzer.Analyze(
                        index,
                        root.transform,
                        new Renderer[] { renderer },
                        transform => transform == root.transform
                            ? new[] { "" }
                            : new[] { "Accessory" });
                Assert.That(
                    visibleStates[renderer].CanToggleVisibility, Is.False);

                renderer.enabled = false;
                var hiddenStates =
                    AtlasRendererVisibilityAnalyzer.Analyze(
                        index,
                        root.transform,
                        new Renderer[] { renderer },
                        transform => transform == root.transform
                            ? new[] { "" }
                            : new[] { "Accessory" });
                Assert.That(
                    hiddenStates[renderer].CanBecomeVisible, Is.True);
                Assert.That(
                    hiddenStates[renderer].CanToggleVisibility, Is.True);
            }
            finally
            {
                Object.DestroyImmediate(root);
            }
        }

        [Test]
        public void GroupLayoutCacheKeyMatchesDistinctEquivalentArrays()
        {
            var key = new AutoAtlasTextureMergePlanner.GroupLayoutKey(
                new[] { 0, 1, 8 },
                new Vector2Int(512, 256));
            var same = new AutoAtlasTextureMergePlanner.GroupLayoutKey(
                new[] { 0, 1, 8 },
                new Vector2Int(512, 256));
            var differentGroup = new AutoAtlasTextureMergePlanner.GroupLayoutKey(
                new[] { 0, 2, 8 },
                new Vector2Int(512, 256));
            var differentWidth = new AutoAtlasTextureMergePlanner.GroupLayoutKey(
                new[] { 0, 1, 8 },
                new Vector2Int(1024, 256));
            var differentHeight = new AutoAtlasTextureMergePlanner.GroupLayoutKey(
                new[] { 0, 1, 8 },
                new Vector2Int(512, 512));

            Assert.That(key.Equals(same), Is.True);
            Assert.That(key.GetHashCode(), Is.EqualTo(same.GetHashCode()));
            Assert.That(key.Equals(differentGroup), Is.False);
            Assert.That(key.Equals(differentWidth), Is.False);
            Assert.That(key.Equals(differentHeight), Is.False);

            var cache = new Dictionary<
                AutoAtlasTextureMergePlanner.GroupLayoutKey,
                int> { [key] = 42 };
            Assert.That(cache.TryGetValue(same, out var value), Is.True);
            Assert.That(value, Is.EqualTo(42));
        }

        private static AutoAtlasTextureMergePlanner.Candidate Candidate(
            AutoAtlasTextureMergePlanner.TextureCostPlan baseline,
            AutoAtlasTextureMergePlanner.TextureCostPlan merged,
            int[] groupIds = null)
        {
            return new AutoAtlasTextureMergePlanner.Candidate(
                groupIds ?? new[] { 0, 1 },
                baseline,
                merged,
                new Vector2Int(64, 64),
                new Dictionary<string, Vector2Int>());
        }

        private static AutoAtlasTextureMergePlanner.TextureCostPlan Plan(
            IEnumerable<AutoAtlasTextureMergePlanner.TextureCostEntry> entries,
            IReadOnlyDictionary<int, double> sampling = null)
        {
            return new AutoAtlasTextureMergePlanner.TextureCostPlan(
                entries,
                sampling);
        }

        private static AutoAtlasTextureMergePlanner.TextureCostEntry Entry(
            int width,
            int height,
            int mipCount,
            int blockSize = 4)
        {
            return new AutoAtlasTextureMergePlanner.TextureCostEntry(
                width,
                height,
                (1u, 1u, (uint)blockSize),
                mipCount);
        }
    }
}
